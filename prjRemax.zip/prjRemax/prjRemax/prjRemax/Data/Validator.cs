﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjRemax.Data
{
   public  class Validator
    {
        private static string message = "Entry Error";

        public static string Message
        {
            get
            {
                return message;
            }
            set
            {
                message = value;
            }
        }

        public static bool IsPresent(TextBox textBox)
        {
            if (textBox.Text == "")
            {
                
                MessageBox.Show(textBox.Tag + " is a required field.", Message);
                textBox.Focus();
                return false;
            }
            return true;
        }
        public static bool IsPresentRichTxt(RichTextBox textBox)
        {
            if (textBox.Text == "")
            {

                MessageBox.Show(textBox.Tag + " is a required field.", Message);
                textBox.Focus();
                return false;
            }
            return true;
        }
        public static bool IsRightNumber(TextBox textBox)
        {
            int number = Convert.ToInt32(textBox.Text);

            if (!(number.ToString().Length == 4))
            {
                
                MessageBox.Show(textBox.Tag + " must be 4 digits", Message);
                textBox.Clear(); // clear the textBox
                textBox.Focus(); // set the focus()
                return false;
            }
            return true;
        }


        public static bool IsDecimal(TextBox textBox)
        {
            decimal number = 0m;
            if (Decimal.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
             
                MessageBox.Show(textBox.Tag + " must be a decimal value.", Message);
                textBox.Focus();
                return false;
            }
        }

        
        public static bool IsInt32(TextBox textBox)
        {
            int number = 0;
            if (Int32.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(textBox.Tag + " must be an integer.", Message);
                textBox.Clear();
                textBox.Focus();
                return false;
            }
        }
        public static bool IsFloat(TextBox textBox)
        {
            float number = 0;
            if (float.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(textBox.Tag + " must be numbers.", Message);
                textBox.Clear();
                textBox.Focus();
                return false;
            }
        }
        public static bool IsPresentDate(DateTimePicker textBox)
        {
            if (textBox.Text == "")
            {
                // click on the keyword Tag and press F1 to have more detail about Tag property
                MessageBox.Show(textBox.Tag + " is a required field.", Message);
                textBox.Focus();
                return false;
            }
            return true;
        }
        public static bool IsPresentComboBox(ComboBox c1)
        {
            if (c1.Text == "")
            {
                // click on the keyword Tag and press F1 to have more detail about Tag property
                MessageBox.Show(c1.Tag + " is a required field.", Message);
                c1.Focus();
                return false;
            }
            return true;
        }
        public static bool IsSpecialCharacters(TextBox textBox)
        {

            var regexItem = new Regex(@"[~`!@#$%^&*()+=|\{}':;.,<>/?[\]""_-]");
            if (regexItem.IsMatch(textBox.Text))
            {
                MessageBox.Show("Can not contain Special Characters");
                return false;

            }
            return true;

        }
        public static bool IsLetters(TextBox textBox)
        {

            var regexItem = new Regex("^[a-z A-Z]*$");

            if (!regexItem.IsMatch(textBox.Text))
            {
                MessageBox.Show("Can contain only alphabets");
                textBox.Clear();
                textBox.Focus();
                return false;

            }
            return true;

        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Data;

namespace prjRemax.Data
{
    public static class DataBase
    {
        public static DataSet mySet;
        public static OleDbConnection myCon;
        public static OleDbDataAdapter adpUsers, adpEmployees,adpHouses,adpSellers,adpBuyers;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using prjRemax.Bus;

namespace prjRemax.Data
{
    public class List
    {
        public static List<Employee> GetList()
        {
            List<Employee> list = new List<Employee>();
            Employee aEmp;
            DataColumn[] keys = new DataColumn[1];
            keys[0] = DataBase.mySet.Tables["Users"].Columns["RefUsers"];
            DataBase.mySet.Tables["Users"].PrimaryKey = keys;
            Int32 RefUsers = 0;
           
           
            foreach (DataRow myRow in DataBase.mySet.Tables["Employees"].Rows)
            {
                
                aEmp = new Employee();
                aEmp.ID = Convert.ToInt32(myRow["ID"].ToString());
                RefUsers = aEmp.ID;
                aEmp.EmployeeName = myRow["EmployeeName"].ToString();
                aEmp.BirthDate = Convert.ToDateTime(myRow["BirthDate"].ToString());
                aEmp.EmployeePosition = myRow["EmployeePosition"].ToString();
                aEmp.Salary = Convert.ToDouble(myRow["Salary"].ToString());
                aEmp.Status = myRow["Status"].ToString();
                DataRow myRow2 = DataBase.mySet.Tables["Users"].Rows.Find(RefUsers);
                aEmp.Password = myRow2["PassWords"].ToString();
                list.Add(aEmp);
                
            }
            

            return list;
            





        }
        /*Only find the houses of the logged in Agent*/
        public static List<House> GetListHousesSpecifiedAgent()
        {
            List<House> list = new List<House>();
            House aHouse;
            int refSeller = 0;
            int refAgent = 0;
            DataTable tbSellers = DataBase.mySet.Tables["Sellers"];
            DataTable tbAgents = DataBase.mySet.Tables["Employees"];
            DataTable tbHouses = DataBase.mySet.Tables["Houses"];

          



           var FindSeller = from DataRow seller in tbSellers.Rows join DataRow houses in tbHouses.Rows on seller.Field<int>("ID") equals houses.Field<int>("RefSeller") where (houses.Field<int>("RefSeller") == refSeller) select seller.Field<string>("SellerName");
            var FindAgents = from agent in tbAgents.AsEnumerable() where agent.Field<int>("ID") == refAgent select agent.Field<string>("EmployeeName");
            var FindID = from DataRow agent in tbAgents.Rows select agent.Field<int>("ID");

            if (CurrentUser.UserType.ToString() != Positions.Admin.ToString())
            {






                foreach (DataRow myRow in DataBase.mySet.Tables["Houses"].Rows)
                {

                    if (myRow["RefAgent"].ToString() == CurrentUser.ID.ToString())
                    {
                        aHouse = new House();


                        aHouse.ID = Convert.ToInt32(myRow["ID"].ToString());
                        aHouse.YearBuilt = Int32.Parse(myRow["YearBuilt"].ToString());
                        aHouse.LivingArea = float.Parse(myRow["LivingArea"].ToString());
                        aHouse.Address = new Address();
                        aHouse.Address.HouseNumber = myRow["HouseNumber"].ToString();
                        aHouse.Address.StreetName = myRow["StreetName"].ToString();
                        aHouse.Address.District = myRow["District"].ToString();
                        aHouse.Address.City = myRow["City"].ToString();
                        refSeller = Int32.Parse(myRow["RefSeller"].ToString());
                        aHouse.FinalPrice = Int32.Parse(myRow["FinalPrice"].ToString());
                        aHouse.Description = myRow["Description"].ToString();
                        aHouse.RefAgent = CurrentUser.Name;
                        aHouse.RefSellerID = refSeller;
                       
                        aHouse.RefSeller = FindSeller.ToList()[0].ToString();
                        aHouse.RefAgent = CurrentUser.Name;

                        aHouse.RefAgentID = CurrentUser.ID;
                        list.Add(aHouse);
                    }
                }


                return list;

            }
            else
            {
                refSeller = 0;
                refAgent = 0;
                foreach (DataRow myRow in DataBase.mySet.Tables["Houses"].Rows)
                {

                    aHouse = new House();


                    aHouse.ID = Convert.ToInt32(myRow["ID"].ToString());
                    aHouse.YearBuilt = Int32.Parse(myRow["YearBuilt"].ToString());
                    aHouse.LivingArea = float.Parse(myRow["LivingArea"].ToString());
                    aHouse.Address = new Address();
                    aHouse.Address.HouseNumber = myRow["HouseNumber"].ToString();
                    aHouse.Address.StreetName = myRow["StreetName"].ToString();
                    aHouse.Address.District = myRow["District"].ToString();
                    aHouse.Address.City = myRow["City"].ToString();
                    refAgent = Int32.Parse(myRow["RefAgent"].ToString());
                    aHouse.FinalPrice = Int32.Parse(myRow["FinalPrice"].ToString());
                    aHouse.Description = myRow["Description"].ToString();
                    refSeller = Int32.Parse(myRow["RefSeller"].ToString());
                    aHouse.RefSellerID = refSeller;
                    
                  

                    aHouse.RefSeller = FindSeller.ToList()[0].ToString();
                    aHouse.RefAgent = FindAgents.ToList()[0].ToString();
                    FindID = from agent in tbAgents.AsEnumerable() where agent.Field<string>("EmployeeName") == aHouse.RefAgent select agent.Field<int>("ID");
                   
                    aHouse.RefAgentID = Int32.Parse(FindID.ToList()[0].ToString());
                    list.Add(aHouse);

                }
                return list;

            }
        }
        public static List<Buyer> GetListBuyerSpecificAgent()
        {
            List<Buyer> list = new List<Buyer>();
            Buyer aBuy = new Buyer();
            int refAgent = 0;
            DataTable tbAgents = DataBase.mySet.Tables["Employees"];
            var FindAgents = from agent in tbAgents.AsEnumerable() where agent.Field<int>("ID") == refAgent select agent.Field<string>("EmployeeName");
            if (CurrentUser.UserType != Positions.Admin.ToString())
            {
                refAgent = CurrentUser.ID;
                foreach (DataRow myRow in DataBase.mySet.Tables["Buyers"].Rows)
                {
                    if (myRow["RefAgent"].ToString() == CurrentUser.ID.ToString())
                    {
                        aBuy = new Buyer();
                        aBuy.ID = Int32.Parse(myRow["ID"].ToString());
                        aBuy.Name = myRow["BuyersName"].ToString();
                        aBuy.Age = Int32.Parse(myRow["BuyersAge"].ToString());
                        aBuy.BirthDate = DateTime.Parse(myRow["BirthDate"].ToString());
                        aBuy.Credit = myRow["BuyersCredit"].ToString();
                        aBuy.Budget = float.Parse(myRow["BuyersBudget"].ToString());
                        aBuy.Address = new Address();
                        aBuy.Address.HouseNumber = myRow["HouseNumber"].ToString();
                        aBuy.Address.StreetName = myRow["StreetName"].ToString();
                        aBuy.Address.District = myRow["District"].ToString();
                        aBuy.Address.City = myRow["City"].ToString();
                        aBuy.RefAgent = Int32.Parse(myRow["RefAgent"].ToString());
                        aBuy.AgentName = FindAgents.ToList()[0].ToString();
                        list.Add(aBuy);
                    }
                }
                return list;
            }
            else
            {
                
                foreach (DataRow myRow in DataBase.mySet.Tables["Buyers"].Rows)
                {
                    aBuy = new Buyer();
                    aBuy.ID = Int32.Parse(myRow["ID"].ToString());
                    aBuy.Name = myRow["BuyersName"].ToString();
                    aBuy.Age = Int32.Parse(myRow["BuyersAge"].ToString());
                    aBuy.BirthDate = DateTime.Parse(myRow["BirthDate"].ToString());
                    aBuy.Credit = myRow["BuyersCredit"].ToString();
                    aBuy.Budget = float.Parse(myRow["BuyersBudget"].ToString());
                    aBuy.Address = new Address();
                    aBuy.Address.HouseNumber = myRow["HouseNumber"].ToString();
                    aBuy.Address.StreetName = myRow["StreetName"].ToString();
                    aBuy.Address.District = myRow["District"].ToString();
                    aBuy.Address.City = myRow["City"].ToString();
                    aBuy.RefAgent = Int32.Parse(myRow["RefAgent"].ToString());
                    refAgent = aBuy.RefAgent;
                    aBuy.AgentName = FindAgents.ToList()[0].ToString();
                    list.Add(aBuy);
                }
                return list;
                    
            }

        }
        public static List<Seller> GetListSellerSpecificAgent()
        {
            List<Seller> list = new List<Seller>();
            Seller aSeller;
            
            int refAgent = 0;
            DataTable tbAgents = DataBase.mySet.Tables["Employees"];
            var FindAgents = from agent in tbAgents.AsEnumerable() where agent.Field<int>("ID") == refAgent select agent.Field<string>("EmployeeName");


            if (CurrentUser.UserType != Positions.Admin.ToString())
            {
                refAgent = CurrentUser.ID;
                foreach (DataRow myRow in DataBase.mySet.Tables["Sellers"].Rows)
                {
                    if (myRow["RefAgent"].ToString() == CurrentUser.ID.ToString())
                    {
                        aSeller = new Seller();
                        aSeller.ID = Int32.Parse(myRow["ID"].ToString());
                        aSeller.Name = myRow["SellerName"].ToString();
                        aSeller.Age = Int32.Parse(myRow["SellerAge"].ToString());
                        aSeller.BirthDate = DateTime.Parse(myRow["BirthDate"].ToString());
                        aSeller.Address = new Address();
                        aSeller.Address.HouseNumber = myRow["HouseNumber"].ToString();
                        aSeller.Address.StreetName = myRow["StreetName"].ToString();
                        aSeller.Address.District = myRow["District"].ToString();
                        aSeller.Address.City = myRow["City"].ToString();
                        aSeller.RefAgent = Int32.Parse(myRow["RefAgent"].ToString());
                        aSeller.AgentName = FindAgents.ToList()[0].ToString();
                        list.Add(aSeller);
                    }

                }
                return list;
            }
            else
            {
                refAgent = 0;
            
                foreach (DataRow myRow in DataBase.mySet.Tables["Sellers"].Rows)
                {
                   
                    aSeller = new Seller();
                    aSeller.ID = Int32.Parse(myRow["ID"].ToString());
                    aSeller.Name = myRow["SellerName"].ToString();
                    aSeller.Age = Int32.Parse(myRow["SellerAge"].ToString());
                    aSeller.BirthDate = DateTime.Parse(myRow["BirthDate"].ToString());
                    aSeller.Address = new Address();
                    aSeller.Address.HouseNumber = myRow["HouseNumber"].ToString();
                    aSeller.Address.StreetName = myRow["StreetName"].ToString();
                    aSeller.Address.District = myRow["District"].ToString();
                    aSeller.Address.City = myRow["City"].ToString();
                    aSeller.RefAgent = Int32.Parse(myRow["RefAgent"].ToString());
                    refAgent= Int32.Parse(myRow["RefAgent"].ToString());
                    aSeller.AgentName = FindAgents.ToList()[0].ToString();
                    list.Add(aSeller);

                   
                }
                return list;


            }






        }
    }
}

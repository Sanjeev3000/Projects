﻿namespace prjRemax.GUI
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.actionsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.EmployeesMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.AgentsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.Housesmenu = new System.Windows.Forms.ToolStripMenuItem();
            this.buyersmenu = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSellers = new System.Windows.Forms.ToolStripMenuItem();
            this.Searchmnu = new System.Windows.Forms.ToolStripMenuItem();
            this.ExitMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.info = new System.Windows.Forms.MenuStrip();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.lblUserName = new System.Windows.Forms.Label();
            this.info.SuspendLayout();
            this.bunifuGradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // actionsMenu
            // 
            this.actionsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.EmployeesMenu,
            this.AgentsMenu,
            this.buyersmenu,
            this.mnuSellers,
            this.Searchmnu,
            this.ExitMenu});
            this.actionsMenu.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.actionsMenu.Name = "actionsMenu";
            this.actionsMenu.Size = new System.Drawing.Size(81, 25);
            this.actionsMenu.Text = "Actions";
            // 
            // EmployeesMenu
            // 
            this.EmployeesMenu.Name = "EmployeesMenu";
            this.EmployeesMenu.Size = new System.Drawing.Size(162, 26);
            this.EmployeesMenu.Text = "Employees";
            this.EmployeesMenu.Click += new System.EventHandler(this.EmployeesMenu_Click);
            // 
            // AgentsMenu
            // 
            this.AgentsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Housesmenu});
            this.AgentsMenu.Name = "AgentsMenu";
            this.AgentsMenu.Size = new System.Drawing.Size(162, 26);
            this.AgentsMenu.Text = "Agents";
            this.AgentsMenu.Click += new System.EventHandler(this.AgentsMenu_Click);
            // 
            // Housesmenu
            // 
            this.Housesmenu.Name = "Housesmenu";
            this.Housesmenu.Size = new System.Drawing.Size(133, 26);
            this.Housesmenu.Text = "Houses";
            this.Housesmenu.Click += new System.EventHandler(this.Housesmenu_Click);
            // 
            // buyersmenu
            // 
            this.buyersmenu.Name = "buyersmenu";
            this.buyersmenu.Size = new System.Drawing.Size(162, 26);
            this.buyersmenu.Text = "Buyers";
            this.buyersmenu.Click += new System.EventHandler(this.buyersmenu_Click);
            // 
            // mnuSellers
            // 
            this.mnuSellers.Name = "mnuSellers";
            this.mnuSellers.Size = new System.Drawing.Size(162, 26);
            this.mnuSellers.Text = "Sellers";
            this.mnuSellers.Click += new System.EventHandler(this.mnuSellers_Click);
            // 
            // Searchmnu
            // 
            this.Searchmnu.Name = "Searchmnu";
            this.Searchmnu.Size = new System.Drawing.Size(162, 26);
            this.Searchmnu.Text = "Search";
            this.Searchmnu.Click += new System.EventHandler(this.Searchmnu_Click);
            // 
            // ExitMenu
            // 
            this.ExitMenu.Name = "ExitMenu";
            this.ExitMenu.Size = new System.Drawing.Size(162, 26);
            this.ExitMenu.Text = "Exit";
            this.ExitMenu.Click += new System.EventHandler(this.ExitMenu_Click);
            // 
            // info
            // 
            this.info.BackColor = System.Drawing.Color.Transparent;
            this.info.Dock = System.Windows.Forms.DockStyle.None;
            this.info.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.actionsMenu});
            this.info.Location = new System.Drawing.Point(0, 0);
            this.info.Name = "info";
            this.info.Size = new System.Drawing.Size(89, 29);
            this.info.TabIndex = 1;
            this.info.Text = "menuStrip1";
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.lblUserName);
            this.bunifuGradientPanel1.Controls.Add(this.info);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.DeepSkyBlue;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.RoyalBlue;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.LightSkyBlue;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.White;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(505, 30);
            this.bunifuGradientPanel1.TabIndex = 5;
            this.bunifuGradientPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.bunifuGradientPanel1_Paint);
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.BackColor = System.Drawing.Color.Transparent;
            this.lblUserName.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblUserName.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.Location = new System.Drawing.Point(491, 0);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(14, 21);
            this.lblUserName.TabIndex = 11;
            this.lblUserName.Text = "!";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(505, 428);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.IsMdiContainer = true;
            this.Name = "frmMain";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.info.ResumeLayout(false);
            this.info.PerformLayout();
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem actionsMenu;
        private System.Windows.Forms.ToolStripMenuItem EmployeesMenu;
        private System.Windows.Forms.ToolStripMenuItem AgentsMenu;
        private System.Windows.Forms.ToolStripMenuItem Housesmenu;
        private System.Windows.Forms.ToolStripMenuItem ExitMenu;
        private System.Windows.Forms.MenuStrip info;
        private System.Windows.Forms.ToolStripMenuItem mnuSellers;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.ToolStripMenuItem buyersmenu;
        private System.Windows.Forms.ToolStripMenuItem Searchmnu;
    }
}
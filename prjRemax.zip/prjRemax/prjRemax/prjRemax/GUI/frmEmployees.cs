﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using prjRemax.Bus;
using prjRemax.Data;
using System.Data.OleDb;

namespace prjRemax.GUI
{
    public partial class frmEmployees : Form
    {
        string mode;
        public frmEmployees()
        {
            InitializeComponent();
        }
        private void GridControls()
        {
            gridEmployees.DataSource = listOfEmployees;
            gridEmployees.Columns[0].HeaderText = "Name";
            gridEmployees.Columns[1].HeaderText = "BirthDate";
            gridEmployees.Columns[2].HeaderText = "Position";
            gridEmployees.Columns[3].HeaderText = "Income";
            gridEmployees.Columns[4].HeaderText = "Status";
            gridEmployees.Columns[5].HeaderText = "Password";
            gridEmployees.Columns[6].HeaderText = "Employee Number";





        }
        private void Grid2TXT()
        {
            txtEmployeeName.Text = gridEmployees.CurrentRow.Cells[0].Value.ToString();
            datBirthdate.Value = Convert.ToDateTime(gridEmployees.CurrentRow.Cells[1].Value);
            cboPosition.Text= gridEmployees.CurrentRow.Cells[2].Value.ToString();
            txtSalary.Text= gridEmployees.CurrentRow.Cells[3].Value.ToString();
            cboStatus.Text= gridEmployees.CurrentRow.Cells[4].Value.ToString();
            txtPassword.Text= gridEmployees.CurrentRow.Cells[5].Value.ToString();
           

        }
        private void Visibility(bool Name, bool Birth, bool Post, bool Sal, bool Status, bool Pass)
        {

            txtEmployeeName.Enabled = Name;
            datBirthdate.Enabled = Birth;
            cboPosition.Enabled = Post;
            txtSalary.Enabled = Sal;
            cboStatus.Enabled = Status;
            txtPassword.Enabled = Pass;




        }
        private void ButtonControls(bool Add, bool Edit, bool Save)
        {
            btnAdd.Visible = Add;
            btnEdit.Visible = Edit;
            btnSave.Visible = Save;
        }
        public List<Employee> listOfEmployees = List.GetList();
        




        DataTable tbEmployees;
        DataTable tbUsers;
        private void frmEmployees_Load(object sender, EventArgs e)
        {
            timerCircle.Start();
            gridEmployees.Visible = false;
            tbEmployees = DataBase.mySet.Tables["Employees"];
            tbUsers = DataBase.mySet.Tables["Users"];
            cboPosition.Items.Add("Admin");
            cboPosition.Items.Add("Agent");
            cboStatus.Items.Add("Full-Time");
            cboStatus.Items.Add("Part-Time");
            GridControls();
            Visibility(false, false, false, false, false, false);
            ButtonControls(true, true, false);
            
        }


        private void btnAdd_Click_1(object sender, EventArgs e)
        {

            Visibility(true, true, true, true, true, true);
            ButtonControls(false, false, true);
            mode = "Add";
            txtEmployeeName.Text = "";
            txtPassword.Text = "";
            txtSalary.Text = "";
            datBirthdate.Value = DateTime.Now;
            cboPosition.Text = "";
            cboStatus.Text = "";
        }

     
        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Are you sure?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }
        private bool IsValid()
        {
            return Validator.IsPresent(txtEmployeeName) && Validator.IsPresent(txtPassword) && Validator.IsPresent(txtSalary) && Validator.IsPresentDate(datBirthdate) && Validator.IsPresentComboBox(cboPosition) && Validator.IsPresentComboBox(cboStatus) && Validator.IsLetters(txtEmployeeName) && Validator.IsSpecialCharacters(txtSalary) && Validator.IsFloat(txtSalary) && Validator.IsSpecialCharacters(txtPassword);
        }
        private void btnSave1_Click(object sender, EventArgs e)
        {
            ButtonControls(true,true,false);
            int index = 0;
            Int32 current = 0;
            DataRow myRow = null;
            DataRow myRow2 = null;




            if (mode == "Add")
            {
                if (IsValid())
                {
                    myRow = tbEmployees.NewRow();
                tbEmployees.Rows.Add(myRow);
                


                    Employee aEmp = new Employee(txtEmployeeName.Text, datBirthdate.Value.Subtract(datBirthdate.Value.TimeOfDay), cboPosition.SelectedItem.ToString(), Convert.ToDouble(txtSalary.Text), cboStatus.SelectedItem.ToString(), txtPassword.Text);

                    listOfEmployees.Add(aEmp);

                    gridEmployees.DataSource = null;
                    gridEmployees.DataSource = listOfEmployees;
                    GridControls();


                    foreach (Employee item in listOfEmployees)
                    {

                        foreach (DataRow row in tbEmployees.Rows)
                        {
                            if (row["EmployeeName"].ToString() == item.EmployeeName.ToString())
                            {
                                current++;
                            }
                        }
                    }
                    myRow2 = tbUsers.NewRow();
                    listOfEmployees[current].ID = gridEmployees.RowCount;
                    myRow["ID"] = listOfEmployees[current].ID;
                    myRow["EmployeeName"] = listOfEmployees[current].EmployeeName;
                    myRow["BirthDate"] = listOfEmployees[current].BirthDate;
                    myRow["EmployeePosition"] = listOfEmployees[current].EmployeePosition;
                    myRow["Salary"] = listOfEmployees[current].Salary;
                    myRow["Status"] = listOfEmployees[current].Status;

                    myRow2["PassWords"] = listOfEmployees[current].Password;
                    myRow2["RefUsers"] = listOfEmployees[current].ID;

                    tbUsers.Rows.Add(myRow2);
                    MessageBox.Show("Success");
                }
            }
            if (mode == "Edit")
            {
                if (IsValid())
                {

                    index = gridEmployees.CurrentRow.Index;

                    listOfEmployees[index].EmployeeName = txtEmployeeName.Text;
                    listOfEmployees[index].BirthDate = datBirthdate.Value.Subtract(datBirthdate.Value.TimeOfDay);
                    listOfEmployees[index].EmployeePosition = cboPosition.SelectedItem.ToString();
                    listOfEmployees[index].Salary = Convert.ToDouble(txtSalary.Text);
                    listOfEmployees[index].Status = cboStatus.SelectedItem.ToString();
                    listOfEmployees[index].Password = txtPassword.Text;
                    current = index;

                    myRow = tbEmployees.Rows[current];
                    myRow2 = tbUsers.Rows[current];

                    myRow["EmployeeName"] = listOfEmployees[index].EmployeeName;
                    myRow["BirthDate"] = listOfEmployees[index].BirthDate;
                    myRow["EmployeePosition"] = listOfEmployees[index].EmployeePosition;
                    myRow["Salary"] = listOfEmployees[index].Salary;
                    myRow["Status"] = listOfEmployees[index].Status;
                    myRow2["PassWords"] = listOfEmployees[index].Password;

                    gridEmployees.DataSource = null;
                    gridEmployees.DataSource = listOfEmployees;
                    GridControls();
                    MessageBox.Show("Done");

                }
            }





            OleDbCommandBuilder myBuild = new OleDbCommandBuilder(DataBase.adpEmployees);
            DataBase.adpEmployees.Update(tbEmployees);





            OleDbCommandBuilder myBuild2 = new OleDbCommandBuilder(DataBase.adpUsers);
            DataBase.adpUsers.Update(tbUsers);

            

            current = 0;
            index = 0;
            Visibility(false, false, false, false, false, false);
            DataBase.mySet.Tables["Employees"].Reset();
            DataBase.adpEmployees.Fill(DataBase.mySet, "Employees");

            
        }

        private void btnEdit_Click_2(object sender, EventArgs e)
        {
            Visibility(true, true, true, true, true, true);

            mode = "Edit";
            txtEmployeeName.Focus();
            ButtonControls(false, false, true);

        }

        private void gridEmployees_CellDoubleClick_1(object sender, DataGridViewCellEventArgs e)
        {
            Grid2TXT();
        }
        int i = 0;
        private void timerCircle_Tick(object sender, EventArgs e)
        {
            
            
            i= i + 25;
            CircleProgress.Value = i;
            if (CircleProgress.Value==100)
            {
                timerCircle.Stop();
                CircleProgress.Visible = false;
                gridEmployees.Visible = true;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            bool c1 = false;
            
           
            int current = Int32.Parse(gridEmployees.CurrentRow.Cells[6].Value.ToString());
            foreach (DataRow item in DataBase.mySet.Tables["Houses"].Rows)
            {
                if (item["RefAgent"].ToString()==current.ToString())
                {
                    MessageBox.Show("Give the house of this agent to another agent!");
                    c1 = false;

                }
                else
                {
                    c1 = true;

                }
            }
            foreach (DataRow item in DataBase.mySet.Tables["Sellers"].Rows)
            {
                if (item["RefAgent"].ToString() == current.ToString())
                {
                    MessageBox.Show("Give the house of this agent to another agent!");
                    c1 = false;


                }
                else
                {
                    c1 = true;

                }
            }
            foreach (DataRow item in DataBase.mySet.Tables["Buyers"].Rows)
            {
                if (item["RefAgent"].ToString() == current.ToString())
                {
                    MessageBox.Show("Give the house of this agent to another agent!");
                    c1 = false;


                }
                else
                {
                    c1 = true;

                }
            }
            if (c1==true)
            {


                DataRow[] rowsE = tbEmployees.Select("ID=" + current);
                rowsE[0].Delete();
                DataRow[] rows = tbUsers.Select("RefUsers=" + current);
                rows[0].Delete();
                listOfEmployees.RemoveAt(gridEmployees.CurrentRow.Index);
                gridEmployees.DataSource = null;
                gridEmployees.DataSource = listOfEmployees;
                GridControls();
                OleDbCommandBuilder myBuild2 = new OleDbCommandBuilder(DataBase.adpUsers);
                DataBase.adpUsers.Update(tbUsers);
                OleDbCommandBuilder myBuild = new OleDbCommandBuilder(DataBase.adpEmployees);
                DataBase.adpEmployees.Update(tbEmployees);
                

                DataBase.mySet.Tables["Employees"].Reset();
                DataBase.adpEmployees.Fill(DataBase.mySet, "Employees");

                DataBase.mySet.Tables["Users"].Reset();
                DataBase.adpUsers.Fill(DataBase.mySet, "Users");


            }

        }
    }
}

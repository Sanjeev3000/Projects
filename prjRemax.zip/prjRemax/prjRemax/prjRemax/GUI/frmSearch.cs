﻿using prjRemax.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjRemax.GUI
{
    public partial class frmSearch : Form
    {
        public frmSearch()
        {
            InitializeComponent();
        }
        DataTable tb;
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            
           
            gridResults.DataSource = null;
            if (cboSelect.Text == "HouseReferenceNumber")
            {
                lblSub.Text = "Results for Houses based on House Reference Number: "+txtSearch.Text;
                tb = DataBase.mySet.Tables["Houses"].Clone();
                OleDbDataAdapter adpTmp = new OleDbDataAdapter("Select * From Houses Where ID Like '" + txtSearch.Text + "%'", DataBase.myCon);
                adpTmp.Fill(tb);
                gridResults.DataSource = tb;
                gridResults.Columns[1].HeaderText = "Year Built";
                gridResults.Columns[2].HeaderText = "Living Area in SF";
                gridResults.Columns[3].HeaderText = "House Number";
                gridResults.Columns[4].HeaderText = "Street Name";
                gridResults.Columns[5].HeaderText = "District";
                gridResults.Columns[6].HeaderText = "City";
                gridResults.Columns[7].HeaderText = "Final Price";
                gridResults.Columns[8].HeaderText = "Description";
                gridResults.Columns[9].HeaderText = "Real Estate Agent ID";
                gridResults.Columns[10].HeaderText = "Property Owner ID";
                gridResults.Columns[0].HeaderText = "House Reference ID";


            }
            if (cboSelect.Text=="City")
            {
                lblSub.Text = "Results for Houses based on City: " + txtSearch.Text;

                tb = DataBase.mySet.Tables["Houses"].Clone();
                OleDbDataAdapter adpTmp = new OleDbDataAdapter("Select * From Houses Where City Like '" + txtSearch.Text + "%'", DataBase.myCon);
                adpTmp.Fill(tb);
                gridResults.DataSource = tb;
                gridResults.Columns[1].HeaderText = "Year Built";
                gridResults.Columns[2].HeaderText = "Living Area in SF";
                gridResults.Columns[3].HeaderText = "House Number";
                gridResults.Columns[4].HeaderText = "Street Name";
                gridResults.Columns[5].HeaderText = "District";
                gridResults.Columns[6].HeaderText = "City";
                gridResults.Columns[7].HeaderText = "Final Price";
                gridResults.Columns[8].HeaderText = "Description";
                gridResults.Columns[9].HeaderText = "Real Estate Agent ID";
                gridResults.Columns[10].HeaderText = "Property Owner ID";
                gridResults.Columns[0].HeaderText = "House Reference ID";
            }
            if (cboSelect.Text == "FinalPrice")
            {
                lblSub.Text = "Results for Houses based on Final Price: " + txtSearch.Text;

                tb = DataBase.mySet.Tables["Houses"].Clone();
                OleDbDataAdapter adpTmp = new OleDbDataAdapter("Select * From Houses Where FinalPrice Like '" + txtSearch.Text + "%'", DataBase.myCon);
                adpTmp.Fill(tb);
                gridResults.DataSource = tb;
                gridResults.Columns[1].HeaderText = "Year Built";
                gridResults.Columns[2].HeaderText = "Living Area in SF";
                gridResults.Columns[3].HeaderText = "House Number";
                gridResults.Columns[4].HeaderText = "Street Name";
                gridResults.Columns[5].HeaderText = "District";
                gridResults.Columns[6].HeaderText = "City";
                gridResults.Columns[7].HeaderText = "Final Price";
                gridResults.Columns[8].HeaderText = "Description";
                gridResults.Columns[9].HeaderText = "Real Estate Agent ID";
                gridResults.Columns[10].HeaderText = "Property Owner ID";
                gridResults.Columns[0].HeaderText = "House Reference ID";
            }
            if (cboSelect.Text=="EmployeeNumber")
            {
                lblSub.Text = "Results for Houses based on Agent Reference Number: " + txtSearch.Text;

                tb = DataBase.mySet.Tables["Employees"].Clone();
                OleDbDataAdapter adpTmp = new OleDbDataAdapter("Select * From Employees Where ID Like '" + txtSearch.Text + "%'", DataBase.myCon);
                adpTmp.Fill(tb);
                gridResults.DataSource = tb;
                gridResults.Columns[1].HeaderText = "Name";
                gridResults.Columns[2].HeaderText = "BirthDate";
                gridResults.Columns[3].HeaderText = "Position";
                gridResults.Columns[4].HeaderText = "Income";
                gridResults.Columns[5].HeaderText = "Status";
                gridResults.Columns[0].HeaderText = "Employee Number";


            }
            if (cboSelect.Text == "EmployeeName")
            {
                lblSub.Text = "Results for Houses based on Agent Name: " + txtSearch.Text;

                tb = DataBase.mySet.Tables["Employees"].Clone();
                OleDbDataAdapter adpTmp = new OleDbDataAdapter("Select * From Employees Where EmployeeName Like '" + txtSearch.Text + "%'", DataBase.myCon);
                adpTmp.Fill(tb);
                gridResults.DataSource = tb;
                gridResults.Columns[1].HeaderText = "Name";
                gridResults.Columns[2].HeaderText = "BirthDate";
                gridResults.Columns[3].HeaderText = "Position";
                gridResults.Columns[4].HeaderText = "Income";
                gridResults.Columns[5].HeaderText = "Status";
                gridResults.Columns[0].HeaderText = "Employee Number";


            }
            if (cboSelect.Text == "EmployeeStatus")
            {
                lblSub.Text = "Results for Houses based on Agent status: " + txtSearch.Text;

                tb = DataBase.mySet.Tables["Employees"].Clone();
                OleDbDataAdapter adpTmp = new OleDbDataAdapter("Select * From Employees Where Status Like '" + txtSearch.Text + "%'", DataBase.myCon);
                adpTmp.Fill(tb);
                gridResults.DataSource = tb;
                gridResults.Columns[1].HeaderText = "Name";
                gridResults.Columns[2].HeaderText = "BirthDate";
                gridResults.Columns[3].HeaderText = "Position";
                gridResults.Columns[4].HeaderText = "Income";
                gridResults.Columns[5].HeaderText = "Status";
                gridResults.Columns[0].HeaderText = "Employee Number";


            }
        }
       
        private void frmSearch_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Are you sure?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}

﻿using prjRemax.Bus;
using prjRemax.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjRemax.GUI
{
    public partial class frmBuyers : Form
    {
        public frmBuyers()
        {
            InitializeComponent();
        }
        string mode;
        private void buttonControls(bool add,bool edit,bool save,bool del)
        {
            btnAdd.Visible = add;
            btnEdit.Visible = edit;
            btnSave.Visible = save;
            btnDelete.Visible = del;
        }
        private void Visibility(bool Name,bool age,bool date,bool credit,bool budget,bool number,bool sname,bool dis,bool city,bool agent)
        {
         txtName.Enabled = Name;
            txtAge.Enabled = age;
            datBirthdate.Enabled = date;
            cboCredit.Enabled = credit;
            txtBudget.Enabled = budget;
            txtHNumber.Enabled = number;
            txtStreetName.Enabled = sname;
            txtDistrict.Enabled = dis;
            txtCity.Enabled = city;
            cboAgent.Enabled = agent;   
        }
        public List<Buyer> listOfBuyers = List.GetListBuyerSpecificAgent();
        DataTable tbBuyers;
        private void frmBuyers_Load(object sender, EventArgs e)
        {
            if (CurrentUser.UserType != Positions.Admin.ToString())
            {
                cboAgent.Visible = false;
                lblRegAge.Visible = false;
            }
            gridBuyers.Visible = false;
            timer.Start();
            cboAgent.DisplayMember = "Names";
            cboAgent.ValueMember = "ID";
            cboAgent.DataSource = (from agent in DataBase.mySet.Tables["Employees"].AsEnumerable() where (agent.Field<string>("EmployeePosition") == Positions.Agent.ToString()) select new { Names = agent.Field<string>("EmployeeName"), ID = agent.Field<int>("ID") }).ToList();
            tbBuyers = DataBase.mySet.Tables["Buyers"];
            gridBuyers.DataSource = listOfBuyers;
            GridControls();
            Visibility(false, false, false, false, false, false, false, false, false, false);
            buttonControls(true, true, false,true);
        }
        private void GridControls()
        {
            gridBuyers.DataSource = listOfBuyers;
            gridBuyers.Columns[0].HeaderText = "Agent Reference Number";
            gridBuyers.Columns[1].HeaderText = "Agent Name";
            gridBuyers.Columns[2].HeaderText = "Buyer's Reference Number";
            gridBuyers.Columns[3].HeaderText = "Credit";
            gridBuyers.Columns[4].HeaderText = "Budget";
            gridBuyers.Columns[5].HeaderText = "Name";
            gridBuyers.Columns[6].HeaderText = "Age";
            gridBuyers.Columns[7].HeaderText = "BirthDate";
            gridBuyers.Columns[8].HeaderText = "Address";
        }
        private void Grid2TXT()
        {
            txtName.Text = gridBuyers.CurrentRow.Cells[5].Value.ToString();
            txtAge.Text = gridBuyers.CurrentRow.Cells[6].Value.ToString();
            datBirthdate.Value = DateTime.Parse(gridBuyers.CurrentRow.Cells[7].Value.ToString());
            txtHNumber.Text = listOfBuyers[gridBuyers.CurrentRow.Index].Address.HouseNumber.ToString();
            txtStreetName.Text = listOfBuyers[gridBuyers.CurrentRow.Index].Address.StreetName;
            txtDistrict.Text = listOfBuyers[gridBuyers.CurrentRow.Index].Address.District;
            txtCity.Text = listOfBuyers[gridBuyers.CurrentRow.Index].Address.City;
            cboCredit.Text = gridBuyers.CurrentRow.Cells[3].Value.ToString();
            txtBudget.Text = gridBuyers.CurrentRow.Cells[4].Value.ToString();
            cboAgent.Text = gridBuyers.CurrentRow.Cells[1].Value.ToString();
        }

        private void lblsHouse_Click(object sender, EventArgs e)
        {

        }
        int i;
        private void timer_Tick(object sender, EventArgs e)
        {
            i += 25;
            CircleProgress.Value = i;
            if (CircleProgress.Value == 100)
            {
                timer.Stop();
                CircleProgress.Visible = false;
                gridBuyers.Visible = true;
            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this,"Are you sure?","Exit",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
            {
                this.Close();
            }
            
        }

    
        private void gridBuyers_DoubleClick(object sender, EventArgs e)
        {
            Grid2TXT();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtAge.Clear();
            txtBudget.Clear();
            txtCity.Clear();
            txtDistrict.Clear();
            txtHNumber.Clear();
            txtName.Clear();
            txtStreetName.Clear();
            cboCredit.Text = "";
            cboAgent.Text = "";
            datBirthdate.Value = DateTime.Now;
            mode = "ADD";
            Visibility(true, true, true, true, true, true, true, true, true, true);
            buttonControls(false, false, true,false);
        }


        private bool IsValid()
        {
            return Validator.IsLetters(txtName) && Validator.IsPresent(txtName) && Validator.IsSpecialCharacters(txtName) && Validator.IsPresentDate(datBirthdate) && Validator.IsPresent(txtAge) && Validator.IsInt32(txtAge) && Validator.IsPresentComboBox(cboCredit) && Validator.IsPresent(txtBudget) && Validator.IsSpecialCharacters(txtBudget) && Validator.IsFloat(txtBudget) && Validator.IsPresent(txtHNumber) && Validator.IsSpecialCharacters(txtHNumber) && Validator.IsPresent(txtStreetName) && Validator.IsSpecialCharacters(txtStreetName) && Validator.IsPresent(txtDistrict) && Validator.IsSpecialCharacters(txtDistrict) && Validator.IsPresent(txtCity) && Validator.IsSpecialCharacters(txtCity);
        }
        private void btnSave_Click(object sender, EventArgs e)
        {

            DataRow myRow = null;
            Buyer aBuy;
            int current = 0;
            int ID = 0;
            if (mode == "ADD")
            {
                if (IsValid())
                {


                    myRow = tbBuyers.NewRow();
                    tbBuyers.Rows.Add(myRow);
                    if (CurrentUser.UserType == Positions.Admin.ToString())
                    {
                        aBuy = new Buyer(txtName.Text, Int32.Parse(txtAge.Text), datBirthdate.Value, new Address(txtHNumber.Text, txtStreetName.Text, txtDistrict.Text, txtCity.Text), cboCredit.Text, float.Parse(txtBudget.Text), Int32.Parse(cboAgent.SelectedValue.ToString()), cboAgent.Text);

                    }
                    else
                    {
                        aBuy = new Buyer(txtName.Text, Int32.Parse(txtAge.Text), datBirthdate.Value, new Address(txtHNumber.Text, txtStreetName.Text, txtDistrict.Text, txtCity.Text), cboCredit.Text, float.Parse(txtBudget.Text), CurrentUser.ID, CurrentUser.Name);

                    }
                    listOfBuyers.Add(aBuy);
                    gridBuyers.DataSource = null;
                    gridBuyers.DataSource = listOfBuyers;
                    GridControls();
                    foreach (Buyer item in listOfBuyers)
                    {
                        foreach (DataRow rows in tbBuyers.Rows)
                        {
                            if (rows["ID"].ToString() == item.ID.ToString())
                            {
                                current++;
                            }
                        }
                    }
                    ID = current + 1;
                    listOfBuyers[current].ID = ID;
                    myRow["BuyersName"] = listOfBuyers[current].Name;
                    myRow["BuyersAge"] = listOfBuyers[current].Age;
                    myRow["BirthDate"] = listOfBuyers[current].BirthDate;
                    myRow["BuyersCredit"] = listOfBuyers[current].Credit;
                    myRow["BuyersBudget"] = listOfBuyers[current].Budget;
                    myRow["HouseNumber"] = listOfBuyers[current].Address.HouseNumber;
                    myRow["StreetName"] = listOfBuyers[current].Address.StreetName;
                    myRow["District"] = listOfBuyers[current].Address.District;
                    myRow["City"] = listOfBuyers[current].Address.City;
                    myRow["RefAgent"] = listOfBuyers[current].RefAgent;
                    MessageBox.Show("Success");
                }
            }
            if (mode == "EDIT")
            {
                if (IsValid())
                {


                    current = gridBuyers.CurrentRow.Index;
                    if (CurrentUser.UserType == Positions.Admin.ToString())
                    {
                        listOfBuyers[current].Name = txtName.Text;
                        listOfBuyers[current].Age = Int32.Parse(txtAge.Text);
                        listOfBuyers[current].BirthDate = datBirthdate.Value;
                        listOfBuyers[current].Credit = cboCredit.Text;
                        listOfBuyers[current].Budget = float.Parse(txtBudget.Text);
                        listOfBuyers[current].Address.HouseNumber = txtHNumber.Text;
                        listOfBuyers[current].Address.StreetName = txtStreetName.Text;
                        listOfBuyers[current].Address.District = txtDistrict.Text;
                        listOfBuyers[current].Address.City = txtCity.Text;
                        listOfBuyers[current].RefAgent = Int32.Parse(cboAgent.SelectedValue.ToString());
                        listOfBuyers[current].AgentName = cboAgent.Text;

                        myRow = tbBuyers.Rows[current];

                        myRow["BuyersName"] = listOfBuyers[current].Name;
                        myRow["BuyersAge"] = listOfBuyers[current].Age;
                        myRow["BirthDate"] = listOfBuyers[current].BirthDate;
                        myRow["BuyersCredit"] = listOfBuyers[current].Credit;
                        myRow["BuyersBudget"] = listOfBuyers[current].Budget;
                        myRow["HouseNumber"] = listOfBuyers[current].Address.HouseNumber;
                        myRow["StreetName"] = listOfBuyers[current].Address.StreetName;
                        myRow["District"] = listOfBuyers[current].Address.District;
                        myRow["City"] = listOfBuyers[current].Address.City;
                        myRow["RefAgent"] = listOfBuyers[current].RefAgent;

                        gridBuyers.DataSource = null;
                        gridBuyers.DataSource = listOfBuyers;
                        GridControls();


                    }
                    if (CurrentUser.UserType != Positions.Admin.ToString())
                    {
                        current = 0;
                        current = gridBuyers.CurrentRow.Index;
                        listOfBuyers[current].Name = txtName.Text;
                        listOfBuyers[current].Age = Int32.Parse(txtAge.Text);
                        listOfBuyers[current].BirthDate = datBirthdate.Value;
                        listOfBuyers[current].Credit = cboCredit.Text;
                        listOfBuyers[current].Budget = float.Parse(txtBudget.Text);
                        listOfBuyers[current].Address.HouseNumber = txtHNumber.Text;
                        listOfBuyers[current].Address.StreetName = txtStreetName.Text;
                        listOfBuyers[current].Address.District = txtDistrict.Text;
                        listOfBuyers[current].Address.City = txtCity.Text;
                        listOfBuyers[current].RefAgent = Int32.Parse(cboAgent.SelectedValue.ToString());
                        listOfBuyers[current].AgentName = cboAgent.Text;

                        DataRow[] rows = tbBuyers.Select("ID=" + listOfBuyers[current].ID);
                        myRow = rows[0];
                        myRow["BuyersName"] = listOfBuyers[current].Name;
                        myRow["BuyersAge"] = listOfBuyers[current].Age;
                        myRow["BirthDate"] = listOfBuyers[current].BirthDate;
                        myRow["BuyersCredit"] = listOfBuyers[current].Credit;
                        myRow["BuyersBudget"] = listOfBuyers[current].Budget;
                        myRow["HouseNumber"] = listOfBuyers[current].Address.HouseNumber;
                        myRow["StreetName"] = listOfBuyers[current].Address.StreetName;
                        myRow["District"] = listOfBuyers[current].Address.District;
                        myRow["City"] = listOfBuyers[current].Address.City;
                        myRow["RefAgent"] = listOfBuyers[current].RefAgent;
                        gridBuyers.DataSource = null;
                        gridBuyers.DataSource = listOfBuyers;
                        GridControls();
                    }
                    MessageBox.Show("DONE");
                }
            }
                OleDbCommandBuilder myBuild = new OleDbCommandBuilder(DataBase.adpBuyers);
            DataBase.adpBuyers.Update(tbBuyers);
            current = 0;
            ID = 0;
            DataBase.mySet.Tables["Buyers"].Reset();
            DataBase.adpBuyers.Fill(DataBase.mySet, "Buyers");
            Visibility(false, false, false, false, false, false, false, false, false, false);
            buttonControls(true, true, false,true);
    
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            txtName.Focus();
            mode = "EDIT";
            Visibility(true, true, true, true, true, true, true, true, true, true);
            buttonControls(false, false, true, false);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            
            int current = gridBuyers.CurrentRow.Index;
            if (CurrentUser.UserType == Positions.Admin.ToString())
            {


                if (MessageBox.Show(this, "Do you want to remove the buyer: " + tbBuyers.Rows[current]["BuyersName"].ToString() + "?", "Removal", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    tbBuyers.Rows[current].Delete();
                    listOfBuyers.RemoveAt(current);
                    gridBuyers.DataSource = null;
                    gridBuyers.DataSource = listOfBuyers;
                    GridControls();
                  
                }
            }
            else
            {
                if (MessageBox.Show(this, "Do you want to remove the buyer: " + gridBuyers.CurrentRow.Cells[5].Value.ToString() + "?", "Removal", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    DataRow[] rows = tbBuyers.Select("ID=" + gridBuyers.CurrentRow.Cells[2].Value);

                    rows[0].Delete();
                    listOfBuyers.RemoveAt(current);
                    gridBuyers.DataSource = null;
                    gridBuyers.DataSource = listOfBuyers;
                    GridControls();
                   
                }
            }
            OleDbCommandBuilder myBuild = new OleDbCommandBuilder(DataBase.adpBuyers);
            DataBase.adpBuyers.Update(tbBuyers);

            DataBase.mySet.Tables["Buyers"].Reset();
            DataBase.adpBuyers.Fill(DataBase.mySet, "Buyers");
        }
    }
}

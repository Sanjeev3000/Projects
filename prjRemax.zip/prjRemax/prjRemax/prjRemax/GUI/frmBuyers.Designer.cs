﻿namespace prjRemax.GUI
{
    partial class frmBuyers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBuyers));
            this.gridBuyers = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblSal = new System.Windows.Forms.Label();
            this.lblPosition = new System.Windows.Forms.Label();
            this.lblBirth = new System.Windows.Forms.Label();
            this.lnlEmpName = new System.Windows.Forms.Label();
            this.datBirthdate = new System.Windows.Forms.DateTimePicker();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.cboCredit = new System.Windows.Forms.ComboBox();
            this.txtBudget = new System.Windows.Forms.TextBox();
            this.cboAgent = new System.Windows.Forms.ComboBox();
            this.lblRegAge = new System.Windows.Forms.Label();
            this.lblDistrict = new System.Windows.Forms.Label();
            this.lblsStreet = new System.Windows.Forms.Label();
            this.lblsHouse = new System.Windows.Forms.Label();
            this.txtHNumber = new System.Windows.Forms.TextBox();
            this.txtDistrict = new System.Windows.Forms.TextBox();
            this.txtStreetName = new System.Windows.Forms.TextBox();
            this.lblSellersCi = new System.Windows.Forms.Label();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.CircleProgress = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.btnExit = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnSave = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnEdit = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnAdd = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnDelete = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            ((System.ComponentModel.ISupportInitialize)(this.gridBuyers)).BeginInit();
            this.bunifuGradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gridBuyers
            // 
            this.gridBuyers.AllowUserToAddRows = false;
            this.gridBuyers.AllowUserToDeleteRows = false;
            this.gridBuyers.AllowUserToResizeColumns = false;
            this.gridBuyers.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.gridBuyers.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gridBuyers.BackgroundColor = System.Drawing.Color.White;
            this.gridBuyers.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gridBuyers.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.LightSkyBlue;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridBuyers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gridBuyers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridBuyers.DoubleBuffered = true;
            this.gridBuyers.EnableHeadersVisualStyles = false;
            this.gridBuyers.HeaderBgColor = System.Drawing.Color.White;
            this.gridBuyers.HeaderForeColor = System.Drawing.Color.LightSkyBlue;
            this.gridBuyers.Location = new System.Drawing.Point(16, 43);
            this.gridBuyers.Margin = new System.Windows.Forms.Padding(4);
            this.gridBuyers.Name = "gridBuyers";
            this.gridBuyers.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.gridBuyers.Size = new System.Drawing.Size(787, 169);
            this.gridBuyers.TabIndex = 19;
            this.gridBuyers.DoubleClick += new System.EventHandler(this.gridBuyers_DoubleClick);
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 20;
            this.bunifuElipse1.TargetControl = this;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(338, 9);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(150, 19);
            this.lblTitle.TabIndex = 20;
            this.lblTitle.Text = "Buyers Management";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.BackColor = System.Drawing.Color.Transparent;
            this.lblStatus.Location = new System.Drawing.Point(4, 367);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(107, 17);
            this.lblStatus.TabIndex = 31;
            this.lblStatus.Text = "Buyer\'s Budget :";
            // 
            // lblSal
            // 
            this.lblSal.AutoSize = true;
            this.lblSal.BackColor = System.Drawing.Color.Transparent;
            this.lblSal.Location = new System.Drawing.Point(4, 333);
            this.lblSal.Name = "lblSal";
            this.lblSal.Size = new System.Drawing.Size(101, 17);
            this.lblSal.TabIndex = 30;
            this.lblSal.Text = "Buyer\'s Credit :";
            // 
            // lblPosition
            // 
            this.lblPosition.AutoSize = true;
            this.lblPosition.BackColor = System.Drawing.Color.Transparent;
            this.lblPosition.Location = new System.Drawing.Point(4, 298);
            this.lblPosition.Name = "lblPosition";
            this.lblPosition.Size = new System.Drawing.Size(87, 17);
            this.lblPosition.TabIndex = 29;
            this.lblPosition.Text = "Buyer\'s Age :";
            // 
            // lblBirth
            // 
            this.lblBirth.AutoSize = true;
            this.lblBirth.BackColor = System.Drawing.Color.Transparent;
            this.lblBirth.Location = new System.Drawing.Point(4, 267);
            this.lblBirth.Name = "lblBirth";
            this.lblBirth.Size = new System.Drawing.Size(120, 17);
            this.lblBirth.TabIndex = 28;
            this.lblBirth.Text = "Buyer\'s BirthDate :";
            // 
            // lnlEmpName
            // 
            this.lnlEmpName.AutoSize = true;
            this.lnlEmpName.BackColor = System.Drawing.Color.Transparent;
            this.lnlEmpName.Location = new System.Drawing.Point(4, 230);
            this.lnlEmpName.Name = "lnlEmpName";
            this.lnlEmpName.Size = new System.Drawing.Size(101, 17);
            this.lnlEmpName.TabIndex = 27;
            this.lnlEmpName.Text = "Buyer\'s Name :";
            // 
            // datBirthdate
            // 
            this.datBirthdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datBirthdate.Location = new System.Drawing.Point(297, 260);
            this.datBirthdate.Name = "datBirthdate";
            this.datBirthdate.Size = new System.Drawing.Size(116, 23);
            this.datBirthdate.TabIndex = 23;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(296, 227);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(116, 23);
            this.txtName.TabIndex = 21;
            // 
            // txtAge
            // 
            this.txtAge.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAge.Location = new System.Drawing.Point(297, 295);
            this.txtAge.Margin = new System.Windows.Forms.Padding(4);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(34, 23);
            this.txtAge.TabIndex = 33;
            // 
            // cboCredit
            // 
            this.cboCredit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCredit.FormattingEnabled = true;
            this.cboCredit.Items.AddRange(new object[] {
            "Good",
            "Poor"});
            this.cboCredit.Location = new System.Drawing.Point(297, 330);
            this.cboCredit.Name = "cboCredit";
            this.cboCredit.Size = new System.Drawing.Size(115, 25);
            this.cboCredit.TabIndex = 34;
            // 
            // txtBudget
            // 
            this.txtBudget.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBudget.Location = new System.Drawing.Point(297, 364);
            this.txtBudget.Margin = new System.Windows.Forms.Padding(4);
            this.txtBudget.Name = "txtBudget";
            this.txtBudget.Size = new System.Drawing.Size(116, 23);
            this.txtBudget.TabIndex = 35;
            // 
            // cboAgent
            // 
            this.cboAgent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboAgent.FormattingEnabled = true;
            this.cboAgent.Location = new System.Drawing.Point(619, 364);
            this.cboAgent.Name = "cboAgent";
            this.cboAgent.Size = new System.Drawing.Size(112, 25);
            this.cboAgent.TabIndex = 43;
            // 
            // lblRegAge
            // 
            this.lblRegAge.AutoSize = true;
            this.lblRegAge.Location = new System.Drawing.Point(456, 367);
            this.lblRegAge.Name = "lblRegAge";
            this.lblRegAge.Size = new System.Drawing.Size(100, 17);
            this.lblRegAge.TabIndex = 42;
            this.lblRegAge.Text = "Buyer\'s Agent :";
            // 
            // lblDistrict
            // 
            this.lblDistrict.AutoSize = true;
            this.lblDistrict.Location = new System.Drawing.Point(457, 298);
            this.lblDistrict.Name = "lblDistrict";
            this.lblDistrict.Size = new System.Drawing.Size(104, 17);
            this.lblDistrict.TabIndex = 41;
            this.lblDistrict.Text = "Buyer\'s District :";
            // 
            // lblsStreet
            // 
            this.lblsStreet.AutoSize = true;
            this.lblsStreet.Location = new System.Drawing.Point(456, 267);
            this.lblsStreet.Name = "lblsStreet";
            this.lblsStreet.Size = new System.Drawing.Size(141, 17);
            this.lblsStreet.TabIndex = 40;
            this.lblsStreet.Text = "Buyer\'s Street Name :";
            // 
            // lblsHouse
            // 
            this.lblsHouse.AutoSize = true;
            this.lblsHouse.Location = new System.Drawing.Point(456, 230);
            this.lblsHouse.Name = "lblsHouse";
            this.lblsHouse.Size = new System.Drawing.Size(156, 17);
            this.lblsHouse.TabIndex = 39;
            this.lblsHouse.Text = "Buyer\'s House Number :";
            this.lblsHouse.Click += new System.EventHandler(this.lblsHouse_Click);
            // 
            // txtHNumber
            // 
            this.txtHNumber.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.txtHNumber.Location = new System.Drawing.Point(619, 227);
            this.txtHNumber.Margin = new System.Windows.Forms.Padding(4);
            this.txtHNumber.Name = "txtHNumber";
            this.txtHNumber.Size = new System.Drawing.Size(112, 24);
            this.txtHNumber.TabIndex = 38;
            // 
            // txtDistrict
            // 
            this.txtDistrict.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.txtDistrict.Location = new System.Drawing.Point(619, 295);
            this.txtDistrict.Margin = new System.Windows.Forms.Padding(4);
            this.txtDistrict.Name = "txtDistrict";
            this.txtDistrict.Size = new System.Drawing.Size(112, 24);
            this.txtDistrict.TabIndex = 37;
            // 
            // txtStreetName
            // 
            this.txtStreetName.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.txtStreetName.Location = new System.Drawing.Point(619, 264);
            this.txtStreetName.Margin = new System.Windows.Forms.Padding(4);
            this.txtStreetName.Name = "txtStreetName";
            this.txtStreetName.Size = new System.Drawing.Size(112, 24);
            this.txtStreetName.TabIndex = 36;
            // 
            // lblSellersCi
            // 
            this.lblSellersCi.AutoSize = true;
            this.lblSellersCi.Location = new System.Drawing.Point(457, 333);
            this.lblSellersCi.Name = "lblSellersCi";
            this.lblSellersCi.Size = new System.Drawing.Size(86, 17);
            this.lblSellersCi.TabIndex = 45;
            this.lblSellersCi.Text = "Buyer\'s City :";
            // 
            // txtCity
            // 
            this.txtCity.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.txtCity.Location = new System.Drawing.Point(619, 326);
            this.txtCity.Margin = new System.Windows.Forms.Padding(4);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(112, 24);
            this.txtCity.TabIndex = 44;
            // 
            // CircleProgress
            // 
            this.CircleProgress.animated = true;
            this.CircleProgress.animationIterval = 2;
            this.CircleProgress.animationSpeed = 10;
            this.CircleProgress.BackColor = System.Drawing.Color.White;
            this.CircleProgress.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("CircleProgress.BackgroundImage")));
            this.CircleProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CircleProgress.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.CircleProgress.LabelVisible = true;
            this.CircleProgress.LineProgressThickness = 4;
            this.CircleProgress.LineThickness = 4;
            this.CircleProgress.Location = new System.Drawing.Point(310, 94);
            this.CircleProgress.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.CircleProgress.MaxValue = 100;
            this.CircleProgress.Name = "CircleProgress";
            this.CircleProgress.ProgressBackColor = System.Drawing.Color.Red;
            this.CircleProgress.ProgressColor = System.Drawing.Color.DeepSkyBlue;
            this.CircleProgress.Size = new System.Drawing.Size(118, 118);
            this.CircleProgress.TabIndex = 46;
            this.CircleProgress.Value = 0;
            // 
            // timer
            // 
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // btnExit
            // 
            this.btnExit.ActiveBorderThickness = 1;
            this.btnExit.ActiveCornerRadius = 10;
            this.btnExit.ActiveFillColor = System.Drawing.Color.DeepSkyBlue;
            this.btnExit.ActiveForecolor = System.Drawing.Color.White;
            this.btnExit.ActiveLineColor = System.Drawing.Color.Red;
            this.btnExit.BackColor = System.Drawing.Color.White;
            this.btnExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnExit.BackgroundImage")));
            this.btnExit.ButtonText = "X";
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnExit.IdleBorderThickness = 1;
            this.btnExit.IdleCornerRadius = 20;
            this.btnExit.IdleFillColor = System.Drawing.Color.Transparent;
            this.btnExit.IdleForecolor = System.Drawing.Color.DeepSkyBlue;
            this.btnExit.IdleLineColor = System.Drawing.Color.DeepSkyBlue;
            this.btnExit.Location = new System.Drawing.Point(779, -2);
            this.btnExit.Margin = new System.Windows.Forms.Padding(6);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(40, 29);
            this.btnExit.TabIndex = 47;
            this.btnExit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.ActiveBorderThickness = 1;
            this.btnSave.ActiveCornerRadius = 20;
            this.btnSave.ActiveFillColor = System.Drawing.Color.DeepSkyBlue;
            this.btnSave.ActiveForecolor = System.Drawing.Color.White;
            this.btnSave.ActiveLineColor = System.Drawing.Color.Red;
            this.btnSave.BackColor = System.Drawing.Color.White;
            this.btnSave.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSave.BackgroundImage")));
            this.btnSave.ButtonText = "Save";
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnSave.IdleBorderThickness = 1;
            this.btnSave.IdleCornerRadius = 20;
            this.btnSave.IdleFillColor = System.Drawing.Color.White;
            this.btnSave.IdleForecolor = System.Drawing.Color.DeepSkyBlue;
            this.btnSave.IdleLineColor = System.Drawing.Color.DeepSkyBlue;
            this.btnSave.Location = new System.Drawing.Point(711, 397);
            this.btnSave.Margin = new System.Windows.Forms.Padding(5);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(94, 40);
            this.btnSave.TabIndex = 50;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.ActiveBorderThickness = 1;
            this.btnEdit.ActiveCornerRadius = 20;
            this.btnEdit.ActiveFillColor = System.Drawing.Color.DeepSkyBlue;
            this.btnEdit.ActiveForecolor = System.Drawing.Color.White;
            this.btnEdit.ActiveLineColor = System.Drawing.Color.Red;
            this.btnEdit.BackColor = System.Drawing.Color.White;
            this.btnEdit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEdit.BackgroundImage")));
            this.btnEdit.ButtonText = "Edit";
            this.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdit.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnEdit.IdleBorderThickness = 1;
            this.btnEdit.IdleCornerRadius = 20;
            this.btnEdit.IdleFillColor = System.Drawing.Color.White;
            this.btnEdit.IdleForecolor = System.Drawing.Color.DeepSkyBlue;
            this.btnEdit.IdleLineColor = System.Drawing.Color.DeepSkyBlue;
            this.btnEdit.Location = new System.Drawing.Point(111, 397);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(5);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(94, 40);
            this.btnEdit.TabIndex = 49;
            this.btnEdit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.ActiveBorderThickness = 1;
            this.btnAdd.ActiveCornerRadius = 20;
            this.btnAdd.ActiveFillColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAdd.ActiveForecolor = System.Drawing.Color.White;
            this.btnAdd.ActiveLineColor = System.Drawing.Color.Red;
            this.btnAdd.BackColor = System.Drawing.Color.White;
            this.btnAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAdd.BackgroundImage")));
            this.btnAdd.ButtonText = "Add";
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnAdd.IdleBorderThickness = 1;
            this.btnAdd.IdleCornerRadius = 20;
            this.btnAdd.IdleFillColor = System.Drawing.Color.White;
            this.btnAdd.IdleForecolor = System.Drawing.Color.DeepSkyBlue;
            this.btnAdd.IdleLineColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAdd.Location = new System.Drawing.Point(7, 397);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(5);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(94, 40);
            this.btnAdd.TabIndex = 48;
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.ActiveBorderThickness = 1;
            this.btnDelete.ActiveCornerRadius = 20;
            this.btnDelete.ActiveFillColor = System.Drawing.Color.DeepSkyBlue;
            this.btnDelete.ActiveForecolor = System.Drawing.Color.White;
            this.btnDelete.ActiveLineColor = System.Drawing.Color.Red;
            this.btnDelete.BackColor = System.Drawing.Color.White;
            this.btnDelete.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDelete.BackgroundImage")));
            this.btnDelete.ButtonText = "Delete";
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnDelete.IdleBorderThickness = 1;
            this.btnDelete.IdleCornerRadius = 20;
            this.btnDelete.IdleFillColor = System.Drawing.Color.White;
            this.btnDelete.IdleForecolor = System.Drawing.Color.DeepSkyBlue;
            this.btnDelete.IdleLineColor = System.Drawing.Color.DeepSkyBlue;
            this.btnDelete.Location = new System.Drawing.Point(388, 397);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(5);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(94, 40);
            this.btnDelete.TabIndex = 51;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.lblTitle);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.Red;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Azure;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.White;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(819, 36);
            this.bunifuGradientPanel1.TabIndex = 52;
            // 
            // frmBuyers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(819, 454);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.CircleProgress);
            this.Controls.Add(this.lblSellersCi);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.cboAgent);
            this.Controls.Add(this.lblRegAge);
            this.Controls.Add(this.lblDistrict);
            this.Controls.Add(this.lblsStreet);
            this.Controls.Add(this.lblsHouse);
            this.Controls.Add(this.txtHNumber);
            this.Controls.Add(this.txtDistrict);
            this.Controls.Add(this.txtStreetName);
            this.Controls.Add(this.txtBudget);
            this.Controls.Add(this.cboCredit);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblSal);
            this.Controls.Add(this.lblPosition);
            this.Controls.Add(this.lblBirth);
            this.Controls.Add(this.lnlEmpName);
            this.Controls.Add(this.datBirthdate);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.gridBuyers);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmBuyers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmBuyers";
            this.Load += new System.EventHandler(this.frmBuyers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridBuyers)).EndInit();
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuCustomDataGrid gridBuyers;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblSal;
        private System.Windows.Forms.Label lblPosition;
        private System.Windows.Forms.Label lblBirth;
        private System.Windows.Forms.Label lnlEmpName;
        private System.Windows.Forms.DateTimePicker datBirthdate;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtBudget;
        private System.Windows.Forms.ComboBox cboCredit;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.ComboBox cboAgent;
        private System.Windows.Forms.Label lblRegAge;
        private System.Windows.Forms.Label lblDistrict;
        private System.Windows.Forms.Label lblsStreet;
        private System.Windows.Forms.Label lblsHouse;
        private System.Windows.Forms.TextBox txtHNumber;
        private System.Windows.Forms.TextBox txtDistrict;
        private System.Windows.Forms.TextBox txtStreetName;
        private System.Windows.Forms.Label lblSellersCi;
        private System.Windows.Forms.TextBox txtCity;
        private Bunifu.Framework.UI.BunifuCircleProgressbar CircleProgress;
        private System.Windows.Forms.Timer timer;
        private Bunifu.Framework.UI.BunifuThinButton2 btnExit;
        private Bunifu.Framework.UI.BunifuThinButton2 btnSave;
        private Bunifu.Framework.UI.BunifuThinButton2 btnEdit;
        private Bunifu.Framework.UI.BunifuThinButton2 btnAdd;
        private Bunifu.Framework.UI.BunifuThinButton2 btnDelete;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
    }
}
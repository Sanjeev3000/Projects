﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using prjRemax.Bus;
using prjRemax.Data;

namespace prjRemax.GUI
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }
        
        DataTable tbEmployees;
        public static bool LoginStatus;
        private void frmMain_Load(object sender, EventArgs e)
        {
            tbEmployees = DataBase.mySet.Tables["Employees"];
            if (CurrentUser.UserType.ToString()!=Positions.Admin.ToString())
            {
                EmployeesMenu.Visible = false;
            }
            

                actionsMenu.Text = CurrentUser.UserType;
                lblUserName.Text = "User: " + CurrentUser.Name;
            
            if (CurrentUser.UserType=="Guest")
            {
               
                EmployeesMenu.Visible = false;
                AgentsMenu.Visible = false;
                buyersmenu.Visible = false;
                mnuSellers.Visible = false;

            }
        }

     
        private void ExitMenu_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Are you sure?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                this.Dispose();
                frmLogin Login = new frmLogin();
                Login.Show();
            }
        }

        private void EmployeesMenu_Click(object sender, EventArgs e)
        {
            frmEmployees empfrm = new frmEmployees();
            empfrm.MdiParent = this;
            empfrm.Show();
           
        }

        private void AgentsMenu_Click(object sender, EventArgs e)
        {
            
        }

        private void Housesmenu_Click(object sender, EventArgs e)
        {
            frmHouses housefrm = new frmHouses();
            housefrm.MdiParent = this;
            housefrm.Show();
        }

        private void mnuSellers_Click(object sender, EventArgs e)
        {
            frmSellers sellerfrm = new frmSellers();
            sellerfrm.MdiParent = this;
            sellerfrm.Show();
        }

        private void bunifuGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblUserName_Click(object sender, EventArgs e)
        {

        }

        private void buyersmenu_Click(object sender, EventArgs e)
        {
            frmBuyers by = new frmBuyers();
            by.MdiParent = this;
            by.Show();
        }

        private void Searchmnu_Click(object sender, EventArgs e)
        {
            frmSearch s = new frmSearch();
            s.MdiParent = this;
            s.Show();
        }
    }
}

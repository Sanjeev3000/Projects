﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using prjRemax.Bus;
using prjRemax.Data;
using System.Data.OleDb;

namespace prjRemax.GUI
{
    public partial class frmSellers : Form
    {
        public frmSellers()
        {
            InitializeComponent();
        }
        public List<Seller> listOfSellers = new List<Seller>();
        string mode;
        DataTable tbSellers;
        private void ButtonControls(bool add, bool edit, bool save)
        {
            btnAdd.Visible = add;
            btnEdit.Visible = edit;
            btnSave.Visible = save;
        }
        private void visible(bool name,bool age,bool date,bool hn,bool s,bool d,bool c,bool refa)
        {
            txtAge.Enabled = age;
            txtName.Enabled = name;
            txtHNumber.Enabled = hn;
            txtStreetName.Enabled = s;
            txtDistrict.Enabled = d;
            txtCity.Enabled = c;
            datBirthdate.Enabled = date;
            cboAgent.Enabled = refa;



        }
        private void frmSellers_Load(object sender, EventArgs e)
        {


            listOfSellers = List.GetListSellerSpecificAgent();
            if (CurrentUser.UserType!=Positions.Admin.ToString())
            {
                cboAgent.Visible = false;
                lblRegAge.Visible = false;
            }
            gridSellers.Visible = false;
            timer.Start();
            cboAgent.DisplayMember = "Names";
            cboAgent.ValueMember = "ID";
            cboAgent.DataSource = (from agent in DataBase.mySet.Tables["Employees"].AsEnumerable() where (agent.Field<string>("EmployeePosition") == Positions.Agent.ToString()) select new { Names = agent.Field<string>("EmployeeName"), ID = agent.Field<int>("ID") }).ToList();
            tbSellers = DataBase.mySet.Tables["Sellers"];
            gridSellers.DataSource = listOfSellers;
            GridControls();

            ButtonControls(true, true, false);
            visible(false, false, false, false, false, false, false, false);

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Are you sure?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }
        int i;
        private void timer_Tick(object sender, EventArgs e)
        {
            i += 25;
            CircleProgress.Value = i;
            if (CircleProgress.Value == 100)
            {
                timer.Stop();
                CircleProgress.Visible = false;
                gridSellers.Visible = true;
            }
        }

        private void cboAgent_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtAge.Clear();
            txtCity.Clear();
            txtDistrict.Clear();
            txtHNumber.Clear();
            txtName.Clear();
            txtStreetName.Clear();
            datBirthdate.Value = DateTime.Now;
            cboAgent.Text = "";
            mode = "ADD";
            ButtonControls(false, false, true);
            visible(true, true, true, true, true, true, true, true);
        }
        private bool IsValid()
        {
            return Validator.IsLetters(txtName) && Validator.IsPresent(txtName) && Validator.IsSpecialCharacters(txtName) && Validator.IsPresentDate(datBirthdate) && Validator.IsPresent(txtAge) && Validator.IsInt32(txtAge) && Validator.IsPresent(txtHNumber) && Validator.IsSpecialCharacters(txtHNumber) && Validator.IsPresent(txtStreetName) && Validator.IsSpecialCharacters(txtStreetName) && Validator.IsPresent(txtDistrict) && Validator.IsSpecialCharacters(txtDistrict) && Validator.IsPresent(txtCity) && Validator.IsSpecialCharacters(txtCity);
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            DataRow myRow = null;
            Seller aSeller;
            int current = 0;
            int ID = 0;
            if (mode == "ADD")
            {
                if (IsValid())
                {


                    myRow = tbSellers.NewRow();
                    tbSellers.Rows.Add(myRow);
                    if (CurrentUser.UserType == Positions.Admin.ToString())
                    {
                        aSeller = new Seller(txtName.Text, Int32.Parse(txtAge.Text), datBirthdate.Value, new Address(txtHNumber.Text, txtStreetName.Text, txtDistrict.Text, txtCity.Text), Int32.Parse(cboAgent.SelectedValue.ToString()), cboAgent.Text);
                    }
                    else
                    {
                        aSeller = new Seller(txtName.Text, Int32.Parse(txtAge.Text), datBirthdate.Value, new Address(txtHNumber.Text, txtStreetName.Text, txtDistrict.Text, txtCity.Text), CurrentUser.ID, CurrentUser.Name);
                    }
                    listOfSellers.Add(aSeller);
                    gridSellers.DataSource = null;
                    gridSellers.DataSource = listOfSellers;
                    GridControls();

                    foreach (Seller item in listOfSellers)
                    {
                        foreach (DataRow row in tbSellers.Rows)
                        {
                            if (row["ID"].ToString() == item.ID.ToString())
                            {
                                current++;
                            }

                        }
                    }
                    ID = current + 1;

                    listOfSellers[current].ID = ID;
                    myRow["SellerName"] = listOfSellers[current].Name;
                    myRow["SellerAge"] = listOfSellers[current].Age;
                    myRow["BirthDate"] = listOfSellers[current].BirthDate;
                    myRow["HouseNumber"] = listOfSellers[current].Address.HouseNumber;
                    myRow["StreetName"] = listOfSellers[current].Address.StreetName;
                    myRow["District"] = listOfSellers[current].Address.District;
                    myRow["City"] = listOfSellers[current].Address.City;
                    myRow["RefAgent"] = listOfSellers[current].RefAgent;
                    MessageBox.Show("Success");
                }
            }
            if (mode == "EDIT")
            {
                if (IsValid())
                {


                    current = gridSellers.CurrentRow.Index;

                    if (CurrentUser.UserType == Positions.Admin.ToString())
                    {

                        listOfSellers[current].Name = txtName.Text;
                        listOfSellers[current].Age = Int32.Parse(txtAge.Text);
                        listOfSellers[current].BirthDate = datBirthdate.Value;
                        listOfSellers[current].Address.HouseNumber = txtHNumber.Text;
                        listOfSellers[current].Address.StreetName = txtStreetName.Text;
                        listOfSellers[current].Address.District = txtDistrict.Text;
                        listOfSellers[current].Address.City = txtCity.Text;
                        listOfSellers[current].RefAgent = Int32.Parse(cboAgent.SelectedValue.ToString());
                        listOfSellers[current].AgentName = cboAgent.Text;
                        myRow = tbSellers.Rows[current];

                        myRow["SellerName"] = listOfSellers[current].Name;
                        myRow["SellerAge"] = listOfSellers[current].Age;
                        myRow["BirthDate"] = listOfSellers[current].BirthDate;
                        myRow["HouseNumber"] = listOfSellers[current].Address.HouseNumber;
                        myRow["StreetName"] = listOfSellers[current].Address.StreetName;
                        myRow["District"] = listOfSellers[current].Address.District;
                        myRow["City"] = listOfSellers[current].Address.City;
                        myRow["RefAgent"] = listOfSellers[current].RefAgent;

                        gridSellers.DataSource = null;
                        gridSellers.DataSource = listOfSellers;
                        GridControls();

                    }
                    if (CurrentUser.UserType != Positions.Admin.ToString())
                    {
                        current = 0;
                        current = gridSellers.CurrentRow.Index;

                        listOfSellers[current].Name = txtName.Text;
                        listOfSellers[current].Age = Int32.Parse(txtAge.Text);
                        listOfSellers[current].BirthDate = datBirthdate.Value;
                        listOfSellers[current].Address.HouseNumber = txtHNumber.Text;
                        listOfSellers[current].Address.StreetName = txtStreetName.Text;
                        listOfSellers[current].Address.District = txtDistrict.Text;
                        listOfSellers[current].Address.City = txtCity.Text;
                        listOfSellers[current].RefAgent = Int32.Parse(cboAgent.SelectedValue.ToString());

                        DataRow[] Rows = tbSellers.Select("ID=" + listOfSellers[current].ID);
                        myRow = Rows[0];
                        myRow["SellerName"] = listOfSellers[current].Name;
                        myRow["SellerAge"] = listOfSellers[current].Age;
                        myRow["BirthDate"] = listOfSellers[current].BirthDate;
                        myRow["HouseNumber"] = listOfSellers[current].Address.HouseNumber;
                        myRow["StreetName"] = listOfSellers[current].Address.StreetName;
                        myRow["District"] = listOfSellers[current].Address.District;
                        myRow["City"] = listOfSellers[current].Address.City;
                        myRow["RefAgent"] = listOfSellers[current].RefAgent;



                        gridSellers.DataSource = null;
                        gridSellers.DataSource = listOfSellers;
                        GridControls();

                    }
                    MessageBox.Show("Done");
                }
            }
            OleDbCommandBuilder myBuild = new OleDbCommandBuilder(DataBase.adpSellers);
            DataBase.adpSellers.Update(tbSellers);
            current = 0;
            ID = 0;
            DataBase.mySet.Tables["Sellers"].Reset();
            DataBase.adpSellers.Fill(DataBase.mySet, "Sellers");
            ButtonControls(true, true, false);
            visible(false, false, false, false, false, false, false, false);
            MessageBox.Show("Success");

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            txtName.Focus();
            mode = "EDIT";
            ButtonControls(false, false, true);
            visible(true, true, true, true, true, true, true, true);


        }
        private void GRID2TXT()
        {
            txtName.Text = gridSellers.CurrentRow.Cells[3].Value.ToString();
            txtAge.Text = gridSellers.CurrentRow.Cells[4].Value.ToString();
            datBirthdate.Value = DateTime.Parse(gridSellers.CurrentRow.Cells[5].Value.ToString());
            txtHNumber.Text = listOfSellers[gridSellers.CurrentRow.Index].Address.HouseNumber;
            txtStreetName.Text = listOfSellers[gridSellers.CurrentRow.Index].Address.StreetName;
            txtDistrict.Text = listOfSellers[gridSellers.CurrentRow.Index].Address.District;
            txtCity.Text = listOfSellers[gridSellers.CurrentRow.Index].Address.City;
            cboAgent.Text = gridSellers.CurrentRow.Cells[1].Value.ToString();
        }
        private void GridControls()
        {
            gridSellers.DataSource = listOfSellers;
            gridSellers.Columns[0].HeaderText = "Agent Reference Number";
            gridSellers.Columns[1].HeaderText = "Agent Name";
            gridSellers.Columns[2].HeaderText = "Seller's Reference Number";
            gridSellers.Columns[3].HeaderText = "Name";
            gridSellers.Columns[4].HeaderText = "Age";
            gridSellers.Columns[5].HeaderText = "BirthDate";
            gridSellers.Columns[6].HeaderText = "Address";
        }
        private void gridSellers_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
            GRID2TXT();
        }

        private void gridSellers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int current = gridSellers.CurrentRow.Index;
            if (CurrentUser.UserType == Positions.Admin.ToString())
            {


                if (MessageBox.Show(this, "Do you want to remove the Seller: " + tbSellers.Rows[current]["SellerName"].ToString() + "?", "Removal", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    tbSellers.Rows[current].Delete();
                    listOfSellers.RemoveAt(current);
                    gridSellers.DataSource = null;
                    gridSellers.DataSource = listOfSellers;
                    GridControls();

                }
            }
            else
            {
                if (MessageBox.Show(this, "Do you want to remove the seller: " + gridSellers.CurrentRow.Cells[3].Value.ToString() + "?", "Removal", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    DataRow[] rows = tbSellers.Select("ID=" + gridSellers.CurrentRow.Cells[2].Value);

                    rows[0].Delete();
                    listOfSellers.RemoveAt(current);
                    gridSellers.DataSource = null;
                    gridSellers.DataSource = listOfSellers;
                    GridControls();

                }
            }
            OleDbCommandBuilder myBuild = new OleDbCommandBuilder(DataBase.adpSellers);
            DataBase.adpSellers.Update(tbSellers);

            DataBase.mySet.Tables["Sellers"].Reset();
            DataBase.adpSellers.Fill(DataBase.mySet, "Sellers");
        }
    
    }
}

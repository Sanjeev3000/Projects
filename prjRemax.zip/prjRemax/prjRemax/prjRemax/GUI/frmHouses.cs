﻿using prjRemax.Bus;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using prjRemax.Data;
using System.Data.OleDb;

namespace prjRemax.GUI
{
    public partial class frmHouses : Form
    {
        public frmHouses()
        {
            InitializeComponent();
        }
      
        public List<House> listOfHouses = new List<House>();
        string mode;
        DataTable tbHouse;
        DataTable tbSellers;
        
        private void Grid2TXT()
        {
           
            txtYearBuilt.Text = gridHouses.CurrentRow.Cells[0].Value.ToString();
            txtArea.Text = gridHouses.CurrentRow.Cells[1].Value.ToString();
            txtHouseNum.Text = listOfHouses[gridHouses.CurrentRow.Index].Address.HouseNumber;
            txtStreetName.Text = listOfHouses[gridHouses.CurrentRow.Index].Address.StreetName;
            txtDistrict.Text = listOfHouses[gridHouses.CurrentRow.Index].Address.District;
            txtCity.Text = listOfHouses[gridHouses.CurrentRow.Index].Address.City;
            txtPrice.Text = gridHouses.CurrentRow.Cells[3].Value.ToString();
            RTxtDescription.Text = gridHouses.CurrentRow.Cells[4].Value.ToString();
           cboSellers .Text = gridHouses.CurrentRow.Cells[5].Value.ToString();
           cboAgents .Text = gridHouses.CurrentRow.Cells[6].Value.ToString();






        }
        private void Visibility(bool year,bool area,bool ho,bool str,bool dis,bool city,bool fp,bool descp,bool sell,bool ag)
        {
            txtYearBuilt.Enabled = year;
            txtArea.Enabled = area;
            txtHouseNum.Enabled = ho;
            txtStreetName.Enabled = str;
            txtDistrict.Enabled = dis;
            txtCity.Enabled = city;
            txtPrice.Enabled = fp;
            RTxtDescription.Enabled = descp;
            cboSellers.Enabled = sell;
            cboAgents.Enabled = ag;
                


        }
        private void ButtonControls(bool add,bool edit,bool save)
        {
            btnAdd.Visible = add;
            btnEdit.Visible = edit;
            btnSave.Visible = save;
        }
        private void frmHouses_Load(object sender, EventArgs e)
        {
            timer.Start();
            gridHouses.Visible = false;
            tbHouse = DataBase.mySet.Tables["Houses"];
            tbSellers = DataBase.mySet.Tables["Sellers"];
            cboAgents.Visible = false;
            lblAgents.Visible = false;
            listOfHouses = List.GetListHousesSpecifiedAgent();
            List<Employee> tmp = List.GetList();
            var FindAgents = from agent in tmp where (agent.EmployeePosition==Positions.Agent.ToString()) select  new { Names = agent.EmployeeName, ID = agent.ID };
            var FindSellers = from DataRow Sellers in tbSellers.Rows select new { ID = Sellers.Field<int>("ID"), Names = Sellers.Field<string>("SellerName") };
            if (CurrentUser.UserType == Positions.Admin.ToString())
            {
                lblAgents.Visible = true;
                cboAgents.Visible = true;
                cboAgents.DisplayMember = "Names";
                cboAgents.ValueMember = "ID";
                cboAgents.DataSource = FindAgents.ToList();
            }
            
            cboSellers.DisplayMember = "Names";
            cboSellers.ValueMember = "ID";
            cboSellers.DataSource = FindSellers.ToList();
            gridHouses.DataSource = listOfHouses;
            GridControls();
            Visibility(false, false, false, false, false, false, false, true, false,false);
            RTxtDescription.ReadOnly = true;
            ButtonControls(true, true, false);
        }
        private void GridControls()
        {
            gridHouses.DataSource = listOfHouses;
            gridHouses.Columns[0].HeaderText = "Year Built";
            gridHouses.Columns[1].HeaderText = "Living Area in SF";
            gridHouses.Columns[2].HeaderText = "Location";
            gridHouses.Columns[3].HeaderText = "Final Price";
            gridHouses.Columns[4].HeaderText = "Description";
            gridHouses.Columns[5].HeaderText = "Seller's Name";
            gridHouses.Columns[6].HeaderText = "Real Estate Agent's Name";
            gridHouses.Columns[7].HeaderText = "House Reference ID";
            gridHouses.Columns[8].HeaderText = "Real Estate Agent's Reference Number";
            gridHouses.Columns[9].HeaderText = "Seller's Identification Number";
            

        }
       
        private void gridHouses_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }
        int i = 0;
        private void timer_Tick(object sender, EventArgs e)
        {
            i += 25;
            CircleProgress.Value = i;
            if (CircleProgress.Value==100)
            {
                timer.Stop();
                CircleProgress.Visible = false;
                gridHouses.Visible = true;
            }
        }

     
        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Are you sure?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                listOfHouses.Clear();
                this.Close();
            }
        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {

            txtYearBuilt.Text = "";
            txtStreetName.Text = "";
            txtPrice.Text = "";
            txtHouseNum.Text = "";
            txtDistrict.Text = "";
            txtCity.Text = "";
            txtArea.Text = "";
            RTxtDescription.Text = "";
            mode = "Add";
            Visibility(true, true, true, true, true, true, true, true, true, true);
            ButtonControls(false, false, true);
            RTxtDescription.ReadOnly = false;
        }
        private bool IsValid()
        {
            return Validator.IsPresent(txtYearBuilt) && Validator.IsRightNumber(txtYearBuilt) && Validator.IsInt32(txtYearBuilt) && Validator.IsPresent(txtArea) && Validator.IsFloat(txtArea) && Validator.IsPresent(txtHouseNum) && Validator.IsSpecialCharacters(txtHouseNum) && Validator.IsPresent(txtStreetName) && Validator.IsSpecialCharacters(txtStreetName) && Validator.IsPresent(txtDistrict) && Validator.IsSpecialCharacters(txtDistrict) && Validator.IsPresent(txtCity) && Validator.IsSpecialCharacters(txtCity) && Validator.IsFloat(txtPrice) && Validator.IsPresent(txtPrice) && Validator.IsPresentRichTxt(RTxtDescription);
        }
        private void btnSave_Click_1(object sender, EventArgs e)
        {
            int current = 0;
            int ID = 0;
            DataRow NewRow = null;
            House aHouse;
            
            if (mode == "Add")
            {
                if (IsValid())
                {


                    NewRow = tbHouse.NewRow();
                    tbHouse.Rows.Add(NewRow);
                    if (CurrentUser.UserType == Positions.Admin.ToString())
                    {
                        aHouse = new House(Int32.Parse(txtYearBuilt.Text), float.Parse(txtArea.Text), new Address(txtHouseNum.Text, txtStreetName.Text, txtDistrict.Text, txtCity.Text), float.Parse(txtPrice.Text), RTxtDescription.Text, cboAgents.Text, cboSellers.Text, Int32.Parse(cboAgents.SelectedValue.ToString()), Int32.Parse(cboSellers.SelectedValue.ToString()));
                    }
                    else
                    {
                        aHouse = new House(Int32.Parse(txtYearBuilt.Text), float.Parse(txtArea.Text), new Address(txtHouseNum.Text, txtStreetName.Text, txtDistrict.Text, txtCity.Text), float.Parse(txtPrice.Text), RTxtDescription.Text, CurrentUser.Name, cboSellers.Text, CurrentUser.ID, Int32.Parse(cboSellers.SelectedValue.ToString()));

                    }
                    listOfHouses.Add(aHouse);
                    gridHouses.DataSource = null;
                    gridHouses.DataSource = listOfHouses;
                    GridControls();
                    foreach (House item in listOfHouses)
                    {
                        foreach (DataRow myRow in tbHouse.Rows)
                        {
                            if (myRow["ID"].ToString() == item.ID.ToString())
                            {
                                current++;

                            }
                        }
                    }
                    ID = current + 1;
                    listOfHouses[current].ID = ID;

                    NewRow["YearBuilt"] = listOfHouses[current].YearBuilt;
                    NewRow["LivingArea"] = listOfHouses[current].LivingArea;
                    NewRow["HouseNumber"] = listOfHouses[current].Address.HouseNumber;
                    NewRow["StreetName"] = listOfHouses[current].Address.StreetName;
                    NewRow["District"] = listOfHouses[current].Address.District;
                    NewRow["City"] = listOfHouses[current].Address.City;
                    NewRow["FinalPrice"] = listOfHouses[current].FinalPrice;
                    NewRow["Description"] = listOfHouses[current].Description;
                    NewRow["RefAgent"] = listOfHouses[current].RefAgentID;
                    NewRow["RefSeller"] = listOfHouses[current].RefSellerID;

                    MessageBox.Show("Success");
                }
            }

            if (mode == "Edit")
            {
                if (IsValid())
                {


                    current = gridHouses.CurrentRow.Index;
                    if (CurrentUser.UserType == Positions.Admin.ToString())
                    {
                        listOfHouses[current].YearBuilt = Int32.Parse(txtYearBuilt.Text);
                        listOfHouses[current].LivingArea = float.Parse(txtArea.Text);
                        listOfHouses[current].Address.HouseNumber = txtHouseNum.Text;
                        listOfHouses[current].Address.StreetName = txtStreetName.Text;
                        listOfHouses[current].Address.District = txtDistrict.Text;
                        listOfHouses[current].Address.City = txtCity.Text;
                        listOfHouses[current].FinalPrice = float.Parse(txtPrice.Text);
                        listOfHouses[current].Description = RTxtDescription.Text;
                        listOfHouses[current].RefAgent = cboAgents.Text;
                        listOfHouses[current].RefAgentID = Int32.Parse(cboAgents.SelectedValue.ToString());
                        listOfHouses[current].RefSeller = cboSellers.Text;
                        listOfHouses[current].RefSellerID = Int32.Parse(cboSellers.SelectedValue.ToString());

                        NewRow = tbHouse.Rows[current];
                        NewRow["YearBuilt"] = listOfHouses[current].YearBuilt;
                        NewRow["LivingArea"] = listOfHouses[current].LivingArea;
                        NewRow["HouseNumber"] = listOfHouses[current].Address.HouseNumber;
                        NewRow["StreetName"] = listOfHouses[current].Address.StreetName;
                        NewRow["District"] = listOfHouses[current].Address.District;
                        NewRow["City"] = listOfHouses[current].Address.City;
                        NewRow["FinalPrice"] = listOfHouses[current].FinalPrice;
                        NewRow["Description"] = listOfHouses[current].Description;
                        NewRow["RefAgent"] = listOfHouses[current].RefAgentID;
                        NewRow["RefSeller"] = listOfHouses[current].RefSellerID;
                        gridHouses.DataSource = null;
                        gridHouses.DataSource = listOfHouses;
                        GridControls();
                    }
                    if (CurrentUser.UserType != Positions.Admin.ToString())
                    {
                        current = 0;
                        current = gridHouses.CurrentRow.Index;
                        MessageBox.Show("Test");
                        listOfHouses[current].YearBuilt = Int32.Parse(txtYearBuilt.Text);
                        listOfHouses[current].LivingArea = float.Parse(txtArea.Text);
                        listOfHouses[current].Address.HouseNumber = txtHouseNum.Text;
                        listOfHouses[current].Address.StreetName = txtStreetName.Text;
                        listOfHouses[current].Address.District = txtDistrict.Text;
                        listOfHouses[current].Address.City = txtCity.Text;
                        listOfHouses[current].FinalPrice = float.Parse(txtPrice.Text);
                        listOfHouses[current].Description = RTxtDescription.Text;
                        listOfHouses[current].RefSeller = cboSellers.Text;
                        listOfHouses[current].RefSellerID = Int32.Parse(cboSellers.SelectedValue.ToString());

                        DataRow[] Rows = tbHouse.Select("ID=" + listOfHouses[current].ID);
                        NewRow = Rows[0];


                        NewRow["YearBuilt"] = listOfHouses[current].YearBuilt;
                        NewRow["LivingArea"] = listOfHouses[current].LivingArea;
                        NewRow["HouseNumber"] = listOfHouses[current].Address.HouseNumber;
                        NewRow["StreetName"] = listOfHouses[current].Address.StreetName;
                        NewRow["District"] = listOfHouses[current].Address.District;
                        NewRow["City"] = listOfHouses[current].Address.City;
                        NewRow["FinalPrice"] = listOfHouses[current].FinalPrice;
                        NewRow["Description"] = listOfHouses[current].Description;
                        NewRow["RefSeller"] = listOfHouses[current].RefSellerID;
                        gridHouses.DataSource = null;
                        gridHouses.DataSource = listOfHouses;
                        GridControls();
                    }

                    MessageBox.Show("Done");
                }

            }
            OleDbCommandBuilder myBuild = new OleDbCommandBuilder(DataBase.adpHouses);
            DataBase.adpHouses.Update(tbHouse);
            current = 0;
            ID = 0;
            DataBase.mySet.Tables["Houses"].Reset();
            DataBase.adpHouses.Fill(DataBase.mySet, "Houses");
            MessageBox.Show("Success");
            
            Visibility(false, false, false, false, false, false, false, false, false, false);
            ButtonControls(true, true, false);


        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            mode = "Edit";
            txtYearBuilt.Focus();
            Visibility(true, true, true, true, true, true, true, true, true, true);
            ButtonControls(false, false, true);
            RTxtDescription.ReadOnly = false;

        }

        private void gridHouses_CellDoubleClick_1(object sender, DataGridViewCellEventArgs e)
        {
            Grid2TXT();

        }

        private void gridHouses_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int current = gridHouses.CurrentRow.Index;
            if (CurrentUser.UserType == Positions.Admin.ToString())
            {


                if (MessageBox.Show(this, "Do you want to remove the House: " + tbHouse.Rows[current]["ID"].ToString() + "?", "Removal", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    tbHouse.Rows[current].Delete();
                    listOfHouses.RemoveAt(current);
                    gridHouses.DataSource = null;
                    gridHouses.DataSource = listOfHouses;
                    GridControls();

                }
            }
            else
            {
                if (MessageBox.Show(this, "Do you want to remove the buyer: " + gridHouses.CurrentRow.Cells[7].Value.ToString() + "?", "Removal", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    DataRow[] rows = tbHouse.Select("ID=" + gridHouses.CurrentRow.Cells[7].Value);

                    rows[0].Delete();
                    listOfHouses.RemoveAt(current);
                    gridHouses.DataSource = null;
                    gridHouses.DataSource = listOfHouses;
                    GridControls();

                }
            }
            OleDbCommandBuilder myBuild = new OleDbCommandBuilder(DataBase.adpHouses);
            DataBase.adpHouses.Update(tbHouse);

            DataBase.mySet.Tables["Houses"].Reset();
            DataBase.adpHouses.Fill(DataBase.mySet, "Houses");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using prjRemax.Data;
using prjRemax.Bus;
namespace prjRemax.GUI
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
           


        }
       
        DataTable tbUsers;
        private void Login()
        {
            bool found = false;
            foreach (DataRow myRow in tbUsers.Rows)
            {
                if (txtID.Text == myRow["ID"].ToString() && txtPassword.Text == myRow["PassWords"].ToString())
                {
                   
                    found = true;
                    CurrentUser.ID = Convert.ToInt32(txtID.Text);
                    CurrentUser.Password = txtPassword.Text;
                    CurrentUser.RefUsers = Convert.ToInt32(myRow["RefUsers"].ToString());

                    foreach (DataRow myRowE in DataBase.mySet.Tables["Employees"].Rows)
                    {
                        if (myRowE["ID"].ToString() == CurrentUser.RefUsers.ToString())
                        {
                            CurrentUser.Name = myRowE["EmployeeName"].ToString();
                            CurrentUser.UserType = myRowE["EmployeePosition"].ToString();
                            CurrentUser.ID = Int32.Parse(myRowE["ID"].ToString());

                        }
                    }


                    frmMain main = new frmMain();

                    main.Show();
                    this.Hide();
                   





                }
                
            }
            if (!found)
            {
                MessageBox.Show("Invalid User!");
            }

        }
        private void frmLogin_Load(object sender, EventArgs e)
        {
            DataBase.myCon = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\EventProgramming\prjRemax\prjRemax\prjRemax\bin\Debug\data\Remax.mdb");
            DataBase.myCon.Open();
            DataBase.mySet = new DataSet();
            OleDbCommand mycmd = new OleDbCommand("Select * From Users", DataBase.myCon);
            DataBase.adpUsers = new OleDbDataAdapter(mycmd);
            DataBase.adpUsers.Fill(DataBase.mySet, "Users");
            tbUsers = DataBase.mySet.Tables["Users"];
            OleDbCommand myCmd2 = new OleDbCommand("Select * From Employees", DataBase.myCon);
            DataBase.adpEmployees = new OleDbDataAdapter(myCmd2);
            DataBase.adpEmployees.Fill(DataBase.mySet, "Employees");
            OleDbCommand myCmd3 = new OleDbCommand("Select * From Houses", DataBase.myCon);
            DataBase.adpHouses = new OleDbDataAdapter(myCmd3);
            DataBase.adpHouses.Fill(DataBase.mySet, "Houses");
            OleDbCommand myCmd4 = new OleDbCommand("Select * From Sellers Order By ID", DataBase.myCon);
            DataBase.adpSellers = new OleDbDataAdapter(myCmd4);
            DataBase.adpSellers.Fill(DataBase.mySet, "Sellers");
            OleDbCommand myCmd5 = new OleDbCommand("Select * From Buyers", DataBase.myCon);
            DataBase.adpBuyers = new OleDbDataAdapter(myCmd5);
            DataBase.adpBuyers.Fill(DataBase.mySet, "Buyers");
            this.KeyPreview = true;
        }
      
      
       

     

       

        private void btnLogin_Click_1(object sender, EventArgs e)
        {
            
        }

      

        private void btnExit_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Are you sure?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Environment.Exit(0);
            }
        }

        private void btnLogin1_Click(object sender, EventArgs e)
        {
            Login();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            CurrentUser.Name = "Guest";
            CurrentUser.UserType = Positions.Guest.ToString();
            frmMain main = new frmMain();
            main.Show();
            this.Hide();
        }
    }
}

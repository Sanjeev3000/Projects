﻿namespace prjRemax.GUI
{
    partial class frmSellers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSellers));
            this.gridSellers = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.txtHNumber = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtDistrict = new System.Windows.Forms.TextBox();
            this.txtStreetName = new System.Windows.Forms.TextBox();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.grpSellers = new System.Windows.Forms.GroupBox();
            this.datBirthdate = new System.Windows.Forms.DateTimePicker();
            this.cboAgent = new System.Windows.Forms.ComboBox();
            this.lblRegAge = new System.Windows.Forms.Label();
            this.lblSellersCi = new System.Windows.Forms.Label();
            this.lblDistrict = new System.Windows.Forms.Label();
            this.lblsStreet = new System.Windows.Forms.Label();
            this.lblsHouse = new System.Windows.Forms.Label();
            this.lblSDate = new System.Windows.Forms.Label();
            this.lblSelAge = new System.Windows.Forms.Label();
            this.lblSellerName = new System.Windows.Forms.Label();
            this.btnSave = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnEdit = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnAdd = new Bunifu.Framework.UI.BunifuThinButton2();
            this.lblSubTitle = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnExit = new Bunifu.Framework.UI.BunifuThinButton2();
            this.CircleProgress = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.btnDelete = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            ((System.ComponentModel.ISupportInitialize)(this.gridSellers)).BeginInit();
            this.grpSellers.SuspendLayout();
            this.bunifuGradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gridSellers
            // 
            this.gridSellers.AllowUserToAddRows = false;
            this.gridSellers.AllowUserToDeleteRows = false;
            this.gridSellers.AllowUserToResizeColumns = false;
            this.gridSellers.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.gridSellers.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gridSellers.BackgroundColor = System.Drawing.Color.White;
            this.gridSellers.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gridSellers.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.LightSkyBlue;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gridSellers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gridSellers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridSellers.DoubleBuffered = true;
            this.gridSellers.EnableHeadersVisualStyles = false;
            this.gridSellers.HeaderBgColor = System.Drawing.Color.White;
            this.gridSellers.HeaderForeColor = System.Drawing.Color.LightSkyBlue;
            this.gridSellers.Location = new System.Drawing.Point(13, 322);
            this.gridSellers.Margin = new System.Windows.Forms.Padding(4);
            this.gridSellers.Name = "gridSellers";
            this.gridSellers.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.gridSellers.Size = new System.Drawing.Size(665, 201);
            this.gridSellers.TabIndex = 19;
            this.gridSellers.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridSellers_CellContentClick);
            this.gridSellers.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridSellers_CellDoubleClick);
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // txtHNumber
            // 
            this.txtHNumber.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHNumber.Location = new System.Drawing.Point(466, 30);
            this.txtHNumber.Margin = new System.Windows.Forms.Padding(4);
            this.txtHNumber.Name = "txtHNumber";
            this.txtHNumber.Size = new System.Drawing.Size(112, 27);
            this.txtHNumber.TabIndex = 26;
            // 
            // txtCity
            // 
            this.txtCity.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCity.Location = new System.Drawing.Point(169, 182);
            this.txtCity.Margin = new System.Windows.Forms.Padding(4);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(112, 27);
            this.txtCity.TabIndex = 25;
            // 
            // txtDistrict
            // 
            this.txtDistrict.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDistrict.Location = new System.Drawing.Point(466, 135);
            this.txtDistrict.Margin = new System.Windows.Forms.Padding(4);
            this.txtDistrict.Name = "txtDistrict";
            this.txtDistrict.Size = new System.Drawing.Size(112, 27);
            this.txtDistrict.TabIndex = 24;
            // 
            // txtStreetName
            // 
            this.txtStreetName.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStreetName.Location = new System.Drawing.Point(466, 82);
            this.txtStreetName.Margin = new System.Windows.Forms.Padding(4);
            this.txtStreetName.Name = "txtStreetName";
            this.txtStreetName.Size = new System.Drawing.Size(112, 27);
            this.txtStreetName.TabIndex = 23;
            // 
            // txtAge
            // 
            this.txtAge.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAge.Location = new System.Drawing.Point(169, 82);
            this.txtAge.Margin = new System.Windows.Forms.Padding(4);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(33, 27);
            this.txtAge.TabIndex = 21;
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(169, 30);
            this.txtName.Margin = new System.Windows.Forms.Padding(4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(112, 27);
            this.txtName.TabIndex = 20;
            // 
            // grpSellers
            // 
            this.grpSellers.Controls.Add(this.datBirthdate);
            this.grpSellers.Controls.Add(this.cboAgent);
            this.grpSellers.Controls.Add(this.lblRegAge);
            this.grpSellers.Controls.Add(this.lblSellersCi);
            this.grpSellers.Controls.Add(this.lblDistrict);
            this.grpSellers.Controls.Add(this.lblsStreet);
            this.grpSellers.Controls.Add(this.lblsHouse);
            this.grpSellers.Controls.Add(this.lblSDate);
            this.grpSellers.Controls.Add(this.lblSelAge);
            this.grpSellers.Controls.Add(this.lblSellerName);
            this.grpSellers.Controls.Add(this.txtCity);
            this.grpSellers.Controls.Add(this.txtHNumber);
            this.grpSellers.Controls.Add(this.txtName);
            this.grpSellers.Controls.Add(this.txtAge);
            this.grpSellers.Controls.Add(this.txtDistrict);
            this.grpSellers.Controls.Add(this.txtStreetName);
            this.grpSellers.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.grpSellers.Location = new System.Drawing.Point(13, 53);
            this.grpSellers.Margin = new System.Windows.Forms.Padding(4);
            this.grpSellers.Name = "grpSellers";
            this.grpSellers.Padding = new System.Windows.Forms.Padding(4);
            this.grpSellers.Size = new System.Drawing.Size(668, 216);
            this.grpSellers.TabIndex = 27;
            this.grpSellers.TabStop = false;
            // 
            // datBirthdate
            // 
            this.datBirthdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datBirthdate.Location = new System.Drawing.Point(169, 137);
            this.datBirthdate.Name = "datBirthdate";
            this.datBirthdate.Size = new System.Drawing.Size(112, 23);
            this.datBirthdate.TabIndex = 36;
            // 
            // cboAgent
            // 
            this.cboAgent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboAgent.FormattingEnabled = true;
            this.cboAgent.Location = new System.Drawing.Point(466, 186);
            this.cboAgent.Name = "cboAgent";
            this.cboAgent.Size = new System.Drawing.Size(112, 25);
            this.cboAgent.TabIndex = 35;
            this.cboAgent.SelectedIndexChanged += new System.EventHandler(this.cboAgent_SelectedIndexChanged);
            // 
            // lblRegAge
            // 
            this.lblRegAge.AutoSize = true;
            this.lblRegAge.Location = new System.Drawing.Point(304, 189);
            this.lblRegAge.Name = "lblRegAge";
            this.lblRegAge.Size = new System.Drawing.Size(99, 17);
            this.lblRegAge.TabIndex = 34;
            this.lblRegAge.Text = "Seller\'s Agent :";
            // 
            // lblSellersCi
            // 
            this.lblSellersCi.AutoSize = true;
            this.lblSellersCi.Location = new System.Drawing.Point(7, 189);
            this.lblSellersCi.Name = "lblSellersCi";
            this.lblSellersCi.Size = new System.Drawing.Size(85, 17);
            this.lblSellersCi.TabIndex = 33;
            this.lblSellersCi.Text = "Seller\'s City :";
            // 
            // lblDistrict
            // 
            this.lblDistrict.AutoSize = true;
            this.lblDistrict.Location = new System.Drawing.Point(304, 142);
            this.lblDistrict.Name = "lblDistrict";
            this.lblDistrict.Size = new System.Drawing.Size(103, 17);
            this.lblDistrict.TabIndex = 32;
            this.lblDistrict.Text = "Seller\'s District :";
            // 
            // lblsStreet
            // 
            this.lblsStreet.AutoSize = true;
            this.lblsStreet.Location = new System.Drawing.Point(304, 89);
            this.lblsStreet.Name = "lblsStreet";
            this.lblsStreet.Size = new System.Drawing.Size(140, 17);
            this.lblsStreet.TabIndex = 31;
            this.lblsStreet.Text = "Seller\'s Street Name :";
            // 
            // lblsHouse
            // 
            this.lblsHouse.AutoSize = true;
            this.lblsHouse.Location = new System.Drawing.Point(304, 37);
            this.lblsHouse.Name = "lblsHouse";
            this.lblsHouse.Size = new System.Drawing.Size(155, 17);
            this.lblsHouse.TabIndex = 30;
            this.lblsHouse.Text = "Seller\'s House Number :";
            // 
            // lblSDate
            // 
            this.lblSDate.AutoSize = true;
            this.lblSDate.Location = new System.Drawing.Point(7, 142);
            this.lblSDate.Name = "lblSDate";
            this.lblSDate.Size = new System.Drawing.Size(119, 17);
            this.lblSDate.TabIndex = 29;
            this.lblSDate.Text = "Seller\'s BirthDate :";
            // 
            // lblSelAge
            // 
            this.lblSelAge.AutoSize = true;
            this.lblSelAge.Location = new System.Drawing.Point(7, 89);
            this.lblSelAge.Name = "lblSelAge";
            this.lblSelAge.Size = new System.Drawing.Size(86, 17);
            this.lblSelAge.TabIndex = 28;
            this.lblSelAge.Text = "Seller\'s Age :";
            // 
            // lblSellerName
            // 
            this.lblSellerName.AutoSize = true;
            this.lblSellerName.Location = new System.Drawing.Point(7, 37);
            this.lblSellerName.Name = "lblSellerName";
            this.lblSellerName.Size = new System.Drawing.Size(100, 17);
            this.lblSellerName.TabIndex = 27;
            this.lblSellerName.Text = "Seller\'s Name :";
            // 
            // btnSave
            // 
            this.btnSave.ActiveBorderThickness = 1;
            this.btnSave.ActiveCornerRadius = 20;
            this.btnSave.ActiveFillColor = System.Drawing.Color.DeepSkyBlue;
            this.btnSave.ActiveForecolor = System.Drawing.Color.White;
            this.btnSave.ActiveLineColor = System.Drawing.Color.Red;
            this.btnSave.BackColor = System.Drawing.Color.White;
            this.btnSave.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSave.BackgroundImage")));
            this.btnSave.ButtonText = "Save";
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnSave.IdleBorderThickness = 1;
            this.btnSave.IdleCornerRadius = 20;
            this.btnSave.IdleFillColor = System.Drawing.Color.White;
            this.btnSave.IdleForecolor = System.Drawing.Color.DeepSkyBlue;
            this.btnSave.IdleLineColor = System.Drawing.Color.DeepSkyBlue;
            this.btnSave.Location = new System.Drawing.Point(584, 278);
            this.btnSave.Margin = new System.Windows.Forms.Padding(5);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(94, 40);
            this.btnSave.TabIndex = 26;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.ActiveBorderThickness = 1;
            this.btnEdit.ActiveCornerRadius = 20;
            this.btnEdit.ActiveFillColor = System.Drawing.Color.DeepSkyBlue;
            this.btnEdit.ActiveForecolor = System.Drawing.Color.White;
            this.btnEdit.ActiveLineColor = System.Drawing.Color.Red;
            this.btnEdit.BackColor = System.Drawing.Color.White;
            this.btnEdit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEdit.BackgroundImage")));
            this.btnEdit.ButtonText = "Edit";
            this.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdit.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnEdit.IdleBorderThickness = 1;
            this.btnEdit.IdleCornerRadius = 20;
            this.btnEdit.IdleFillColor = System.Drawing.Color.White;
            this.btnEdit.IdleForecolor = System.Drawing.Color.DeepSkyBlue;
            this.btnEdit.IdleLineColor = System.Drawing.Color.DeepSkyBlue;
            this.btnEdit.Location = new System.Drawing.Point(482, 278);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(5);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(94, 40);
            this.btnEdit.TabIndex = 25;
            this.btnEdit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.ActiveBorderThickness = 1;
            this.btnAdd.ActiveCornerRadius = 20;
            this.btnAdd.ActiveFillColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAdd.ActiveForecolor = System.Drawing.Color.White;
            this.btnAdd.ActiveLineColor = System.Drawing.Color.Red;
            this.btnAdd.BackColor = System.Drawing.Color.White;
            this.btnAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAdd.BackgroundImage")));
            this.btnAdd.ButtonText = "Add";
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnAdd.IdleBorderThickness = 1;
            this.btnAdd.IdleCornerRadius = 20;
            this.btnAdd.IdleFillColor = System.Drawing.Color.White;
            this.btnAdd.IdleForecolor = System.Drawing.Color.DeepSkyBlue;
            this.btnAdd.IdleLineColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAdd.Location = new System.Drawing.Point(378, 278);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(5);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(94, 40);
            this.btnAdd.TabIndex = 24;
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblSubTitle
            // 
            this.lblSubTitle.AutoSize = true;
            this.lblSubTitle.Font = new System.Drawing.Font("Century Gothic", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubTitle.Location = new System.Drawing.Point(8, 290);
            this.lblSubTitle.Name = "lblSubTitle";
            this.lblSubTitle.Size = new System.Drawing.Size(99, 28);
            this.lblSubTitle.TabIndex = 28;
            this.lblSubTitle.Text = "Sellers :";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(266, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(191, 24);
            this.lblTitle.TabIndex = 29;
            this.lblTitle.Text = "Sellers Management";
            // 
            // btnExit
            // 
            this.btnExit.ActiveBorderThickness = 1;
            this.btnExit.ActiveCornerRadius = 10;
            this.btnExit.ActiveFillColor = System.Drawing.Color.DeepSkyBlue;
            this.btnExit.ActiveForecolor = System.Drawing.Color.White;
            this.btnExit.ActiveLineColor = System.Drawing.Color.Red;
            this.btnExit.BackColor = System.Drawing.Color.White;
            this.btnExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnExit.BackgroundImage")));
            this.btnExit.ButtonText = "X";
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnExit.IdleBorderThickness = 1;
            this.btnExit.IdleCornerRadius = 20;
            this.btnExit.IdleFillColor = System.Drawing.Color.White;
            this.btnExit.IdleForecolor = System.Drawing.Color.DeepSkyBlue;
            this.btnExit.IdleLineColor = System.Drawing.Color.DeepSkyBlue;
            this.btnExit.Location = new System.Drawing.Point(654, 4);
            this.btnExit.Margin = new System.Windows.Forms.Padding(6);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(40, 29);
            this.btnExit.TabIndex = 30;
            this.btnExit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // CircleProgress
            // 
            this.CircleProgress.animated = true;
            this.CircleProgress.animationIterval = 2;
            this.CircleProgress.animationSpeed = 10;
            this.CircleProgress.BackColor = System.Drawing.Color.White;
            this.CircleProgress.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("CircleProgress.BackgroundImage")));
            this.CircleProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CircleProgress.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.CircleProgress.LabelVisible = true;
            this.CircleProgress.LineProgressThickness = 4;
            this.CircleProgress.LineThickness = 4;
            this.CircleProgress.Location = new System.Drawing.Point(264, 361);
            this.CircleProgress.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.CircleProgress.MaxValue = 100;
            this.CircleProgress.Name = "CircleProgress";
            this.CircleProgress.ProgressBackColor = System.Drawing.Color.Red;
            this.CircleProgress.ProgressColor = System.Drawing.Color.DeepSkyBlue;
            this.CircleProgress.Size = new System.Drawing.Size(156, 156);
            this.CircleProgress.TabIndex = 31;
            this.CircleProgress.Value = 0;
            // 
            // timer
            // 
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // btnDelete
            // 
            this.btnDelete.ActiveBorderThickness = 1;
            this.btnDelete.ActiveCornerRadius = 20;
            this.btnDelete.ActiveFillColor = System.Drawing.Color.DeepSkyBlue;
            this.btnDelete.ActiveForecolor = System.Drawing.Color.White;
            this.btnDelete.ActiveLineColor = System.Drawing.Color.Red;
            this.btnDelete.BackColor = System.Drawing.Color.White;
            this.btnDelete.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDelete.BackgroundImage")));
            this.btnDelete.ButtonText = "Delete";
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnDelete.IdleBorderThickness = 1;
            this.btnDelete.IdleCornerRadius = 20;
            this.btnDelete.IdleFillColor = System.Drawing.Color.White;
            this.btnDelete.IdleForecolor = System.Drawing.Color.DeepSkyBlue;
            this.btnDelete.IdleLineColor = System.Drawing.Color.DeepSkyBlue;
            this.btnDelete.Location = new System.Drawing.Point(200, 278);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(5);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(94, 40);
            this.btnDelete.TabIndex = 52;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.lblTitle);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.Blue;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.White;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(696, 46);
            this.bunifuGradientPanel1.TabIndex = 53;
            // 
            // frmSellers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(696, 535);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.CircleProgress);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblSubTitle);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.grpSellers);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.gridSellers);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmSellers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmSellers";
            this.Load += new System.EventHandler(this.frmSellers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridSellers)).EndInit();
            this.grpSellers.ResumeLayout(false);
            this.grpSellers.PerformLayout();
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuCustomDataGrid gridSellers;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.GroupBox grpSellers;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtHNumber;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.TextBox txtDistrict;
        private System.Windows.Forms.TextBox txtStreetName;
        private System.Windows.Forms.Label lblSelAge;
        private System.Windows.Forms.Label lblSellerName;
        private System.Windows.Forms.Label lblSellersCi;
        private System.Windows.Forms.Label lblDistrict;
        private System.Windows.Forms.Label lblsStreet;
        private System.Windows.Forms.Label lblsHouse;
        private System.Windows.Forms.Label lblSDate;
        private System.Windows.Forms.Label lblRegAge;
        private System.Windows.Forms.ComboBox cboAgent;
        private System.Windows.Forms.DateTimePicker datBirthdate;
        private System.Windows.Forms.Label lblSubTitle;
        private Bunifu.Framework.UI.BunifuThinButton2 btnSave;
        private Bunifu.Framework.UI.BunifuThinButton2 btnEdit;
        private Bunifu.Framework.UI.BunifuThinButton2 btnAdd;
        private System.Windows.Forms.Label lblTitle;
        private Bunifu.Framework.UI.BunifuThinButton2 btnExit;
        private Bunifu.Framework.UI.BunifuCircleProgressbar CircleProgress;
        private System.Windows.Forms.Timer timer;
        private Bunifu.Framework.UI.BunifuThinButton2 btnDelete;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
    }
}
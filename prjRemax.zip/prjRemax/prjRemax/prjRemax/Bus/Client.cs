﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjRemax.Bus
{
   public  class Client
    {
        private string name;
        private int age;
        private DateTime birthDate;
        private Address address;

        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public int Age
        {
            get
            {
                return age;
            }

            set
            {
                age = value;
            }
        }

        public DateTime BirthDate
        {
            get
            {
                return birthDate;
            }

            set
            {
                birthDate = value;
            }
        }

        public Address Address
        {
            get
            {
                return address;
            }

            set
            {
                address = value;
            }
        }

        public Client()
        { }
        public Client(string nam,int ag,DateTime BD,Address ad)
        {
            this.Name = nam;
            this.Age = ag;
            this.BirthDate = BD;
            this.Address = ad;
        }
    }
}

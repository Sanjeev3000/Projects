﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjRemax.Bus
{
    public class Buyer:Client
    {
        private int refAgent;
        private string agentName;
        private int iD;
        private string credit;
        private float budget;
        public int RefAgent
        {
            get
            {
                return refAgent;
            }

            set
            {
                refAgent = value;
            }
        }

        public string AgentName
        {
            get
            {
                return agentName;
            }

            set
            {
                agentName = value;
            }
        }

        public int ID
        {
            get
            {
                return iD;
            }

            set
            {
                iD = value;
            }
        }

        public string Credit
        {
            get
            {
                return credit;
            }

            set
            {
                credit = value;
            }
        }

        public float Budget
        {
            get
            {
                return budget;
            }

            set
            {
                budget = value;
            }
        }

        public Buyer()
        { }

        public Buyer(string name,int age,DateTime BirthDate,Address ad,string cred,float bud,int RefId,string agent):base(name,age,BirthDate,ad)
        {
            this.RefAgent = RefId;
            this.AgentName = agent;
            this.Credit = cred;
            this.budget = bud;
        }
    }
}

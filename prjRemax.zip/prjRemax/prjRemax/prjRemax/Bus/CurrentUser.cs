﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace prjRemax.Bus
{   public enum Positions
    {
        Admin,Agent,Guest
    }
    public static class CurrentUser
    {
        private static int iD;
        private static string password;
        private static int refUsers;
        private static string name;
        private static string userType;
        public static int ID
        {
            get
            {
                return iD;
            }

            set
            {
                iD = value;
            }
        }

        public static string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }

        public static int RefUsers
        {
            get
            {
                return refUsers;
            }

            set
            {
                refUsers = value;
            }
        }

        public static string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public static string UserType
        {
            get
            {
                return userType;
            }

            set
            {
                userType = value;
            }
        }
    }
}

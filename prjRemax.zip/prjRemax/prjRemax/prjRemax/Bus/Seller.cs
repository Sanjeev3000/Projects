﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjRemax.Bus
{
   public class Seller:Client
    {
        private int refAgent;
        private string agentName;
        private int iD;
        public Seller()
        { }

        public Seller(string name, int age, DateTime BD, Address ad,int refID,string agent) : base(name, age, BD, ad)
        {
                this.RefAgent = refID;
                this.AgentName = agent;
        }

        public int RefAgent
        {
            get
            {
                return refAgent;
            }

            set
            {
                refAgent = value;
            }
        }

        public string AgentName
        {
            get
            {
                return agentName;
            }

            set
            {
                agentName = value;
            }
        }

        public int ID
        {
            get
            {
                return iD;
            }

            set
            {
                iD = value;
            }
        }
       
    }
}

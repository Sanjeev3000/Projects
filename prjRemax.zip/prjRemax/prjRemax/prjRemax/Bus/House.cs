﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjRemax.Bus
{
   public class House
   {
        private int yearBuilt;
        private float livingArea;
        private Address address;
        private float finalPrice;
        private string description;
        private string refSeller;
        private string refAgent;
        private int refAgentID;
        private int iD;
        private int refSellerID;
        

        public int YearBuilt
        {
            get
            {
                return yearBuilt;
            }

            set
            {
                yearBuilt = value;
            }
        }

        public float LivingArea
        {
            get
            {
                return livingArea;
            }

            set
            {
                livingArea = value;
            }
        }

        public Address Address
        {
            get
            {
                return address;
            }

            set
            {
                address = value;
            }
        }

        public float FinalPrice
        {
            get
            {
                return finalPrice;
            }

            set
            {
                finalPrice = value;
            }
        }

        public string Description
        {
            get
            {
                return description;
            }

            set
            {
                description = value;
            }
        }

        public string RefSeller
        {
            get
            {
                return refSeller;
            }

            set
            {
                refSeller = value;
            }
        }

        public string RefAgent
        {
            get
            {
                return refAgent;
            }

            set
            {
                refAgent = value;
            }
        }

        public int ID
        {
            get
            {
                return iD;
            }

            set
            {
                iD = value;
            }
        }

        public int RefAgentID
        {
            get
            {
                return refAgentID;
            }

            set
            {
                refAgentID = value;
            }
        }

        public int RefSellerID
        {
            get
            {
                return refSellerID;
            }

            set
            {
                refSellerID = value;
            }
        }

        public House() { }
        public House(int year, float area, Address ad, float price, string desc, string refagent,string refSeller,int id,int idSeller)
        {
            this.YearBuilt = year;
            this.LivingArea = area;
            this.Address = ad;
            this.FinalPrice = price;
            this.Description = desc;
            this.RefAgent = refagent;
            this.RefSeller = refSeller;
            this.RefAgentID = id;
            this.RefSellerID = idSeller;
          
        }
    }
}

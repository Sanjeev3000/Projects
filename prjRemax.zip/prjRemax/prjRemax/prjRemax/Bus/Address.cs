﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjRemax.Bus
{
    public class Address
    {
        private string houseNumber;
        private string streetName;
        private string district;
        private string city;


        public string HouseNumber
        {
            get
            {
                return houseNumber;
            }

            set
            {
                houseNumber = value;
            }
        }

        public string StreetName
        {
            get
            {
                return streetName;
            }

            set
            {
                streetName = value;
            }
        }

        public string District
        {
            get
            {
                return district;
            }

            set
            {
                district = value;
            }
        }

        public string City
        {
            get
            {
                return city;
            }

            set
            {
                city = value;
            }
        }
        public Address()
        {        }
        public Address(string num,string name,string dist,string city)
        {
            this.HouseNumber = num;
            this.StreetName = name;
            this.District = dist;
            this.City = city;
        }
        public override string ToString()
        {
            string state;
            state = houseNumber + "," + streetName + "," + district + "," + city;
            return state;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjRemax.Bus
{
    public class Employee
    {
        private string employeeName;
        private DateTime birthDate;
        private string employeePosition;
        private double salary;
        private string status;
        private string password;
        private int iD;
        public string EmployeeName
        {
            get
            {
                return employeeName;
            }

            set
            {
                employeeName = value;
            }
        }

        public DateTime BirthDate
        {
            get
            {
                return birthDate;
            }

            set
            {
                birthDate = value;
            }
        }

        public string EmployeePosition
        {
            get
            {
                return employeePosition;
            }

            set
            {
                employeePosition = value;
            }
        }

        public double Salary
        {
            get
            {
                return salary;
            }

            set
            {
                salary = value;
            }
        }

        public string Status
        {
            get
            {
                return status;
            }

            set
            {
                status = value;
            }
        }

        public string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }

        public int ID
        {
            get
            {
                return iD;
            }

            set
            {
                iD = value;
            }
        }

        public Employee()
        {
            
        }

        public Employee(string name, DateTime date, string post, double sal, string status,string pass)
        {

            this.EmployeeName = name;
            this.BirthDate = date;
            this.EmployeePosition = post;
            this.Salary = sal;
            this.Status = status;
            this.Password = pass;



        }

    }
}

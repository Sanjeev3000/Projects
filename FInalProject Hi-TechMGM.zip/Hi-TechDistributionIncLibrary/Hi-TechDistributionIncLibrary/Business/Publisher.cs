﻿using Hi_TechDistributionIncLibrary.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi_TechDistributionIncLibrary.Business
{
    public enum EnumPublisherSearch
    {
        Publisher_Name, Phone_Number
    }
    public class Publisher
    {
        private string pName;
        private string pphonenumber;
        private string v;

        public string PName
        {
            get
            {
                return pName;
            }

            set
            {
                pName = value;
            }
        }

        public string Pphonenumber
        {
            get
            {
                return pphonenumber;
            }

            set
            {
                pphonenumber = value;
            }
        }

        public Publisher()
        {
            pName = "";
            pphonenumber = "";


        }
        public Publisher(string name, MaskedTextBox number)
        {
            this.pName = name;
            this.pphonenumber = number.Text;
        }
        public Publisher(ComboBox pu)
        {
            this.pName = Convert.ToString(pu.Text);
        }

        public Publisher(string v)
        {
            this.v = v;
        }

        public override string ToString()
        {
            string state = pName + "," + pphonenumber;
            return state;
        }
        public static void SavetoFile(List<Publisher> list)
        {
            PublisherDA.SaveToFile(list);

        }
        public void Display(List<Publisher> listOfpub, ListView list)
        {
            if (listOfpub.Capacity != 0)
            {
                list.Items.Clear();
                foreach (Publisher element in listOfpub)
                {


                    string[] row = {

                        element.PName,Convert.ToString(element.Pphonenumber)
                    };

                    var listViewItem = new ListViewItem(row);
                    list.Items.Add(listViewItem);
                }
            }
        }
        public static void ReadFromFile(List<Publisher> listTemp, List<Publisher> listOri, Publisher p1, ListView listview)
        {
            listTemp = PublisherDA.ReadFromFile();
            listOri = listTemp;
            p1.Display(listOri, listview);
        }
        public static Publisher Search(TextBox key)
        {
            return PublisherDA.Search(key);
        }
        public static Publisher SearchNumber(MaskedTextBox key)
        {
            return PublisherDA.SearchNumber(key);
        }
    }
}

﻿using Hi_TechDistributionIncLibrary.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi_TechDistributionIncLibrary.Business
{
    public enum EnumSearchUser
    {
        ID, Username

    }
    public class User
    {
        private string username;
        private string password;


        public string Username
        {
            get
            {
                return username;
            }

            set
            {
                username = value;
            }
        }

        public string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }

        //public int UserID
        //{
        //    get
        //    {
        //        return userID;
        //    }

        //    set
        //    {
        //        userID = value;
        //    }
        //}

        //public EnumPosition Upsition
        //{
        //    get
        //    {
        //        return upsition;
        //    }

        //    set
        //    {
        //        upsition = value;
        //    }
        //}

        //private int userID;
        //private EnumPosition upsition;

        public User()
        {
            this.username = "";
            this.password = "";


        }
        // public User(int id, EnumPosition pos,string us,string pass)
        public User(string us, string pass)
        {
            //    this.userID = id;
            //  this.upsition = pos;
            this.username = us;
            this.password = pass;
        }

        public void Display(List<User> aListOfUsers, ListBox listBoxDisplay)
        {
            listBoxDisplay.Items.Clear();

            foreach (User element in aListOfUsers)
            {
                listBoxDisplay.Items.Add(element);
            }

        }
        public void DisplayUsers(List<User> listOfUser, ListView list)
        {
            if (listOfUser.Capacity != 0)
            {
                list.Items.Clear();
                foreach (User element in listOfUser)
                {


                    string[] row = {
                        element.username,element.password




                    };

                    var listViewItem = new ListViewItem(row);
                    list.Items.Add(listViewItem);
                }
            }
        }
        public void ReadCombo(List<Employee> listOfEmployees)
        {
            UserDA.ReadFromFile(listOfEmployees);
        }
        public static User UserSearch(TextBox key)
        {
            return UserDA.Search(key);
        }
        public static void SaveToFile(List<User> list)
        {
            UserDA.SaveToFile(list);
        }
        public void ReadForLoad(List<User> listOfUsers)
        {

            UserDA.ReadFromFileUsers(listOfUsers);
        }
        public static void ReadFromFile(List<User> listforRead, List<User> listOfUsers, User us, ListBox listviewUsers)
        {
            listforRead = UserDA.ReadFromFileUsers();
            listOfUsers = listforRead;
            us.Display(listOfUsers, listviewUsers);
        }
        public override string ToString()
        {
            string state;
            state = username.ToString() + "," + password.ToString();
            return state;
        }
    }
}

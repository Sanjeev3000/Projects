﻿using Hi_TechDistributionIncLibrary.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi_TechDistributionIncLibrary.Business
{
    public class Authors : Person
    {
        public string Name
        {
            get { return (Firstname + Lastname); }
        }

        private string nametemp;
        private int authorID;
        private string city;
        private string phone;
        public int AuthorID
        {
            get
            {
                return authorID;
            }

            set
            {
                authorID = value;
            }
        }

        public string Phone
        {
            get
            {
                return phone;
            }

            set
            {
                phone = value;
            }
        }


        public string City
        {
            get
            {
                return city;
            }

            set
            {
                city = value;
            }
        }


        public string Nametemp
        {
            get
            {
                return nametemp;
            }

            set
            {
                nametemp = value;
            }
        }

        public Authors()
        {

            authorID = 00000;
            city = "";
            phone = "";

        }
        public Authors(int id, string cit, string number, string fn, string ln) : base(fn, ln)
        {
            this.authorID = id;
            this.city = cit;
            this.phone = number;

        }
        public Authors(ComboBox authors)
        {
            this.nametemp = authors.Text;

        }



        public override string ToString()
        {
            string state;
            state = authorID.ToString() + "," + city + "," + phone + "," + base.ToString();
            return state;
        }

        public static void SaveToFile(List<Authors> list)
        {
            AuthorDA.SaveToFile(list);
        }
        public void Display(List<Authors> listOfAu, ListView list)
        {
            if (listOfAu.Capacity != 0)
            {
                list.Items.Clear();
                foreach (Authors element in listOfAu)
                {


                    string[] row = {

                        Convert.ToString(element.AuthorID),element.Firstname,element.Lastname,element.City,element.phone


                    };

                    var listViewItem = new ListViewItem(row);
                    list.Items.Add(listViewItem);
                }
            }
        }
        public static void ReadFromFile(List<Authors> listforRead, List<Authors> listOfAuthors, Authors au, ListView listView)

        {

            listforRead = AuthorDA.ReadFromFile();
            listOfAuthors = listforRead;
            au.Display(listOfAuthors, listView);
        }
        public static Authors Search(TextBox key)
        {
            return AuthorDA.Search(key);
        }
        public static Authors SearchFN(TextBox key)
        {
            return AuthorDA.SearchByFN(key);
        }
        public static Authors SearchLN(TextBox key)
        {

            return AuthorDA.SearchByLN(key);
        }
    }
}

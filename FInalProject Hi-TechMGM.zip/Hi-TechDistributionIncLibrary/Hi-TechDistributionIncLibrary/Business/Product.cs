﻿using Hi_TechDistributionIncLibrary.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi_TechDistributionIncLibrary.Business
{
    public enum EnumProduct
    {

        Book, Software, UNKNOWN

    }
    public enum EnumSearchBook
    {

        ISBN, Title
    }

    public class Product
    {
        private float uPrice;
        private string names;
        public float UPrice
        {
            get
            {
                return uPrice;
            }

            set
            {
                uPrice = value;
            }
        }

        public int QOH
        {
            get
            {
                return qOH;
            }

            set
            {
                qOH = value;
            }
        }

        public EnumProduct ProductType
        {
            get
            {
                return productType;
            }

            set
            {
                productType = value;
            }
        }

        public long ISBN
        {
            get
            {
                return iSBN;
            }

            set
            {
                iSBN = value;
            }
        }

        public string Title
        {
            get
            {
                return title;
            }

            set
            {
                title = value;
            }
        }

        public DateTime YearPublished
        {
            get
            {
                return yearPublished;
            }

            set
            {
                yearPublished = value;
            }
        }



        public string Publisher
        {
            get
            {
                return publisher;
            }

            set
            {
                publisher = value;
            }
        }




        public string Names1
        {
            get
            {
                return names;
            }

            set
            {
                names = value;
            }
        }

        public int Qty
        {
            get
            {
                return qty;
            }

            set
            {
                qty = value;
            }
        }

        public float Subtotal
        {
            get
            {
                return subtotal;
            }

            set
            {
                subtotal = value;
            }
        }

        private int qOH;
        private long iSBN;
        private string title;
        private string publisher;
        private float subtotal;
        private int qty;




        private DateTime yearPublished;
        private EnumProduct productType;

        public Product()
        {
            this.ISBN = 0000000000000;
            this.Title = "";
            this.UPrice = 0000;
            this.YearPublished = new DateTime();
            this.QOH = 000;
            this.productType = EnumProduct.UNKNOWN;
            this.Publisher = "";

        }
        public Product(ComboBox comboProd)
        {
            this.title = comboProd.Text;

        }
        public Product(long isbn, string title, float price, int qu, EnumProduct cat)
        {
            this.ISBN = isbn;
            this.Title = title;
            this.UPrice = price;
            this.QOH = qu;
            this.productType = cat;

        }
        public override string ToString()
        {
            string state;
            state = ISBN.ToString() + "," + Title.ToString() + "," + UPrice.ToString() + "," + YearPublished.ToString() + "," + QOH.ToString() + "," + productType + "," + publisher;
            return state;
        }
        public static void SaveToFile(List<Product> list)
        {
            ProductDA.SaveToFile(list);
        }
        public static void ReadFromFile(List<Product> listTemp, List<Product> listOri, Product p1, ListView listview)
        {
            listTemp = ProductDA.ReadFromFile();
            listOri = listTemp;
            p1.Display(listOri, listview);
        }
        public void Display(List<Product> listOfp, ListView list)
        {
            if (listOfp.Capacity != 0)
            {
                list.Items.Clear();
                foreach (Product element in listOfp)
                {

                    string[] row = {
                       Convert.ToString(element.ISBN),element.Title,Convert.ToString(element.UPrice),Convert.ToString(element.yearPublished),Convert.ToString(element.QOH),Convert.ToString(element.productType),element.Publisher



                    };

                    var listViewItem = new ListViewItem(row);
                    list.Items.Add(listViewItem);
                }
            }
        }
        public void Display2(List<Product> listOfp, ListView list)
        {
            if (listOfp.Capacity != 0)
            {
                list.Items.Clear();
                foreach (Product element in listOfp)
                {

                    string[] row = {
                     element.Title,element.qty.ToString(),element.UPrice.ToString(),element.subtotal.ToString()


                    };

                    var listViewItem = new ListViewItem(row);
                    list.Items.Add(listViewItem);
                }
            }
        }
        public static Product Search(TextBox key)
        {
            return ProductDA.Search(key);

        }
        public static Product SearchByTitle(TextBox key)
        {
            return ProductDA.SearchByTitle(key);
        }
        public double SubTotal(Product pod)
        {
            pod.subtotal = uPrice * qty;
            return subtotal;

        }
    }
}

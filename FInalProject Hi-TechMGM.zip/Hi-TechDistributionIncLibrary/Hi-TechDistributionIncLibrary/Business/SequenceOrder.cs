﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hi_TechDistributionIncLibrary.Business
{
    public class SequenceOrder
    {


        private static int index = 10000;

        public static int increment()
        {
            return index++;
        }
        public static int setIndex(int value)
        {
            return index = value;
        }

        public static int ReadToCheck(List<Order> list)
        {
            //StreamReader sReader = new StreamReader(EmployeeDA.filePath);
            //string line = sReader.ReadLine();
            //while (line != null)
            //{
            //    string[] fields = line.Split(',');
            //    Employee emp = new Employee();
            //    emp.EmployeeID = Convert.ToInt32(fields[0]);
            //    if (emp.EmployeeID == index)
            //    {

            //        return emp.EmployeeID++;

            //    }

            //    else
            //    {
            //        increment();

            //    }

            //}
            //sReader.Close();

            //return 0 ;

            foreach (Order item in list)
            {
                if (item.OrderID == index)
                {
                    item.OrderID = index++;
                }
            }
            return index;


        }
    }
}

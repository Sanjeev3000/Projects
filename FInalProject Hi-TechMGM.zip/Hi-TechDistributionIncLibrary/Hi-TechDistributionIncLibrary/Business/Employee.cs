﻿using Hi_TechDistributionIncLibrary.DataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi_TechDistributionIncLibrary.Business
{
    public enum EnumPosition
    {
        [Description("MIS Manager")]
        MIS_Manager, [Description("Sales Manager")]
        Sales_Manager, [Description("Inventory Controller")]
        Inventory_Controller, [Description("Order Clerk")]
        Order_Clerk, unknown

    }
    public enum EnumStatus
    {
        [Description("Full-Time")]
        Full_Time, [Description("Part-Time")]
        Part_Time, Unknown

    }
    public enum EnumSearch
    {
        FirstName, LastName, ID
    }
    public class Employee : Person
    {

        private int employeeID;/// insert sequence increment
        private EnumStatus status;
        private EnumPosition position;
        private User username;



        public Employee()
        {
            EmployeeID = 000000;
            Status = EnumStatus.Unknown;
            Position = EnumPosition.unknown;
            username = new User();
        }
        public Employee(int id) { }





        public Employee(EnumStatus stat, EnumPosition pos, string fn, string ln, int id, User username) : base(fn, ln)
        {
            this.Status = stat;
            this.position = pos;
            this.employeeID = id;
            this.username = username;

        }

        public Employee(EnumStatus status, EnumPosition position, string fn, string ln, int id)
        {
            this.status = status;
            this.position = position;
            this.Firstname = fn;
            this.Lastname = ln;
            this.employeeID = id;
        }

        public EnumPosition Position
        {
            get
            {
                return position;
            }

            set
            {
                position = value;
            }
        }

        public EnumStatus Status
        {
            get
            {
                return status;
            }

            set
            {
                status = value;
            }
        }

        public int EmployeeID
        {
            get
            {
                return employeeID;
            }

            set
            {
                employeeID = value;
            }
        }

        public User Username
        {
            get
            {
                return username;
            }

            set
            {
                username = value;
            }
        }

        public static void SaveToFile(List<Employee> list)
        {
            EmployeeDA.SaveToFile(list);
        }
        public static Employee Search(TextBox key)
        {
            return EmployeeDA.Search(key);
        }
        public static Employee SearchFN(TextBox key)
        {
            return EmployeeDA.SearchByFN(key);
        }
        public static Employee SearchLN(TextBox key)
        {

            return EmployeeDA.SearchByLN(key);
        }
        public static void ReadFromFile(List<Employee> listforRead, List<Employee> listOfEmployee, Employee emp, ListView listViewEmployees)
        {
            listforRead = EmployeeDA.ReadFromFile();
            listOfEmployee = listforRead;
            emp.Display(listOfEmployee, listViewEmployees);

        }
        public void EmployeeDelete(int empid)
        {
            EmployeeDA.EmployeeDelete(empid);

        }
        public void Display(List<Employee> listOfEmp, ListView list)
        {
            if (listOfEmp.Capacity != 0)
            {
                list.Items.Clear();
                foreach (Employee element in listOfEmp)
                {


                    string[] row = {
                        Convert.ToString(element.employeeID),element.Firstname,element.Lastname,Convert.ToString(element.Status),Convert.ToString(element.Position)




                    };

                    var listViewItem = new ListViewItem(row);
                    list.Items.Add(listViewItem);
                }
            }
        }
    }
}

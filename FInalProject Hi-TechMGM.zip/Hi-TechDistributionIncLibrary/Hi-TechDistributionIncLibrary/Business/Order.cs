﻿using Hi_TechDistributionIncLibrary.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi_TechDistributionIncLibrary.Business
{
    public enum EnumShipDate
    {
        OneDay, OneWeek, OneMonth, UNKNOWN
    }
    public enum EnumOrderBy
    {
        Fax, Email, Phone, UNKNOWN

    }

    public class Order
    {
        private List<Product> ChosenProd;
        private float credit;
        private string email;
        private string fax;
        private string phonenumber;
        private int orderID;
        private string clientName;
        private string productName;
        private int qty;
        private DateTime reqDate;
        private float subtotal;
        private float total;
        private EnumShipDate shipDate;
        private string orderType;
        private float availableCredit;
        public int OrderID
        {
            get
            {
                return orderID;
            }

            set
            {
                orderID = value;
            }
        }

        public DateTime ReqDate
        {
            get
            {
                return reqDate;
            }

            set
            {
                reqDate = value;
            }
        }

        public float Total
        {
            get
            {
                return total;
            }

            set
            {
                total = value;
            }
        }

        public EnumShipDate ShipDate
        {
            get
            {
                return shipDate;
            }

            set
            {
                shipDate = value;
            }
        }

        public string OrderType
        {
            get
            {
                return orderType;
            }

            set
            {
                orderType = value;
            }
        }

        public string ClientName
        {
            get
            {
                return clientName;
            }

            set
            {
                clientName = value;
            }
        }

        public string ProductName
        {
            get
            {
                return productName;
            }

            set
            {
                productName = value;
            }
        }

        public int Qty
        {
            get
            {
                return qty;
            }
            set
            {
                qty = value;
            }

        }

        public float Subtotal
        {
            get
            {
                return subtotal;
            }
            set { subtotal = value; }

        }


        public string Email
        {
            get
            {
                return email;
            }
            set
            {
                email = value;

            }
        }


        public string Phonenumber
        {
            get
            {
                return phonenumber;
            }

            set
            {
                phonenumber = value;
            }
        }

        public string Fax
        {
            get
            {
                return fax;
            }

            set
            {
                fax = value;
            }
        }

        public List<Product> ChosenProd1
        {
            get
            {
                return ChosenProd;
            }

            set
            {
                ChosenProd = value;
            }
        }

        public float AvailableCredit
        {
            get
            {
                return availableCredit;
            }

            set
            {
                availableCredit = value;
            }
        }

        public float Credit
        {
            get
            {
                return credit;
            }

            set
            {
                credit = value;
            }
        }

        public Order()
        {
            this.orderID = 000000000;
            this.clientName = "";
            this.productName = "";
            this.qty = 000000;
            this.reqDate = new DateTime();
            this.shipDate = EnumShipDate.UNKNOWN;
            this.orderType = "";
            this.total = 00000000;


        }
        public Order(int id, string cname, DateTime rdate, EnumShipDate sdate)
        {
            this.OrderID = id;
            this.clientName = cname;

            this.reqDate = rdate;
            this.shipDate = sdate;


        }
        public void Display(List<Order> listOfOD, ListView list)
        {
            if (listOfOD.Capacity != 0)
            {
                list.Items.Clear();
                foreach (Order element in listOfOD)
                {


                    string[] row = {
                       element.orderID.ToString(),element.clientName,element.qty.ToString(),element.reqDate.ToString(),element.shipDate.ToString(),element.orderType.ToString(),element.Subtotal.ToString(),element.total.ToString(),element.Credit.ToString(),element.availableCredit.ToString()



                    };

                    var listViewItem = new ListViewItem(row);
                    list.Items.Add(listViewItem);
                }
            }
        }
        public static void SaveToFile(List<Order> list)
        {
            OrderDA.SaveToFile(list);
        }
        public static Order Search(TextBox key)
        {
            return OrderDA.Search(key);

        }
        public static void ReadFromFile(List<Order> listTemp, List<Order> listOri, Order o1, ListView listview)
        {
            listTemp = OrderDA.ReadFromFile();
            listOri = listTemp;
            o1.Display(listOri, listview);
        }
    }
}

﻿using Hi_TechDistributionIncLibrary.DataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi_TechDistributionIncLibrary.Business
{
    public enum EnumSearchClient
    {
        [Description("Institute's Name")]
        InstituteName, [Description("Phone Number")]
        PhoneNumber
    }
    public class College
    {
        private string name;

        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public string Street
        {
            get
            {
                return street;
            }

            set
            {
                street = value;
            }
        }

        public string PostCode
        {
            get
            {
                return postCode;
            }

            set
            {
                postCode = value;
            }
        }

        public string City
        {
            get
            {
                return city;
            }

            set
            {
                city = value;
            }
        }

        public string PhoneNunber
        {
            get
            {
                return phoneNumber;
            }

            set
            {
                phoneNumber = value;
            }
        }

        public string FaxNumber
        {
            get
            {
                return faxNumber;
            }

            set
            {
                faxNumber = value;
            }
        }

        public int Credit
        {
            get
            {
                return credit;
            }

            set
            {
                credit = value;
            }
        }

        public string Email
        {
            get
            {
                return email;
            }

            set
            {
                email = value;
            }
        }

        private string street;
        private string city;
        private string postCode;
        private string phoneNumber;
        private string faxNumber;
        private int credit;
        private string email;
        public void Display(List<College> listOfCol, ListView list)
        {
            if (listOfCol.Capacity != 0)
            {
                list.Items.Clear();
                foreach (College element in listOfCol)
                {


                    string[] row = {
                        element.name,element.street,element.city,element.postCode,Convert.ToString(element.phoneNumber),Convert.ToString(element.faxNumber),Convert.ToString(element.credit),element.email


                    };

                    var listViewItem = new ListViewItem(row);
                    list.Items.Add(listViewItem);
                }
            }
        }
        public static void SavetoFile(List<College> list)
        {
            CollegeDA.SaveToFile(list);

        }
        public static void ReadFromFile(List<College> listTemp, List<College> listOri, College col, ListView listview)
        {
            listTemp = CollegeDA.ReadFromFile();
            listOri = listTemp;
            col.Display(listOri, listview);
        }
        public static College Search(TextBox key)
        {
            return CollegeDA.Search(key);
        }
        public static College SearchNumber(MaskedTextBox key)
        {
            return CollegeDA.SearchNumber(key);
        }
        public College()
        {
            this.name = "";
            this.street = "";
            this.city = "";
            this.postCode = "";
            this.phoneNumber = "";
            this.faxNumber = "";
            this.credit = 000000;
            this.email = "";



        }
        public College(string na, string st, string ci, string post, MaskedTextBox nu, MaskedTextBox fax, int credit, string em)
        {
            this.name = na;
            this.street = st;
            this.city = ci;
            this.postCode = post;
            this.phoneNumber = nu.Text;
            this.faxNumber = fax.Text;
            this.credit = credit;
            this.email = em;



        }
        public override string ToString()
        {
            string state;
            state = name + "," + street + "," + city + "," + postCode + "," + phoneNumber + "," + faxNumber + "," + credit + "," + email;
            return state;
        }
    }
}

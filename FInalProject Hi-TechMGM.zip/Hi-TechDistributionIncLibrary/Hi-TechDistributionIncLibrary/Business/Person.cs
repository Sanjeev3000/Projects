﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hi_TechDistributionIncLibrary.Business
{
    public class Person
    {

        private string firstname;
        private string lastname;

        public string Firstname
        {
            get
            {
                return firstname;
            }

            set
            {
                firstname = value;
            }
        }

        public string Lastname
        {
            get
            {
                return lastname;
            }

            set
            {
                lastname = value;
            }
        }
        public Person()
        {
            firstname = "";
            lastname = "";

        }
        public Person(string fn, string ln)
        {
            this.firstname = fn;
            this.lastname = ln;


        }
        public Person(string fn)
        {
            this.firstname = fn;
        }
        public override string ToString()
        {
            string state;
            state = firstname + "," + lastname;
            return state;
        }
    }
}

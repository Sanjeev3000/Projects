﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi_TechDistributionIncLibrary.Validator
{
   public class Validator
    {

        private static string message = "Entry Error";

        public static string Message
        {
            get
            {
                return message;
            }
            set
            {
                message = value;
            }
        }

        public static bool IsPresent(TextBox textBox)
        {
            if (textBox.Text == "")
            {
                // click on the keyword Tag and press F1 to have more detail about Tag property
                MessageBox.Show(textBox.Tag + " is a required field.", Message);
                textBox.Focus();
                return false;
            }
            return true;
        }
        public static bool IsPresentMaskedTextBox(MaskedTextBox textBox)
        {
            if (textBox.Text == "")
            {
                // click on the keyword Tag and press F1 to have more detail about Tag property
                MessageBox.Show(textBox.Tag + " is a required field.", Message);
                textBox.Focus();
                return false;
            }
            return true;
        }
        public static bool IsPresentDate(DateTimePicker textBox)
        {
            if (textBox.Text == "")
            {
                // click on the keyword Tag and press F1 to have more detail about Tag property
                MessageBox.Show(textBox.Tag + " is a required field.", Message);
                textBox.Focus();
                return false;
            }
            return true;
        }

        public static bool IsRightNumber(TextBox textBox)
        {
            int number = Convert.ToInt32(textBox.Text);

            if (!(number.ToString().Length == 6)) //if the id does not have 4 digits, send a message using MessageBox control 
            {
                // click on the keyword Tag and press F1 to have more detail about Tag property
                MessageBox.Show(textBox.Tag + " must be 6 digits", Message);
                textBox.Clear(); // clear the textBox
                textBox.Focus(); // set the focus()
                return false;
            }
            return true;
        }
        public static bool IsRightNumberAuthor(TextBox textBox)
        {
            int number = Convert.ToInt32(textBox.Text);

            if (!(number.ToString().Length == 3)) //if the id does not have 4 digits, send a message using MessageBox control 
            {
                // click on the keyword Tag and press F1 to have more detail about Tag property
                MessageBox.Show(textBox.Tag + " must be 3 digits", Message);
                textBox.Clear(); // clear the textBox
                textBox.Focus(); // set the focus()
                return false;
            }
            return true;
        }
        public static bool IsRightNumberISBN(TextBox textBox)
        {
            long number = long.Parse(textBox.Text);

            if (!(number.ToString().Length == 13)) //if the id does not have 4 digits, send a message using MessageBox control 
            {
                // click on the keyword Tag and press F1 to have more detail about Tag property
                MessageBox.Show(textBox.Tag + " must be 13 digits", Message);
                textBox.Clear(); // clear the textBox
                textBox.Focus(); // set the focus()
                return false;
            }
            return true;
        }

        public static bool IsRightNumberOrderID(TextBox textBox)
        {
            int number = Int32.Parse(textBox.Text);

            if (!(number.ToString().Length == 5)) //if the id does not have 4 digits, send a message using MessageBox control 
            {
                // click on the keyword Tag and press F1 to have more detail about Tag property
                MessageBox.Show(textBox.Tag + " must be 5 digits", Message);
                textBox.Clear(); // clear the textBox
                textBox.Focus(); // set the focus()
                return false;
            }
            return true;
        }


        public static bool IsDecimal(TextBox textBox)
        {
            float number = 0f;
            if (float.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                // click on the keyword Tag and press F1 to have more detail about Tag property
                MessageBox.Show(textBox.Tag + " must be a decimal value.", Message);
                textBox.Clear();
                textBox.Focus();
                return false;
            }
        }

        // The IsInt 32 and IsWithinRange methods 
        public static bool IsInt32(TextBox textBox)
        {
            int number = 0;
            if (Int32.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                // click on the keyword Tag and press F1 to have more detail about Tag property
                MessageBox.Show(textBox.Tag + " must be an integer.", Message);
                textBox.Clear();
                textBox.Focus();
                return false;
            }
        }
        public static bool IsLong(TextBox textBox)
        {
            long number = 0;
            if (long.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                // click on the keyword Tag and press F1 to have more detail about Tag property
                MessageBox.Show(textBox.Tag + " must be an long.", Message);
                textBox.Clear();
                textBox.Focus();
                return false;
            }
        }
        public static bool IsInt32MaskedTextBox(MaskedTextBox textBox)
        {
            int number = 0;
            if (Int32.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                // click on the keyword Tag and press F1 to have more detail about Tag property
                MessageBox.Show(textBox.Tag + " must be an integer.", Message);
                textBox.Clear();
                textBox.Focus();
                return false;
            }
        }
        public static bool IsWithinRange(TextBox textBox, decimal min, decimal max)
        {
            decimal number = Convert.ToDecimal(textBox.Text);
            if (number < min || number > max)
            {
                // click on the keyword Tag and press F1 to have more detail about Tag property
                MessageBox.Show(textBox.Tag + " must be between " + min
                    + " and " + max + ".", Message);
                textBox.Clear();
                textBox.Focus();
                return false;
            }
            return true;
        }
        public static bool IsPresentComboBox(ComboBox c1)
        {
            if (c1.Text == "")
            {
                // click on the keyword Tag and press F1 to have more detail about Tag property
                MessageBox.Show(c1.Tag + " is a required field.", Message);
                c1.Focus();
                return false;
            }
            return true;
        }
        public static bool IsSpecialCharacters(TextBox textBox)
        {

            var regexItem = new Regex(@"[~`!@#$%^&*()+=|\{}':;.,<>/?[\]""_-]");
            if (regexItem.IsMatch(textBox.Text))
            {
                MessageBox.Show("Can not contain Special Characters");
                return false;

            }
            return true;

        }
        public static bool IsLetters(TextBox textBox)
        {

            var regexItem = new Regex("^[a-zA-Z]*$");

            if (!regexItem.IsMatch(textBox.Text))
            {
                MessageBox.Show("Can contain only alphabets");
                textBox.Clear();
                textBox.Focus();
                return false;

            }
            return true;

        }

    }
}

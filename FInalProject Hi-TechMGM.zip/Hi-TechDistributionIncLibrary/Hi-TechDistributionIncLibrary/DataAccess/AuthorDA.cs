﻿using Hi_TechDistributionIncLibrary.Business;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi_TechDistributionIncLibrary.DataAccess
{
    public class AuthorDA
    {
        public static string filePathAuthor = Application.StartupPath + @"\Author.dat";
        public static void SaveToFile(List<Authors> list)
        {

            string[] lines = new string[list.Count];
            for (int i = 0; i < list.Count; i++)
            {
                lines[i] = list[i].AuthorID + "," + list[i].Firstname + "," + list[i].Lastname + "," + list[i].City + "," + list[i].Phone;
            }
            File.WriteAllLines(filePathAuthor, lines);
        }
        public static List<Authors> ReadFromFile()
        {
            List<Authors> list = new List<Authors>();
            StreamReader sReader = new StreamReader(filePathAuthor);
            string line = sReader.ReadLine();
            while (line != null)
            {
                string[] fields = line.Split(',');
                Authors a1 = new Authors();
                a1.AuthorID = Int32.Parse(fields[0]);
                a1.Firstname = fields[1];
                a1.Lastname = fields[2];
                a1.City = fields[3];
                a1.Phone = fields[4];
                list.Add(a1);
                line = sReader.ReadLine();

            }
            sReader.Close();
            return list;
        }
        public static Authors SearchByLN(TextBox key)
        {
            if (File.Exists(filePathAuthor))
            {

                StreamReader sReader = new StreamReader(filePathAuthor);
                string line = sReader.ReadLine();
                while (line != null)
                {

                    string[] fields = line.Split(',');
                    if (fields[2] == key.Text)
                    {
                        Authors au = new Authors();
                        au.AuthorID = Int32.Parse(fields[0]);
                        au.Firstname = fields[1];
                        au.Lastname = key.Text;
                        au.City = fields[3];
                        au.Phone = fields[4];
                        sReader.Close();
                        return au;
                    }
                    line = sReader.ReadLine();
                }

            }
            else
            {
                MessageBox.Show("Author not found!Please enter Author data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return (null);




        }
        public static Authors SearchByFN(TextBox key)
        {
            if (File.Exists(filePathAuthor))
            {

                StreamReader sReader = new StreamReader(filePathAuthor);
                string line = sReader.ReadLine();
                while (line != null)
                {

                    string[] fields = line.Split(',');
                    if (fields[1] == key.Text)
                    {
                        Authors au = new Authors();
                        au.AuthorID = Int32.Parse(fields[0]);
                        au.Firstname = key.Text;
                        au.Lastname = fields[2];
                        au.City = fields[3];
                        au.Phone = fields[4];
                        sReader.Close();
                        return au;
                    }
                    line = sReader.ReadLine();
                }

            }
            else
            {
                MessageBox.Show("Author not found!Please enter Author data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return (null);




        }
        public static Authors Search(TextBox key)
        {
            if (File.Exists(filePathAuthor))
            {

                StreamReader sReader = new StreamReader(filePathAuthor);
                string line = sReader.ReadLine();
                while (line != null)
                {

                    string[] fields = line.Split(',');
                    if (fields[0] == key.Text)
                    {
                        Authors au = new Authors();
                        au.AuthorID = Int32.Parse(key.Text);
                        au.Firstname = fields[1];
                        au.Lastname = fields[2];
                        au.City = fields[3];
                        au.Phone = fields[4];
                        sReader.Close();
                        return au;
                    }
                    line = sReader.ReadLine();
                }

            }
            else
            {
                MessageBox.Show("Author not found!Please enter Author data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return (null);









        }
    }
}

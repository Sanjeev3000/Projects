﻿using Hi_TechDistributionIncLibrary.Business;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi_TechDistributionIncLibrary.DataAccess
{
    public class CollegeDA
    {


        public static string filePathCollege = Application.StartupPath + @"\College.dat";

        public static void SaveToFile(List<College> list)
        {

            string[] lines = new string[list.Count];
            for (int i = 0; i < list.Count; i++)
            {
                lines[i] = list[i].Name + "," + list[i].Street + "," + list[i].City + "," + list[i].PostCode + "," + list[i].PhoneNunber + "," + list[i].FaxNumber + "," + list[i].Credit + "," + list[i].Email;
            }
            File.WriteAllLines(filePathCollege, lines);
        }
        public static List<College> ReadFromFile()
        {
            List<College> list = new List<College>();
            StreamReader sReader = new StreamReader(filePathCollege);
            string line = sReader.ReadLine();
            while (line != null)
            {
                string[] fields = line.Split(',');
                College col = new College();
                col.Name = fields[0];
                col.Street = fields[1];
                col.City = fields[2];
                col.PostCode = fields[3];
                col.PhoneNunber = fields[4];
                col.FaxNumber = fields[5];
                col.Credit = Int32.Parse(fields[6]);
                col.Email = fields[7];
                list.Add(col);
                line = sReader.ReadLine();

            }
            sReader.Close();
            return list;
        }
        public static College SearchInfo(List<College> list, string key)
        {
            College col = new College();
            foreach (College item in list)
            {
                if (item.Name == key)
                {
                    col = item;
                }
            }
            return col;
        }
        public static College Search(TextBox key)
        {
            if (File.Exists(filePathCollege))
            {

                StreamReader sReader = new StreamReader(filePathCollege);
                string line = sReader.ReadLine();
                while (line != null)
                {

                    string[] fields = line.Split(',');
                    if (fields[0] == key.Text)
                    {
                        College col = new College();
                        col.Name = fields[0];
                        col.Street = fields[1];
                        col.City = fields[2];
                        col.PostCode = fields[3];
                        col.PhoneNunber = fields[4];
                        col.FaxNumber = fields[5];
                        col.Credit = Int32.Parse(fields[6]);
                        col.Email = fields[7];

                        sReader.Close();
                        return col;
                    }
                    line = sReader.ReadLine();
                }

            }
            else
            {
                MessageBox.Show("Client not found!Please enter Client data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return (null);









        }
        public static College SearchNumber(MaskedTextBox key)
        {
            if (File.Exists(filePathCollege))
            {

                StreamReader sReader = new StreamReader(filePathCollege);
                string line = sReader.ReadLine();
                while (line != null)
                {

                    string[] fields = line.Split(',');
                    if (fields[4] == key.Text)
                    {
                        College col = new College();
                        col.Name = fields[0];
                        col.Street = fields[1];
                        col.City = fields[2];
                        col.PostCode = fields[3];
                        col.PhoneNunber = key.Text;
                        col.FaxNumber = fields[5];
                        col.Credit = Int32.Parse(fields[6]);
                        col.Email = fields[7];

                        sReader.Close();
                        return col;
                    }
                    line = sReader.ReadLine();
                }

            }
            else
            {
                MessageBox.Show("Client not found!Please enter Client data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return (null);









        }
    }
}

﻿using Hi_TechDistributionIncLibrary.Business;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi_TechDistributionIncLibrary.DataAccess
{
    public class PublisherDA
    {


        public static string filePathPublishers = Application.StartupPath + @"\Publisher.dat";
        public static void SaveToFile(List<Publisher> list)
        {

            string[] lines = new string[list.Count];
            for (int i = 0; i < list.Count; i++)
            {
                lines[i] = list[i].PName + "," + list[i].Pphonenumber;
            }
            File.WriteAllLines(filePathPublishers, lines);
        }
        public static List<Publisher> ReadFromFile()
        {
            List<Publisher> list = new List<Publisher>();
            StreamReader sReader = new StreamReader(filePathPublishers);
            string line = sReader.ReadLine();
            while (line != null)
            {
                string[] fields = line.Split(',');
                Publisher p1 = new Publisher();
                p1.PName = fields[0];
                p1.Pphonenumber = fields[1];
                list.Add(p1);
                line = sReader.ReadLine();

            }
            sReader.Close();
            return list;
        }
        public static Publisher Search(TextBox key)
        {
            if (File.Exists(filePathPublishers))
            {

                StreamReader sReader = new StreamReader(filePathPublishers);
                string line = sReader.ReadLine();
                while (line != null)
                {

                    string[] fields = line.Split(',');
                    if (fields[0] == key.Text)
                    {
                        Publisher pub = new Publisher();
                        pub.PName = key.Text;
                        pub.Pphonenumber = fields[1];


                        sReader.Close();
                        return pub;
                    }
                    line = sReader.ReadLine();
                }

            }
            else
            {
                MessageBox.Show("Publisher not found!Please enter Publisher data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return (null);









        }
        public static Publisher SearchNumber(MaskedTextBox key)
        {
            if (File.Exists(filePathPublishers))
            {

                StreamReader sReader = new StreamReader(filePathPublishers);
                string line = sReader.ReadLine();
                while (line != null)
                {

                    string[] fields = line.Split(',');
                    if (fields[1] == key.Text)
                    {
                        Publisher pub = new Publisher();
                        pub.PName = fields[0];
                        pub.Pphonenumber = key.Text;


                        sReader.Close();
                        return pub;
                    }
                    line = sReader.ReadLine();
                }

            }
            else
            {
                MessageBox.Show("Publisher not found!Please enter Publisher data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return (null);









        }

    }
}

﻿using Hi_Tech_Distribution_Inc;
using Hi_Tech_Distribution_Inc.GUI;
using Hi_TechDistributionIncLibrary.Business;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi_TechDistributionIncLibrary.DataAccess
{
    public class UserDA
    {


        public static string filePathUser = Application.StartupPath + @"\User.dat";
        public static List<Employee> ReadFromFile(List<Employee> listOfEmployees)
        {


            string[] lines = File.ReadAllLines(DataAccess.EmployeeDA.filePath);
            Employee emp;
            for (int i = 0; i < lines.Length; i++)
            {
                String[] fields = lines[i].Split(',');
                emp = new Employee();
                emp.EmployeeID = Int32.Parse(fields[0]);
                emp.Firstname = fields[1];
                emp.Lastname = fields[2];
                emp.Status = (EnumStatus)Enum.Parse(typeof(EnumStatus), fields[3]);
                emp.Position = (EnumPosition)Enum.Parse(typeof(EnumPosition), fields[4]);
                listOfEmployees.Add(emp);


            }
            return listOfEmployees;
        }
        public static void Login(LoginForm log, TextBox txtID, TextBox txtPassword, string position)
        {
            Employee emp = new Employee();
            StreamReader sReader = new StreamReader(UserDA.filePathUser);
            bool bypass = false;
            if (File.Exists(EmployeeDA.filePath))
            {

                string line = sReader.ReadLine();
                while (line != null)
                {
                    string[] fields = line.Split(',');
                    if (fields[0] == txtID.Text && fields[1] == txtPassword.Text)
                    {
                        bypass = true;

                    }
                    line = sReader.ReadLine();
                }








            }

            if (bypass)
            {

                frmMIS mainForm = new frmMIS();

                log.Close();


                if (position == Convert.ToString(EnumPosition.MIS_Manager))
                {

                    mainForm.Show();
                    mainForm.tabControlMain.SelectTab(0);
                    mainForm.tabControlMain.TabPages.RemoveAt(3);
                    mainForm.tabControlMain.TabPages.RemoveAt(2);
                    mainForm.tabControlMain.TabPages.RemoveAt(1);


                    sReader.Close();




                }
                if (position == Convert.ToString(EnumPosition.Sales_Manager))
                {

                    mainForm.Show();
                    mainForm.tabControlMain.SelectTab(1);
                    mainForm.tabControlMain.TabPages.RemoveAt(3);
                    mainForm.tabControlMain.TabPages.RemoveAt(2);
                    mainForm.tabControlMain.TabPages.RemoveAt(0);


                    sReader.Close();
                }
                if (position == Convert.ToString(EnumPosition.Inventory_Controller))
                {
                    mainForm.Show();
                    mainForm.tabControlMain.SelectTab(2);
                    mainForm.tabControlMain.TabPages.RemoveAt(3);
                    mainForm.tabControlMain.TabPages.RemoveAt(1);
                    mainForm.tabControlMain.TabPages.RemoveAt(0);
                    sReader.Close();
                }
                if (position == Convert.ToString(EnumPosition.Order_Clerk))
                {
                    mainForm.Show();
                    mainForm.tabControlMain.SelectTab(3);
                    mainForm.tabControlMain.TabPages.RemoveAt(2);
                    mainForm.tabControlMain.TabPages.RemoveAt(1);
                    mainForm.tabControlMain.TabPages.RemoveAt(0);
                    sReader.Close();

                }
            }
            if (!bypass)
            {
                MessageBox.Show("Invalid User");
                log.Show();
            }




        }

        public static List<User> ReadFromFileUsers(List<User> listOfUsers)
        {



            string[] lines = File.ReadAllLines(DataAccess.UserDA.filePathUser);
            User us;
            for (int i = 0; i < lines.Length; i++)
            {
                String[] fields = lines[i].Split(',');
                us = new User();

                us.Username = fields[0];
                us.Password = fields[1];
                listOfUsers.Add(us);


            }
            return listOfUsers;
        }
        public static List<User> ReadFromFileUsers()
        {

            List<User> listOfUsers = new List<User>();

            string[] lines = File.ReadAllLines(DataAccess.UserDA.filePathUser);
            User us;
            for (int i = 0; i < lines.Length; i++)
            {
                String[] fields = lines[i].Split(',');
                us = new User();

                us.Username = fields[0];
                us.Password = fields[1];
                listOfUsers.Add(us);


            }
            return listOfUsers;
        }
        public static void SaveToFile(List<User> list)
        {

            string[] lines = new string[list.Count];
            for (int i = 0; i < list.Count; i++)
            {
                lines[i] = list[i].Username + "," + list[i].Password;
            }
            File.WriteAllLines(filePathUser, lines);
        }
        public static User Search(TextBox key)
        {
            if (File.Exists(filePathUser))
            {

                StreamReader sReader = new StreamReader(filePathUser);
                string line = sReader.ReadLine();
                while (line != null)
                {

                    string[] fields = line.Split(',');
                    if (fields[0] == key.Text)
                    {
                        User us = new User();

                        us.Username = fields[0];
                        us.Password = fields[1];

                        sReader.Close();
                        return us;
                    }
                    line = sReader.ReadLine();
                }

            }
            else
            {
                MessageBox.Show("User not found!Please enter Employee data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return (null);









        }

    }
}

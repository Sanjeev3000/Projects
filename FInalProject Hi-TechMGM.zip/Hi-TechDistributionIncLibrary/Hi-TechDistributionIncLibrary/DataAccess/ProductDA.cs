﻿using Hi_TechDistributionIncLibrary.Business;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi_TechDistributionIncLibrary.DataAccess
{
    public class ProductDA
    {
        public static string filePathProduct = Application.StartupPath + @"\Product.dat";
        public static void SaveToFile(List<Product> list)
        {


            string[] lines = new string[list.Count];
            for (int i = 0; i < list.Count; i++)
            {






                lines[i] = list[i].ISBN + "," + list[i].Title + "," + list[i].UPrice + "," + list[i].YearPublished + "," + list[i].QOH + "," + list[i].ProductType + "," + list[i].Names1 + "," + list[i].Publisher;



            }
            File.WriteAllLines(filePathProduct, lines);



        }
        public static List<Product> ReadFromFile()
        {
            List<Product> list = new List<Product>();
            StreamReader sReader = new StreamReader(filePathProduct);
            string line = sReader.ReadLine();
            while (line != null)
            {
                string[] fields = line.Split(',');
                Product pro = new Product();
                pro.ISBN = long.Parse(fields[0]);
                pro.Title = fields[1];
                pro.UPrice = float.Parse(fields[2]);
                pro.YearPublished = System.DateTime.Parse(fields[3]);
                pro.QOH = Int32.Parse(fields[4]);
                pro.ProductType = (EnumProduct)Enum.Parse(typeof(EnumProduct), fields[5]);
                pro.Names1 = fields[6];
                pro.Publisher = fields[7];

                list.Add(pro);
                line = sReader.ReadLine();

            }
            sReader.Close();
            return list;
        }
        public static Product Search(TextBox key)
        {
            if (File.Exists(filePathProduct))
            {

                StreamReader sReader = new StreamReader(filePathProduct);
                string line = sReader.ReadLine();
                while (line != null)
                {

                    string[] fields = line.Split(',');
                    if (fields[0] == key.Text)
                    {
                        Product pro = new Product();
                        pro.ISBN = long.Parse(key.Text);
                        pro.Title = fields[1];
                        pro.UPrice = float.Parse(fields[2]);
                        pro.YearPublished = System.DateTime.Parse(fields[3]);
                        pro.QOH = Int32.Parse(fields[4]);
                        pro.ProductType = (EnumProduct)Enum.Parse(typeof(EnumProduct), fields[5]);
                        pro.Names1 = fields[6];
                        pro.Publisher = fields[7];


                        sReader.Close();
                        return pro;
                    }
                    line = sReader.ReadLine();
                }

            }
            else
            {
                MessageBox.Show("Product not found!Please enter Product data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return (null);









        }
        public static Product SearchByTitle(TextBox key)
        {
            if (File.Exists(filePathProduct))
            {

                StreamReader sReader = new StreamReader(filePathProduct);
                string line = sReader.ReadLine();
                while (line != null)
                {

                    string[] fields = line.Split(',');
                    if (fields[1] == key.Text)
                    {
                        Product pro = new Product();
                        pro.ISBN = long.Parse(fields[0]);
                        pro.Title = key.Text;
                        pro.UPrice = float.Parse(fields[2]);
                        pro.YearPublished = System.DateTime.Parse(fields[3]);
                        pro.QOH = Int32.Parse(fields[4]);
                        pro.ProductType = (EnumProduct)Enum.Parse(typeof(EnumProduct), fields[5]);
                        pro.Names1 = fields[6];
                        pro.Publisher = fields[7];


                        sReader.Close();
                        return pro;
                    }
                    line = sReader.ReadLine();
                }

            }
            else
            {
                MessageBox.Show("Product not found!Please enter Product data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return (null);
        }
    }
}

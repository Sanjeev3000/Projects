﻿using Hi_TechDistributionIncLibrary.Business;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi_TechDistributionIncLibrary.DataAccess
{
    public class OrderDA
    {
        public static string filePathOrder = Application.StartupPath + @"\Order.dat";



        public static void SaveToFile(List<Order> list)
        {


            string[] lines = new string[list.Count];
            for (int i = 0; i < list.Count; i++)
            {






                lines[i] = list[i].OrderID + "," + list[i].ClientName + "," + list[i].ProductName + "," + list[i].Qty + "," + list[i].ReqDate + "," + list[i].ShipDate + "," + list[i].OrderType + "," + list[i].Subtotal + "," + list[i].Total + "," + list[i].Credit + "," + list[i].AvailableCredit;


            }
            File.WriteAllLines(filePathOrder, lines);



        }
        public static List<Order> ReadFromFile()
        {
            List<Order> list = new List<Order>();
            StreamReader sReader = new StreamReader(filePathOrder);
            string line = sReader.ReadLine();
            while (line != null)
            {
                string[] fields = line.Split(',');
                Order ord = new Order();
                ord.OrderID = Int32.Parse(fields[0]);
                ord.ClientName = fields[1];
                ord.ProductName = fields[2];
                ord.Qty = Int32.Parse(fields[3]);
                ord.ReqDate = DateTime.Parse(fields[4]);
                ord.ShipDate = (EnumShipDate)Enum.Parse(typeof(EnumShipDate), fields[5]);
                ord.OrderType = fields[6];
                ord.Subtotal = float.Parse(fields[7]);
                ord.Total = float.Parse(fields[8]);
                ord.Credit = float.Parse(fields[9]);
                ord.AvailableCredit = float.Parse(fields[10]);

                list.Add(ord);
                line = sReader.ReadLine();

            }
            sReader.Close();
            return list;
        }
        public static Order Search(TextBox key)
        {
            if (File.Exists(filePathOrder))
            {

                StreamReader sReader = new StreamReader(filePathOrder);
                string line = sReader.ReadLine();
                while (line != null)
                {

                    string[] fields = line.Split(',');
                    if (fields[0] == key.Text)
                    {
                        Order ord = new Order();

                        ord.OrderID = Int32.Parse(key.Text);
                        ord.ClientName = fields[1];
                        ord.ProductName = fields[2];
                        ord.Qty = Int32.Parse(fields[3]);
                        ord.ReqDate = DateTime.Parse(fields[4]);
                        ord.ShipDate = (EnumShipDate)Enum.Parse(typeof(EnumShipDate), fields[5]);
                        ord.OrderType = fields[6];
                        ord.Subtotal = float.Parse(fields[7]);
                        ord.Total = float.Parse(fields[8]);
                        ord.Credit = float.Parse(fields[9]);
                        ord.AvailableCredit = float.Parse(fields[10]);

                        sReader.Close();
                        return ord;
                    }
                    line = sReader.ReadLine();
                }

            }
            else
            {
                MessageBox.Show("Order not found!Please enter Order data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return (null);









        }
    }
}

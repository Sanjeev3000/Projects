﻿using Hi_TechDistributionIncLibrary.Business;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi_TechDistributionIncLibrary.DataAccess
{
    public class EmployeeDA
    {
        public static string filePath = Application.StartupPath + @"\Employee.dat";
        public static string fileTemp = Application.StartupPath + @"\TempEmp.dat";
        public static void EmployeeDelete(int empid)
        {


            if (File.Exists(filePath))
            {

                StreamReader sReader = new StreamReader(filePath);
                StreamWriter sWriter = new StreamWriter(fileTemp);


                string line = sReader.ReadLine();
                if (line == null)
                {
                    MessageBox.Show("The File does not contain any data.Please enter Employee data.");
                }
                while (line != null)
                {

                    string[] fields = line.Split(',');

                    if (fields[0] != Convert.ToString(empid))
                    {

                        sWriter.WriteLine(fields[0] + "," + fields[1] + "," + fields[2] + "," + fields[3] + "," + fields[4]);

                    }

                    line = sReader.ReadLine();
                }


                sReader.Close();

                sWriter.Close();

                File.Delete(filePath);

                File.Move(fileTemp, filePath);

            }
            else
            {
                MessageBox.Show("File not found!Please enter Employee data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }




        }
        public static void SaveToFile(List<Employee> list)
        {

            string[] lines = new string[list.Count];
            for (int i = 0; i < list.Count; i++)
            {
                lines[i] = list[i].EmployeeID + "," + list[i].Firstname + "," + list[i].Lastname + "," + list[i].Status + "," + list[i].Position + "," + list[i].Username.Username + "," + list[i].Username.Password;
            }
            File.WriteAllLines(filePath, lines);
        }
        public static List<Employee> ReadFromFile()
        {
            List<Employee> list = new List<Employee>();
            StreamReader sReader = new StreamReader(filePath);
            string line = sReader.ReadLine();
            while (line != null)
            {
                string[] fields = line.Split(',');
                Employee emp = new Employee();
                emp.EmployeeID = Convert.ToInt32(fields[0]);
                emp.Firstname = fields[1];
                emp.Lastname = fields[2];
                emp.Status = (EnumStatus)Enum.Parse(typeof(EnumStatus), fields[3]);
                emp.Position = (EnumPosition)Enum.Parse(typeof(EnumPosition), fields[4]);
                emp.Username = new User(fields[5], fields[6]);
                list.Add(emp);
                line = sReader.ReadLine();

            }
            sReader.Close();
            return list;
        }

        public static Employee SearchInfo(List<Employee> list, string user)
        {
            Employee emp = new Employee();
            foreach (Employee item in list)
            {
                if (item.Username.Username == user)
                {
                    emp = item;
                }
            }
            return emp;
        }
        public static Employee SearchbyID(List<Employee> list, int id)
        {
            Employee emp = new Employee();
            foreach (Employee item in list)
            {
                if (item.EmployeeID == id)
                {
                    emp = item;
                }
            }
            return emp;
        }
        public static Employee SearchbyUs(List<Employee> list, string user)
        {
            Employee emp = new Employee();
            foreach (Employee item in list)
            {
                if (item.Username.Username == user)
                {
                    emp = item;
                }
            }
            return emp;
        }
        public static Employee SearchByFN(TextBox key)
        {
            if (File.Exists(filePath))
            {

                StreamReader sReader = new StreamReader(filePath);
                string line = sReader.ReadLine();
                while (line != null)
                {

                    string[] fields = line.Split(',');
                    if (fields[1] == key.Text)
                    {
                        Employee emp = new Employee();
                        emp.EmployeeID = Int32.Parse(fields[0]);
                        emp.Firstname = key.Text;
                        emp.Lastname = fields[2];
                        emp.Status = (EnumStatus)Enum.Parse(typeof(EnumStatus), fields[3]);
                        emp.Position = (EnumPosition)Enum.Parse(typeof(EnumPosition), fields[4]);
                        emp.Username.Username = fields[5];

                        sReader.Close();
                        return emp;
                    }
                    line = sReader.ReadLine();
                }

            }
            else
            {
                MessageBox.Show("User not found!Please enter Employee data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return (null);




        }
        public static Employee SearchByLN(TextBox key)
        {
            if (File.Exists(filePath))
            {

                StreamReader sReader = new StreamReader(filePath);
                string line = sReader.ReadLine();
                while (line != null)
                {

                    string[] fields = line.Split(',');
                    if (fields[2] == key.Text)
                    {
                        Employee emp = new Employee();
                        emp.EmployeeID = Int32.Parse(fields[0]);
                        emp.Firstname = fields[1];
                        emp.Lastname = key.Text;
                        emp.Status = (EnumStatus)Enum.Parse(typeof(EnumStatus), fields[3]);
                        emp.Position = (EnumPosition)Enum.Parse(typeof(EnumPosition), fields[4]);
                        emp.Username.Username = fields[5];

                        sReader.Close();
                        return emp;
                    }
                    line = sReader.ReadLine();
                }

            }
            else
            {
                MessageBox.Show("User not found!Please enter Employee data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return (null);




        }

        public static Employee Search(TextBox key)
        {
            if (File.Exists(filePath))
            {

                StreamReader sReader = new StreamReader(filePath);
                string line = sReader.ReadLine();
                while (line != null)
                {

                    string[] fields = line.Split(',');
                    if (fields[0] == key.Text)
                    {
                        Employee emp = new Employee();
                        emp.EmployeeID = Int32.Parse(key.Text);
                        emp.Firstname = fields[1];
                        emp.Lastname = fields[2];
                        emp.Status = (EnumStatus)Enum.Parse(typeof(EnumStatus), fields[3]);
                        emp.Position = (EnumPosition)Enum.Parse(typeof(EnumPosition), fields[4]);
                        emp.Username.Username = fields[5];

                        sReader.Close();
                        return emp;
                    }
                    line = sReader.ReadLine();
                }

            }
            else
            {
                MessageBox.Show("User not found!Please enter Employee data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return (null);









        }
    }
}

﻿namespace Hi_Tech_Distribution_Inc
{
    partial class frmMIS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMIS));
            this.tabControlMenu = new System.Windows.Forms.TabControl();
            this.Employee = new System.Windows.Forms.TabPage();
            this.btnClear = new System.Windows.Forms.Button();
            this.comboBoxSearch = new System.Windows.Forms.ComboBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtKey = new System.Windows.Forms.TextBox();
            this.listViewEmployees = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnReadFromFile = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnWriteToFile = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.comboBoxPosition = new System.Windows.Forms.ComboBox();
            this.lblPos = new System.Windows.Forms.Label();
            this.comboBoxStatus = new System.Windows.Forms.ComboBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.txtLn = new System.Windows.Forms.TextBox();
            this.lblLN = new System.Windows.Forms.Label();
            this.txtFn = new System.Windows.Forms.TextBox();
            this.lblFirstname = new System.Windows.Forms.Label();
            this.User = new System.Windows.Forms.TabPage();
            this.btnClearUser = new System.Windows.Forms.Button();
            this.comboBoxSearchUser = new System.Windows.Forms.ComboBox();
            this.btnExit2 = new System.Windows.Forms.Button();
            this.listViewUserD = new System.Windows.Forms.ListView();
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnSearchUser = new System.Windows.Forms.Button();
            this.txtKey2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnUpdateUsers = new System.Windows.Forms.Button();
            this.btnReadUsers = new System.Windows.Forms.Button();
            this.btnUserWriteToFile = new System.Windows.Forms.Button();
            this.txtPW = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtUN = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControlMain = new System.Windows.Forms.TabControl();
            this.tabPageMIS = new System.Windows.Forms.TabPage();
            this.tabPageSales = new System.Windows.Forms.TabPage();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.btnClearSales = new System.Windows.Forms.Button();
            this.maskedTextBoxSearch = new System.Windows.Forms.MaskedTextBox();
            this.comboBoxClientSearch = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnRemoveClients = new System.Windows.Forms.Button();
            this.btnSearchCollege = new System.Windows.Forms.Button();
            this.txtKey3 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.btnViewColleges = new System.Windows.Forms.Button();
            this.btnUpdateCollege = new System.Windows.Forms.Button();
            this.btnSaveCol = new System.Windows.Forms.Button();
            this.btnAddCollege = new System.Windows.Forms.Button();
            this.listViewSchools = new System.Windows.Forms.ListView();
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader30 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txtCredit = new System.Windows.Forms.TextBox();
            this.txtFax = new System.Windows.Forms.MaskedTextBox();
            this.txtPostalCode = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.txtInstituteName = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.MaskedTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPageInventory = new System.Windows.Forms.TabPage();
            this.tabControlinventory = new System.Windows.Forms.TabControl();
            this.tabPagePublishers = new System.Windows.Forms.TabPage();
            this.btnClearPublisher = new System.Windows.Forms.Button();
            this.btnExitP = new System.Windows.Forms.Button();
            this.btnRemovePublishers = new System.Windows.Forms.Button();
            this.btnSearchPublishers = new System.Windows.Forms.Button();
            this.maskedTextBoxSearchPublishers = new System.Windows.Forms.MaskedTextBox();
            this.comboBoxSearchPublishers = new System.Windows.Forms.ComboBox();
            this.txtKey4 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.btnViewPublishers = new System.Windows.Forms.Button();
            this.btnUpdatePublishers = new System.Windows.Forms.Button();
            this.btnSavePublisher = new System.Windows.Forms.Button();
            this.btnAddPublisher = new System.Windows.Forms.Button();
            this.listViewPublishers = new System.Windows.Forms.ListView();
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.maskedTextBoxPhoneNumber = new System.Windows.Forms.MaskedTextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtPPName = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tabPageAuthor = new System.Windows.Forms.TabPage();
            this.btnClearAuthor = new System.Windows.Forms.Button();
            this.btnExitA = new System.Windows.Forms.Button();
            this.btnRemoveAuthors = new System.Windows.Forms.Button();
            this.comboBoxSearchAuthors = new System.Windows.Forms.ComboBox();
            this.btnSearchAuthors = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.txtKey5 = new System.Windows.Forms.TextBox();
            this.btnReadAuthors = new System.Windows.Forms.Button();
            this.btnUpdateAuthors = new System.Windows.Forms.Button();
            this.btnSaveAuthors = new System.Windows.Forms.Button();
            this.btnAddAU = new System.Windows.Forms.Button();
            this.listViewAuthors = new System.Windows.Forms.ListView();
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader21 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader22 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txtPhoneA = new System.Windows.Forms.MaskedTextBox();
            this.txtCityA = new System.Windows.Forms.TextBox();
            this.txtLNA = new System.Windows.Forms.TextBox();
            this.txtFNA = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.tabPageProduct = new System.Windows.Forms.TabPage();
            this.btnSearchProduct = new System.Windows.Forms.Button();
            this.txtKey6 = new System.Windows.Forms.TextBox();
            this.comboBoxSearchProduct = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.btnRemoveProducts = new System.Windows.Forms.Button();
            this.btnUpdateProduct = new System.Windows.Forms.Button();
            this.btnReadProducts = new System.Windows.Forms.Button();
            this.btnSaveProducts = new System.Windows.Forms.Button();
            this.listBoxAuthors = new System.Windows.Forms.ListBox();
            this.btnAuthors = new System.Windows.Forms.Button();
            this.comboBoxPublishers = new System.Windows.Forms.ComboBox();
            this.comboBoxAuthors = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.listViewProduct = new System.Windows.Forms.ListView();
            this.columnHeader23 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader24 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader25 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader26 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader27 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader28 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader29 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.comboBoxProductType = new System.Windows.Forms.ComboBox();
            this.txtQOH = new System.Windows.Forms.TextBox();
            this.dateTimePickerProduct = new System.Windows.Forms.DateTimePicker();
            this.txtUPrice = new System.Windows.Forms.TextBox();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.txtISBN = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.tabPageClerk = new System.Windows.Forms.TabPage();
            this.btnSearchOrders = new System.Windows.Forms.Button();
            this.txtKey7 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.btnReadOrders = new System.Windows.Forms.Button();
            this.btnSaveOrders = new System.Windows.Forms.Button();
            this.listViewChosenProducts = new System.Windows.Forms.ListView();
            this.columnHeader38 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader39 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader40 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader41 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.btnAddOrders = new System.Windows.Forms.Button();
            this.listViewOrders = new System.Windows.Forms.ListView();
            this.columnHeader31 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader32 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader33 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader34 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader35 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader36 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader37 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader42 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader43 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader44 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txtQty = new System.Windows.Forms.TextBox();
            this.btnBuyProducts = new System.Windows.Forms.Button();
            this.comboBoxOrderBy = new System.Windows.Forms.ComboBox();
            this.comboBoxShipDate = new System.Windows.Forms.ComboBox();
            this.dateTimePickerReqDate = new System.Windows.Forms.DateTimePicker();
            this.comboBoxProducts = new System.Windows.Forms.ComboBox();
            this.comboBoxClients = new System.Windows.Forms.ComboBox();
            this.txtOID = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.toolTipSaveReminder = new System.Windows.Forms.ToolTip(this.components);
            this.tabControlMenu.SuspendLayout();
            this.Employee.SuspendLayout();
            this.User.SuspendLayout();
            this.tabControlMain.SuspendLayout();
            this.tabPageMIS.SuspendLayout();
            this.tabPageSales.SuspendLayout();
            this.tabPageInventory.SuspendLayout();
            this.tabControlinventory.SuspendLayout();
            this.tabPagePublishers.SuspendLayout();
            this.tabPageAuthor.SuspendLayout();
            this.tabPageProduct.SuspendLayout();
            this.tabPageClerk.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlMenu
            // 
            this.tabControlMenu.Controls.Add(this.Employee);
            this.tabControlMenu.Controls.Add(this.User);
            this.tabControlMenu.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControlMenu.Location = new System.Drawing.Point(0, 0);
            this.tabControlMenu.Name = "tabControlMenu";
            this.tabControlMenu.SelectedIndex = 0;
            this.tabControlMenu.Size = new System.Drawing.Size(901, 516);
            this.tabControlMenu.TabIndex = 0;
            // 
            // Employee
            // 
            this.Employee.BackColor = System.Drawing.SystemColors.MenuBar;
            this.Employee.Controls.Add(this.btnClear);
            this.Employee.Controls.Add(this.comboBoxSearch);
            this.Employee.Controls.Add(this.btnExit);
            this.Employee.Controls.Add(this.btnRemove);
            this.Employee.Controls.Add(this.btnSearch);
            this.Employee.Controls.Add(this.label1);
            this.Employee.Controls.Add(this.txtKey);
            this.Employee.Controls.Add(this.listViewEmployees);
            this.Employee.Controls.Add(this.btnReadFromFile);
            this.Employee.Controls.Add(this.btnUpdate);
            this.Employee.Controls.Add(this.btnWriteToFile);
            this.Employee.Controls.Add(this.btnSave);
            this.Employee.Controls.Add(this.comboBoxPosition);
            this.Employee.Controls.Add(this.lblPos);
            this.Employee.Controls.Add(this.comboBoxStatus);
            this.Employee.Controls.Add(this.lblStatus);
            this.Employee.Controls.Add(this.txtLn);
            this.Employee.Controls.Add(this.lblLN);
            this.Employee.Controls.Add(this.txtFn);
            this.Employee.Controls.Add(this.lblFirstname);
            this.Employee.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Employee.Location = new System.Drawing.Point(4, 25);
            this.Employee.Name = "Employee";
            this.Employee.Padding = new System.Windows.Forms.Padding(3);
            this.Employee.Size = new System.Drawing.Size(893, 487);
            this.Employee.TabIndex = 0;
            this.Employee.Text = "Employee Control";
            this.Employee.Click += new System.EventHandler(this.Employee_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(324, 96);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(213, 36);
            this.btnClear.TabIndex = 19;
            this.btnClear.Text = "Clear";
            this.toolTipSaveReminder.SetToolTip(this.btnClear, "Don\'t Forget to Save!");
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // comboBoxSearch
            // 
            this.comboBoxSearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSearch.FormattingEnabled = true;
            this.comboBoxSearch.Location = new System.Drawing.Point(10, 153);
            this.comboBoxSearch.Name = "comboBoxSearch";
            this.comboBoxSearch.Size = new System.Drawing.Size(86, 25);
            this.comboBoxSearch.TabIndex = 18;
            this.comboBoxSearch.SelectedIndexChanged += new System.EventHandler(this.comboBoxSearch_SelectedIndexChanged);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(742, 452);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(76, 23);
            this.btnExit.TabIndex = 17;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(499, 175);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(74, 30);
            this.btnRemove.TabIndex = 16;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(207, 155);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(89, 25);
            this.btnSearch.TabIndex = 15;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 16);
            this.label1.TabIndex = 14;
            this.label1.Text = "Search by:";
            // 
            // txtKey
            // 
            this.txtKey.Location = new System.Drawing.Point(101, 155);
            this.txtKey.Name = "txtKey";
            this.txtKey.Size = new System.Drawing.Size(100, 23);
            this.txtKey.TabIndex = 13;
            this.txtKey.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtKey_KeyPress);
            // 
            // listViewEmployees
            // 
            this.listViewEmployees.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.listViewEmployees.Location = new System.Drawing.Point(9, 211);
            this.listViewEmployees.Name = "listViewEmployees";
            this.listViewEmployees.Size = new System.Drawing.Size(564, 201);
            this.listViewEmployees.TabIndex = 8;
            this.listViewEmployees.UseCompatibleStateImageBehavior = false;
            this.listViewEmployees.SelectedIndexChanged += new System.EventHandler(this.listViewEmployees_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Employee ID:";
            this.columnHeader1.Width = 100;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Employee\'s First Name: ";
            this.columnHeader2.Width = 130;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Employee\'s Last Name:";
            this.columnHeader3.Width = 130;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Status:";
            this.columnHeader4.Width = 100;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Position:";
            this.columnHeader5.Width = 100;
            // 
            // btnReadFromFile
            // 
            this.btnReadFromFile.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnReadFromFile.Location = new System.Drawing.Point(324, 57);
            this.btnReadFromFile.Name = "btnReadFromFile";
            this.btnReadFromFile.Size = new System.Drawing.Size(213, 36);
            this.btnReadFromFile.TabIndex = 12;
            this.btnReadFromFile.Text = "View Employees";
            this.btnReadFromFile.UseVisualStyleBackColor = true;
            this.btnReadFromFile.Click += new System.EventHandler(this.btnReadFromFile_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(393, 10);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(69, 36);
            this.btnUpdate.TabIndex = 11;
            this.btnUpdate.Text = "Update to List";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnWriteToFile
            // 
            this.btnWriteToFile.Location = new System.Drawing.Point(468, 11);
            this.btnWriteToFile.Name = "btnWriteToFile";
            this.btnWriteToFile.Size = new System.Drawing.Size(69, 35);
            this.btnWriteToFile.TabIndex = 10;
            this.btnWriteToFile.Text = "Save";
            this.btnWriteToFile.UseVisualStyleBackColor = true;
            this.btnWriteToFile.Click += new System.EventHandler(this.btnWriteToFile_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(324, 10);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(63, 36);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Add to List";
            this.toolTipSaveReminder.SetToolTip(this.btnSave, "Don\'t Forget to Save!");
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // comboBoxPosition
            // 
            this.comboBoxPosition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxPosition.FormattingEnabled = true;
            this.comboBoxPosition.Location = new System.Drawing.Point(89, 96);
            this.comboBoxPosition.Name = "comboBoxPosition";
            this.comboBoxPosition.Size = new System.Drawing.Size(151, 25);
            this.comboBoxPosition.TabIndex = 7;
            // 
            // lblPos
            // 
            this.lblPos.AutoSize = true;
            this.lblPos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPos.Location = new System.Drawing.Point(6, 97);
            this.lblPos.Name = "lblPos";
            this.lblPos.Size = new System.Drawing.Size(59, 16);
            this.lblPos.TabIndex = 6;
            this.lblPos.Text = "Position:";
            // 
            // comboBoxStatus
            // 
            this.comboBoxStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxStatus.FormattingEnabled = true;
            this.comboBoxStatus.Location = new System.Drawing.Point(89, 68);
            this.comboBoxStatus.Name = "comboBoxStatus";
            this.comboBoxStatus.Size = new System.Drawing.Size(151, 25);
            this.comboBoxStatus.TabIndex = 5;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.Location = new System.Drawing.Point(7, 68);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(48, 16);
            this.lblStatus.TabIndex = 4;
            this.lblStatus.Text = "Status:";
            // 
            // txtLn
            // 
            this.txtLn.Location = new System.Drawing.Point(89, 40);
            this.txtLn.Name = "txtLn";
            this.txtLn.Size = new System.Drawing.Size(151, 23);
            this.txtLn.TabIndex = 3;
            // 
            // lblLN
            // 
            this.lblLN.AutoSize = true;
            this.lblLN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLN.Location = new System.Drawing.Point(7, 40);
            this.lblLN.Name = "lblLN";
            this.lblLN.Size = new System.Drawing.Size(77, 16);
            this.lblLN.TabIndex = 2;
            this.lblLN.Text = "Last-Name:";
            this.lblLN.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtFn
            // 
            this.txtFn.Location = new System.Drawing.Point(89, 13);
            this.txtFn.Name = "txtFn";
            this.txtFn.Size = new System.Drawing.Size(151, 23);
            this.txtFn.TabIndex = 1;
            // 
            // lblFirstname
            // 
            this.lblFirstname.AutoSize = true;
            this.lblFirstname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstname.Location = new System.Drawing.Point(6, 14);
            this.lblFirstname.Name = "lblFirstname";
            this.lblFirstname.Size = new System.Drawing.Size(77, 16);
            this.lblFirstname.TabIndex = 0;
            this.lblFirstname.Text = "First-Name:";
            // 
            // User
            // 
            this.User.BackColor = System.Drawing.Color.GhostWhite;
            this.User.Controls.Add(this.btnClearUser);
            this.User.Controls.Add(this.comboBoxSearchUser);
            this.User.Controls.Add(this.btnExit2);
            this.User.Controls.Add(this.listViewUserD);
            this.User.Controls.Add(this.btnSearchUser);
            this.User.Controls.Add(this.txtKey2);
            this.User.Controls.Add(this.label6);
            this.User.Controls.Add(this.btnUpdateUsers);
            this.User.Controls.Add(this.btnReadUsers);
            this.User.Controls.Add(this.btnUserWriteToFile);
            this.User.Controls.Add(this.txtPW);
            this.User.Controls.Add(this.label3);
            this.User.Controls.Add(this.txtUN);
            this.User.Controls.Add(this.label2);
            this.User.Location = new System.Drawing.Point(4, 25);
            this.User.Name = "User";
            this.User.Padding = new System.Windows.Forms.Padding(3);
            this.User.Size = new System.Drawing.Size(893, 487);
            this.User.TabIndex = 1;
            this.User.Text = "Users Control";
            // 
            // btnClearUser
            // 
            this.btnClearUser.Location = new System.Drawing.Point(196, 65);
            this.btnClearUser.Name = "btnClearUser";
            this.btnClearUser.Size = new System.Drawing.Size(45, 31);
            this.btnClearUser.TabIndex = 23;
            this.btnClearUser.Text = "Clear";
            this.toolTipSaveReminder.SetToolTip(this.btnClearUser, "Don\'t Forget to Save!");
            this.btnClearUser.UseVisualStyleBackColor = true;
            this.btnClearUser.Click += new System.EventHandler(this.btnClearUser_Click);
            // 
            // comboBoxSearchUser
            // 
            this.comboBoxSearchUser.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSearchUser.FormattingEnabled = true;
            this.comboBoxSearchUser.Location = new System.Drawing.Point(276, 24);
            this.comboBoxSearchUser.Name = "comboBoxSearchUser";
            this.comboBoxSearchUser.Size = new System.Drawing.Size(100, 24);
            this.comboBoxSearchUser.TabIndex = 22;
            // 
            // btnExit2
            // 
            this.btnExit2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit2.Location = new System.Drawing.Point(749, 456);
            this.btnExit2.Name = "btnExit2";
            this.btnExit2.Size = new System.Drawing.Size(76, 23);
            this.btnExit2.TabIndex = 21;
            this.btnExit2.Text = "Exit";
            this.btnExit2.UseVisualStyleBackColor = true;
            this.btnExit2.Click += new System.EventHandler(this.btnExit2_Click);
            // 
            // listViewUserD
            // 
            this.listViewUserD.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader11});
            this.listViewUserD.Location = new System.Drawing.Point(9, 107);
            this.listViewUserD.Name = "listViewUserD";
            this.listViewUserD.Size = new System.Drawing.Size(564, 201);
            this.listViewUserD.TabIndex = 20;
            this.listViewUserD.UseCompatibleStateImageBehavior = false;
            this.listViewUserD.SelectedIndexChanged += new System.EventHandler(this.listViewUserD_SelectedIndexChanged);
            this.listViewUserD.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listViewUserD_MouseDoubleClick);
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Employee ID:";
            this.columnHeader6.Width = 100;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Employee\'s UserName: ";
            this.columnHeader7.Width = 130;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Employee\'s Password:";
            // 
            // btnSearchUser
            // 
            this.btnSearchUser.Location = new System.Drawing.Point(496, 24);
            this.btnSearchUser.Name = "btnSearchUser";
            this.btnSearchUser.Size = new System.Drawing.Size(101, 28);
            this.btnSearchUser.TabIndex = 19;
            this.btnSearchUser.Text = "Search";
            this.btnSearchUser.UseVisualStyleBackColor = true;
            this.btnSearchUser.Click += new System.EventHandler(this.btnSearchUser_Click);
            // 
            // txtKey2
            // 
            this.txtKey2.Location = new System.Drawing.Point(382, 26);
            this.txtKey2.Name = "txtKey2";
            this.txtKey2.Size = new System.Drawing.Size(108, 22);
            this.txtKey2.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(273, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 16);
            this.label6.TabIndex = 17;
            this.label6.Text = "Search by :";
            // 
            // btnUpdateUsers
            // 
            this.btnUpdateUsers.Location = new System.Drawing.Point(367, 64);
            this.btnUpdateUsers.Name = "btnUpdateUsers";
            this.btnUpdateUsers.Size = new System.Drawing.Size(101, 28);
            this.btnUpdateUsers.TabIndex = 15;
            this.btnUpdateUsers.Text = "Update";
            this.btnUpdateUsers.UseVisualStyleBackColor = true;
            this.btnUpdateUsers.Click += new System.EventHandler(this.btnUpdateUsers_Click);
            // 
            // btnReadUsers
            // 
            this.btnReadUsers.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnReadUsers.Location = new System.Drawing.Point(245, 64);
            this.btnReadUsers.Name = "btnReadUsers";
            this.btnReadUsers.Size = new System.Drawing.Size(101, 29);
            this.btnReadUsers.TabIndex = 11;
            this.btnReadUsers.Text = "View Users";
            this.btnReadUsers.UseVisualStyleBackColor = true;
            this.btnReadUsers.Click += new System.EventHandler(this.btnReadUsers_Click);
            // 
            // btnUserWriteToFile
            // 
            this.btnUserWriteToFile.Location = new System.Drawing.Point(496, 65);
            this.btnUserWriteToFile.Name = "btnUserWriteToFile";
            this.btnUserWriteToFile.Size = new System.Drawing.Size(101, 28);
            this.btnUserWriteToFile.TabIndex = 10;
            this.btnUserWriteToFile.Text = "Save";
            this.btnUserWriteToFile.UseVisualStyleBackColor = true;
            this.btnUserWriteToFile.Click += new System.EventHandler(this.btnUserWriteToFile_Click);
            // 
            // txtPW
            // 
            this.txtPW.Location = new System.Drawing.Point(90, 83);
            this.txtPW.Name = "txtPW";
            this.txtPW.Size = new System.Drawing.Size(100, 22);
            this.txtPW.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Password:";
            // 
            // txtUN
            // 
            this.txtUN.Location = new System.Drawing.Point(90, 56);
            this.txtUN.Name = "txtUN";
            this.txtUN.Size = new System.Drawing.Size(100, 22);
            this.txtUN.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "UserName:";
            // 
            // tabControlMain
            // 
            this.tabControlMain.Controls.Add(this.tabPageMIS);
            this.tabControlMain.Controls.Add(this.tabPageSales);
            this.tabControlMain.Controls.Add(this.tabPageInventory);
            this.tabControlMain.Controls.Add(this.tabPageClerk);
            this.tabControlMain.Location = new System.Drawing.Point(1, -2);
            this.tabControlMain.Name = "tabControlMain";
            this.tabControlMain.SelectedIndex = 0;
            this.tabControlMain.Size = new System.Drawing.Size(855, 542);
            this.tabControlMain.TabIndex = 5;
            // 
            // tabPageMIS
            // 
            this.tabPageMIS.BackColor = System.Drawing.Color.GhostWhite;
            this.tabPageMIS.Controls.Add(this.tabControlMenu);
            this.tabPageMIS.Location = new System.Drawing.Point(4, 22);
            this.tabPageMIS.Name = "tabPageMIS";
            this.tabPageMIS.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageMIS.Size = new System.Drawing.Size(847, 516);
            this.tabPageMIS.TabIndex = 1;
            this.tabPageMIS.Text = "MIS Manager";
            // 
            // tabPageSales
            // 
            this.tabPageSales.BackColor = System.Drawing.SystemColors.Menu;
            this.tabPageSales.Controls.Add(this.txtEmail);
            this.tabPageSales.Controls.Add(this.label30);
            this.tabPageSales.Controls.Add(this.btnClearSales);
            this.tabPageSales.Controls.Add(this.maskedTextBoxSearch);
            this.tabPageSales.Controls.Add(this.comboBoxClientSearch);
            this.tabPageSales.Controls.Add(this.button1);
            this.tabPageSales.Controls.Add(this.btnRemoveClients);
            this.tabPageSales.Controls.Add(this.btnSearchCollege);
            this.tabPageSales.Controls.Add(this.txtKey3);
            this.tabPageSales.Controls.Add(this.label12);
            this.tabPageSales.Controls.Add(this.btnViewColleges);
            this.tabPageSales.Controls.Add(this.btnUpdateCollege);
            this.tabPageSales.Controls.Add(this.btnSaveCol);
            this.tabPageSales.Controls.Add(this.btnAddCollege);
            this.tabPageSales.Controls.Add(this.listViewSchools);
            this.tabPageSales.Controls.Add(this.txtCredit);
            this.tabPageSales.Controls.Add(this.txtFax);
            this.tabPageSales.Controls.Add(this.txtPostalCode);
            this.tabPageSales.Controls.Add(this.txtCity);
            this.tabPageSales.Controls.Add(this.txtStreet);
            this.tabPageSales.Controls.Add(this.txtInstituteName);
            this.tabPageSales.Controls.Add(this.txtPhone);
            this.tabPageSales.Controls.Add(this.label11);
            this.tabPageSales.Controls.Add(this.label10);
            this.tabPageSales.Controls.Add(this.label9);
            this.tabPageSales.Controls.Add(this.label8);
            this.tabPageSales.Controls.Add(this.label7);
            this.tabPageSales.Controls.Add(this.label5);
            this.tabPageSales.Controls.Add(this.label4);
            this.tabPageSales.Location = new System.Drawing.Point(4, 22);
            this.tabPageSales.Name = "tabPageSales";
            this.tabPageSales.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSales.Size = new System.Drawing.Size(847, 516);
            this.tabPageSales.TabIndex = 2;
            this.tabPageSales.Text = "Sales Manager";
            this.tabPageSales.Click += new System.EventHandler(this.tabPageSales_Click);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(169, 292);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(109, 20);
            this.txtEmail.TabIndex = 28;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(22, 295);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(35, 13);
            this.label30.TabIndex = 27;
            this.label30.Text = "Email:";
            // 
            // btnClearSales
            // 
            this.btnClearSales.Location = new System.Drawing.Point(183, 376);
            this.btnClearSales.Name = "btnClearSales";
            this.btnClearSales.Size = new System.Drawing.Size(76, 24);
            this.btnClearSales.TabIndex = 26;
            this.btnClearSales.Text = "Clear";
            this.toolTipSaveReminder.SetToolTip(this.btnClearSales, "Don\'t Forget to Save!");
            this.btnClearSales.UseVisualStyleBackColor = true;
            this.btnClearSales.Click += new System.EventHandler(this.btnClearSales_Click);
            // 
            // maskedTextBoxSearch
            // 
            this.maskedTextBoxSearch.Location = new System.Drawing.Point(169, 444);
            this.maskedTextBoxSearch.Mask = "(999) 000-0000";
            this.maskedTextBoxSearch.Name = "maskedTextBoxSearch";
            this.maskedTextBoxSearch.Size = new System.Drawing.Size(109, 20);
            this.maskedTextBoxSearch.TabIndex = 25;
            this.maskedTextBoxSearch.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBoxSearch_MaskInputRejected);
            // 
            // comboBoxClientSearch
            // 
            this.comboBoxClientSearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxClientSearch.FormattingEnabled = true;
            this.comboBoxClientSearch.Location = new System.Drawing.Point(11, 427);
            this.comboBoxClientSearch.Name = "comboBoxClientSearch";
            this.comboBoxClientSearch.Size = new System.Drawing.Size(153, 21);
            this.comboBoxClientSearch.TabIndex = 24;
            this.comboBoxClientSearch.SelectedIndexChanged += new System.EventHandler(this.comboBoxClientSearch_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button1.Location = new System.Drawing.Point(765, 493);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(76, 23);
            this.button1.TabIndex = 23;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnRemoveClients
            // 
            this.btnRemoveClients.Location = new System.Drawing.Point(7, 469);
            this.btnRemoveClients.Name = "btnRemoveClients";
            this.btnRemoveClients.Size = new System.Drawing.Size(82, 29);
            this.btnRemoveClients.TabIndex = 22;
            this.btnRemoveClients.Text = "Remove";
            this.btnRemoveClients.UseVisualStyleBackColor = true;
            this.btnRemoveClients.Click += new System.EventHandler(this.btnRemoveClients_Click);
            // 
            // btnSearchCollege
            // 
            this.btnSearchCollege.Location = new System.Drawing.Point(170, 470);
            this.btnSearchCollege.Name = "btnSearchCollege";
            this.btnSearchCollege.Size = new System.Drawing.Size(101, 28);
            this.btnSearchCollege.TabIndex = 21;
            this.btnSearchCollege.Text = "Search";
            this.btnSearchCollege.UseVisualStyleBackColor = true;
            this.btnSearchCollege.Click += new System.EventHandler(this.btnSearchCollege_Click);
            // 
            // txtKey3
            // 
            this.txtKey3.Location = new System.Drawing.Point(169, 418);
            this.txtKey3.Name = "txtKey3";
            this.txtKey3.Size = new System.Drawing.Size(108, 20);
            this.txtKey3.TabIndex = 20;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(8, 408);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 16);
            this.label12.TabIndex = 19;
            this.label12.Text = "Search by :";
            // 
            // btnViewColleges
            // 
            this.btnViewColleges.Location = new System.Drawing.Point(95, 374);
            this.btnViewColleges.Name = "btnViewColleges";
            this.btnViewColleges.Size = new System.Drawing.Size(82, 29);
            this.btnViewColleges.TabIndex = 18;
            this.btnViewColleges.Text = "View Clients";
            this.btnViewColleges.UseVisualStyleBackColor = true;
            this.btnViewColleges.Click += new System.EventHandler(this.btnViewColleges_Click);
            // 
            // btnUpdateCollege
            // 
            this.btnUpdateCollege.Location = new System.Drawing.Point(7, 374);
            this.btnUpdateCollege.Name = "btnUpdateCollege";
            this.btnUpdateCollege.Size = new System.Drawing.Size(82, 29);
            this.btnUpdateCollege.TabIndex = 17;
            this.btnUpdateCollege.Text = "Update";
            this.btnUpdateCollege.UseVisualStyleBackColor = true;
            this.btnUpdateCollege.Click += new System.EventHandler(this.btnUpdateCollege_Click);
            // 
            // btnSaveCol
            // 
            this.btnSaveCol.Location = new System.Drawing.Point(95, 339);
            this.btnSaveCol.Name = "btnSaveCol";
            this.btnSaveCol.Size = new System.Drawing.Size(82, 29);
            this.btnSaveCol.TabIndex = 16;
            this.btnSaveCol.Text = "Save";
            this.btnSaveCol.UseVisualStyleBackColor = true;
            this.btnSaveCol.Click += new System.EventHandler(this.btnSaveCol_Click);
            // 
            // btnAddCollege
            // 
            this.btnAddCollege.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnAddCollege.Location = new System.Drawing.Point(7, 339);
            this.btnAddCollege.Name = "btnAddCollege";
            this.btnAddCollege.Size = new System.Drawing.Size(82, 29);
            this.btnAddCollege.TabIndex = 15;
            this.btnAddCollege.Text = "Add to List";
            this.toolTipSaveReminder.SetToolTip(this.btnAddCollege, "Don\'t Forget to Save!");
            this.btnAddCollege.UseVisualStyleBackColor = true;
            this.btnAddCollege.Click += new System.EventHandler(this.btnAddCollege_Click);
            // 
            // listViewSchools
            // 
            this.listViewSchools.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15,
            this.columnHeader30});
            this.listViewSchools.Location = new System.Drawing.Point(284, 6);
            this.listViewSchools.Name = "listViewSchools";
            this.listViewSchools.Size = new System.Drawing.Size(557, 481);
            this.listViewSchools.TabIndex = 14;
            this.listViewSchools.UseCompatibleStateImageBehavior = false;
            this.listViewSchools.SelectedIndexChanged += new System.EventHandler(this.listViewSchools_SelectedIndexChanged);
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Name:";
            this.columnHeader8.Width = 100;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Street:";
            this.columnHeader9.Width = 100;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "City:";
            this.columnHeader10.Width = 70;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "PostalCode:";
            this.columnHeader12.Width = 100;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "PhoneNumber:";
            this.columnHeader13.Width = 100;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "FaxNumber:";
            this.columnHeader14.Width = 100;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Credit:";
            this.columnHeader15.Width = 100;
            // 
            // columnHeader30
            // 
            this.columnHeader30.Text = "Email:";
            this.columnHeader30.Width = 150;
            // 
            // txtCredit
            // 
            this.txtCredit.Location = new System.Drawing.Point(169, 259);
            this.txtCredit.Name = "txtCredit";
            this.txtCredit.Size = new System.Drawing.Size(109, 20);
            this.txtCredit.TabIndex = 13;
            // 
            // txtFax
            // 
            this.txtFax.Location = new System.Drawing.Point(169, 220);
            this.txtFax.Mask = "(999) 000-0000";
            this.txtFax.Name = "txtFax";
            this.txtFax.Size = new System.Drawing.Size(109, 20);
            this.txtFax.TabIndex = 12;
            // 
            // txtPostalCode
            // 
            this.txtPostalCode.Location = new System.Drawing.Point(169, 137);
            this.txtPostalCode.Name = "txtPostalCode";
            this.txtPostalCode.Size = new System.Drawing.Size(109, 20);
            this.txtPostalCode.TabIndex = 11;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(169, 102);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(109, 20);
            this.txtCity.TabIndex = 10;
            // 
            // txtStreet
            // 
            this.txtStreet.Location = new System.Drawing.Point(169, 62);
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.Size = new System.Drawing.Size(109, 20);
            this.txtStreet.TabIndex = 9;
            // 
            // txtInstituteName
            // 
            this.txtInstituteName.Location = new System.Drawing.Point(169, 23);
            this.txtInstituteName.Name = "txtInstituteName";
            this.txtInstituteName.Size = new System.Drawing.Size(109, 20);
            this.txtInstituteName.TabIndex = 8;
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(169, 185);
            this.txtPhone.Mask = "(999) 000-0000";
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(109, 20);
            this.txtPhone.TabIndex = 7;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(22, 262);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 13);
            this.label11.TabIndex = 6;
            this.label11.Text = "Credit Limit:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(22, 223);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 13);
            this.label10.TabIndex = 5;
            this.label10.Text = "Fax Number:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(22, 185);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "Phone Number:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(22, 144);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "Postal Code:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 102);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(27, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "City:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Street:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "College\'s/University\'s Name:";
            // 
            // tabPageInventory
            // 
            this.tabPageInventory.Controls.Add(this.tabControlinventory);
            this.tabPageInventory.Location = new System.Drawing.Point(4, 22);
            this.tabPageInventory.Name = "tabPageInventory";
            this.tabPageInventory.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageInventory.Size = new System.Drawing.Size(847, 516);
            this.tabPageInventory.TabIndex = 3;
            this.tabPageInventory.Text = "Inventory Controller";
            // 
            // tabControlinventory
            // 
            this.tabControlinventory.Controls.Add(this.tabPagePublishers);
            this.tabControlinventory.Controls.Add(this.tabPageAuthor);
            this.tabControlinventory.Controls.Add(this.tabPageProduct);
            this.tabControlinventory.Location = new System.Drawing.Point(0, 0);
            this.tabControlinventory.Name = "tabControlinventory";
            this.tabControlinventory.SelectedIndex = 0;
            this.tabControlinventory.Size = new System.Drawing.Size(841, 516);
            this.tabControlinventory.TabIndex = 0;
            // 
            // tabPagePublishers
            // 
            this.tabPagePublishers.BackColor = System.Drawing.SystemColors.Menu;
            this.tabPagePublishers.Controls.Add(this.btnClearPublisher);
            this.tabPagePublishers.Controls.Add(this.btnExitP);
            this.tabPagePublishers.Controls.Add(this.btnRemovePublishers);
            this.tabPagePublishers.Controls.Add(this.btnSearchPublishers);
            this.tabPagePublishers.Controls.Add(this.maskedTextBoxSearchPublishers);
            this.tabPagePublishers.Controls.Add(this.comboBoxSearchPublishers);
            this.tabPagePublishers.Controls.Add(this.txtKey4);
            this.tabPagePublishers.Controls.Add(this.label15);
            this.tabPagePublishers.Controls.Add(this.btnViewPublishers);
            this.tabPagePublishers.Controls.Add(this.btnUpdatePublishers);
            this.tabPagePublishers.Controls.Add(this.btnSavePublisher);
            this.tabPagePublishers.Controls.Add(this.btnAddPublisher);
            this.tabPagePublishers.Controls.Add(this.listViewPublishers);
            this.tabPagePublishers.Controls.Add(this.maskedTextBoxPhoneNumber);
            this.tabPagePublishers.Controls.Add(this.label14);
            this.tabPagePublishers.Controls.Add(this.txtPPName);
            this.tabPagePublishers.Controls.Add(this.label13);
            this.tabPagePublishers.Location = new System.Drawing.Point(4, 22);
            this.tabPagePublishers.Name = "tabPagePublishers";
            this.tabPagePublishers.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePublishers.Size = new System.Drawing.Size(833, 490);
            this.tabPagePublishers.TabIndex = 0;
            this.tabPagePublishers.Text = "Publisher Management";
            this.tabPagePublishers.Click += new System.EventHandler(this.tabPagePublishers_Click);
            // 
            // btnClearPublisher
            // 
            this.btnClearPublisher.Location = new System.Drawing.Point(334, 76);
            this.btnClearPublisher.Name = "btnClearPublisher";
            this.btnClearPublisher.Size = new System.Drawing.Size(76, 24);
            this.btnClearPublisher.TabIndex = 33;
            this.btnClearPublisher.Text = "Clear";
            this.toolTipSaveReminder.SetToolTip(this.btnClearPublisher, "Don\'t Forget to Save!");
            this.btnClearPublisher.UseVisualStyleBackColor = true;
            this.btnClearPublisher.Click += new System.EventHandler(this.btnClearPublisher_Click);
            // 
            // btnExitP
            // 
            this.btnExitP.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExitP.Location = new System.Drawing.Point(708, 459);
            this.btnExitP.Name = "btnExitP";
            this.btnExitP.Size = new System.Drawing.Size(76, 23);
            this.btnExitP.TabIndex = 32;
            this.btnExitP.Text = "Exit";
            this.btnExitP.UseVisualStyleBackColor = true;
            this.btnExitP.Click += new System.EventHandler(this.btnExitP_Click);
            // 
            // btnRemovePublishers
            // 
            this.btnRemovePublishers.Location = new System.Drawing.Point(701, 283);
            this.btnRemovePublishers.Name = "btnRemovePublishers";
            this.btnRemovePublishers.Size = new System.Drawing.Size(82, 29);
            this.btnRemovePublishers.TabIndex = 31;
            this.btnRemovePublishers.Text = "Remove";
            this.btnRemovePublishers.UseVisualStyleBackColor = true;
            this.btnRemovePublishers.Click += new System.EventHandler(this.btnRemovePublishers_Click);
            // 
            // btnSearchPublishers
            // 
            this.btnSearchPublishers.Location = new System.Drawing.Point(675, 85);
            this.btnSearchPublishers.Name = "btnSearchPublishers";
            this.btnSearchPublishers.Size = new System.Drawing.Size(108, 28);
            this.btnSearchPublishers.TabIndex = 30;
            this.btnSearchPublishers.Text = "Search";
            this.btnSearchPublishers.UseVisualStyleBackColor = true;
            this.btnSearchPublishers.Click += new System.EventHandler(this.btnSearchPublishers_Click);
            // 
            // maskedTextBoxSearchPublishers
            // 
            this.maskedTextBoxSearchPublishers.Location = new System.Drawing.Point(675, 59);
            this.maskedTextBoxSearchPublishers.Mask = "(999) 000-0000";
            this.maskedTextBoxSearchPublishers.Name = "maskedTextBoxSearchPublishers";
            this.maskedTextBoxSearchPublishers.Size = new System.Drawing.Size(109, 20);
            this.maskedTextBoxSearchPublishers.TabIndex = 29;
            // 
            // comboBoxSearchPublishers
            // 
            this.comboBoxSearchPublishers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSearchPublishers.FormattingEnabled = true;
            this.comboBoxSearchPublishers.Location = new System.Drawing.Point(517, 42);
            this.comboBoxSearchPublishers.Name = "comboBoxSearchPublishers";
            this.comboBoxSearchPublishers.Size = new System.Drawing.Size(153, 21);
            this.comboBoxSearchPublishers.TabIndex = 28;
            this.comboBoxSearchPublishers.SelectedIndexChanged += new System.EventHandler(this.comboBoxSearchPublishers_SelectedIndexChanged);
            // 
            // txtKey4
            // 
            this.txtKey4.Location = new System.Drawing.Point(675, 33);
            this.txtKey4.Name = "txtKey4";
            this.txtKey4.Size = new System.Drawing.Size(108, 20);
            this.txtKey4.TabIndex = 27;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(514, 23);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(75, 16);
            this.label15.TabIndex = 26;
            this.label15.Text = "Search by :";
            // 
            // btnViewPublishers
            // 
            this.btnViewPublishers.Location = new System.Drawing.Point(416, 41);
            this.btnViewPublishers.Name = "btnViewPublishers";
            this.btnViewPublishers.Size = new System.Drawing.Size(95, 29);
            this.btnViewPublishers.TabIndex = 22;
            this.btnViewPublishers.Text = "View Publishers";
            this.btnViewPublishers.UseVisualStyleBackColor = true;
            this.btnViewPublishers.Click += new System.EventHandler(this.btnViewPublishers_Click);
            // 
            // btnUpdatePublishers
            // 
            this.btnUpdatePublishers.Location = new System.Drawing.Point(328, 41);
            this.btnUpdatePublishers.Name = "btnUpdatePublishers";
            this.btnUpdatePublishers.Size = new System.Drawing.Size(82, 29);
            this.btnUpdatePublishers.TabIndex = 21;
            this.btnUpdatePublishers.Text = "Update";
            this.btnUpdatePublishers.UseVisualStyleBackColor = true;
            this.btnUpdatePublishers.Click += new System.EventHandler(this.btnUpdatePublishers_Click);
            // 
            // btnSavePublisher
            // 
            this.btnSavePublisher.Location = new System.Drawing.Point(416, 6);
            this.btnSavePublisher.Name = "btnSavePublisher";
            this.btnSavePublisher.Size = new System.Drawing.Size(95, 29);
            this.btnSavePublisher.TabIndex = 20;
            this.btnSavePublisher.Text = "Save";
            this.btnSavePublisher.UseVisualStyleBackColor = true;
            this.btnSavePublisher.Click += new System.EventHandler(this.btnSavePublisher_Click);
            // 
            // btnAddPublisher
            // 
            this.btnAddPublisher.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnAddPublisher.Location = new System.Drawing.Point(328, 6);
            this.btnAddPublisher.Name = "btnAddPublisher";
            this.btnAddPublisher.Size = new System.Drawing.Size(82, 29);
            this.btnAddPublisher.TabIndex = 19;
            this.btnAddPublisher.Text = "Add to List";
            this.toolTipSaveReminder.SetToolTip(this.btnAddPublisher, "Don\'t Forget to Save!");
            this.btnAddPublisher.UseVisualStyleBackColor = true;
            this.btnAddPublisher.Click += new System.EventHandler(this.btnAddPublisher_Click);
            // 
            // listViewPublishers
            // 
            this.listViewPublishers.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader16,
            this.columnHeader17});
            this.listViewPublishers.Location = new System.Drawing.Point(6, 101);
            this.listViewPublishers.Name = "listViewPublishers";
            this.listViewPublishers.Size = new System.Drawing.Size(600, 383);
            this.listViewPublishers.TabIndex = 9;
            this.listViewPublishers.UseCompatibleStateImageBehavior = false;
            this.listViewPublishers.SelectedIndexChanged += new System.EventHandler(this.listViewPublishers_SelectedIndexChanged);
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Publisher\'s Name:";
            this.columnHeader16.Width = 300;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "Publisher\'s Number:";
            this.columnHeader17.Width = 300;
            // 
            // maskedTextBoxPhoneNumber
            // 
            this.maskedTextBoxPhoneNumber.Location = new System.Drawing.Point(146, 43);
            this.maskedTextBoxPhoneNumber.Mask = "(999) 000-0000";
            this.maskedTextBoxPhoneNumber.Name = "maskedTextBoxPhoneNumber";
            this.maskedTextBoxPhoneNumber.Size = new System.Drawing.Size(109, 20);
            this.maskedTextBoxPhoneNumber.TabIndex = 8;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 46);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(134, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "Publisher\'s Phone Number:";
            // 
            // txtPPName
            // 
            this.txtPPName.Location = new System.Drawing.Point(100, 11);
            this.txtPPName.Name = "txtPPName";
            this.txtPPName.Size = new System.Drawing.Size(98, 20);
            this.txtPPName.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 14);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "Publisher\'s Name:";
            // 
            // tabPageAuthor
            // 
            this.tabPageAuthor.BackColor = System.Drawing.SystemColors.Menu;
            this.tabPageAuthor.Controls.Add(this.btnClearAuthor);
            this.tabPageAuthor.Controls.Add(this.btnExitA);
            this.tabPageAuthor.Controls.Add(this.btnRemoveAuthors);
            this.tabPageAuthor.Controls.Add(this.comboBoxSearchAuthors);
            this.tabPageAuthor.Controls.Add(this.btnSearchAuthors);
            this.tabPageAuthor.Controls.Add(this.label20);
            this.tabPageAuthor.Controls.Add(this.txtKey5);
            this.tabPageAuthor.Controls.Add(this.btnReadAuthors);
            this.tabPageAuthor.Controls.Add(this.btnUpdateAuthors);
            this.tabPageAuthor.Controls.Add(this.btnSaveAuthors);
            this.tabPageAuthor.Controls.Add(this.btnAddAU);
            this.tabPageAuthor.Controls.Add(this.listViewAuthors);
            this.tabPageAuthor.Controls.Add(this.txtPhoneA);
            this.tabPageAuthor.Controls.Add(this.txtCityA);
            this.tabPageAuthor.Controls.Add(this.txtLNA);
            this.tabPageAuthor.Controls.Add(this.txtFNA);
            this.tabPageAuthor.Controls.Add(this.label16);
            this.tabPageAuthor.Controls.Add(this.label17);
            this.tabPageAuthor.Controls.Add(this.label18);
            this.tabPageAuthor.Controls.Add(this.label19);
            this.tabPageAuthor.Location = new System.Drawing.Point(4, 22);
            this.tabPageAuthor.Name = "tabPageAuthor";
            this.tabPageAuthor.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageAuthor.Size = new System.Drawing.Size(833, 490);
            this.tabPageAuthor.TabIndex = 1;
            this.tabPageAuthor.Text = "Author Management";
            // 
            // btnClearAuthor
            // 
            this.btnClearAuthor.Location = new System.Drawing.Point(543, 70);
            this.btnClearAuthor.Name = "btnClearAuthor";
            this.btnClearAuthor.Size = new System.Drawing.Size(76, 24);
            this.btnClearAuthor.TabIndex = 34;
            this.btnClearAuthor.Text = "Clear";
            this.toolTipSaveReminder.SetToolTip(this.btnClearAuthor, "Don\'t Forget to Save!");
            this.btnClearAuthor.UseVisualStyleBackColor = true;
            this.btnClearAuthor.Click += new System.EventHandler(this.btnClearAuthor_Click);
            // 
            // btnExitA
            // 
            this.btnExitA.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExitA.Location = new System.Drawing.Point(707, 459);
            this.btnExitA.Name = "btnExitA";
            this.btnExitA.Size = new System.Drawing.Size(76, 23);
            this.btnExitA.TabIndex = 33;
            this.btnExitA.Text = "Exit";
            this.btnExitA.UseVisualStyleBackColor = true;
            this.btnExitA.Click += new System.EventHandler(this.btnExitA_Click);
            // 
            // btnRemoveAuthors
            // 
            this.btnRemoveAuthors.Location = new System.Drawing.Point(496, 332);
            this.btnRemoveAuthors.Name = "btnRemoveAuthors";
            this.btnRemoveAuthors.Size = new System.Drawing.Size(74, 30);
            this.btnRemoveAuthors.TabIndex = 24;
            this.btnRemoveAuthors.Text = "Remove";
            this.btnRemoveAuthors.UseVisualStyleBackColor = true;
            this.btnRemoveAuthors.Click += new System.EventHandler(this.btnRemoveAuthors_Click);
            // 
            // comboBoxSearchAuthors
            // 
            this.comboBoxSearchAuthors.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSearchAuthors.FormattingEnabled = true;
            this.comboBoxSearchAuthors.Location = new System.Drawing.Point(333, 36);
            this.comboBoxSearchAuthors.Name = "comboBoxSearchAuthors";
            this.comboBoxSearchAuthors.Size = new System.Drawing.Size(86, 21);
            this.comboBoxSearchAuthors.TabIndex = 23;
            // 
            // btnSearchAuthors
            // 
            this.btnSearchAuthors.Location = new System.Drawing.Point(530, 38);
            this.btnSearchAuthors.Name = "btnSearchAuthors";
            this.btnSearchAuthors.Size = new System.Drawing.Size(89, 25);
            this.btnSearchAuthors.TabIndex = 22;
            this.btnSearchAuthors.Text = "Search";
            this.btnSearchAuthors.UseVisualStyleBackColor = true;
            this.btnSearchAuthors.Click += new System.EventHandler(this.btnSearchAuthors_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(330, 16);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(72, 16);
            this.label20.TabIndex = 21;
            this.label20.Text = "Search by:";
            // 
            // txtKey5
            // 
            this.txtKey5.Location = new System.Drawing.Point(424, 38);
            this.txtKey5.Name = "txtKey5";
            this.txtKey5.Size = new System.Drawing.Size(100, 20);
            this.txtKey5.TabIndex = 20;
            // 
            // btnReadAuthors
            // 
            this.btnReadAuthors.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnReadAuthors.Location = new System.Drawing.Point(11, 374);
            this.btnReadAuthors.Name = "btnReadAuthors";
            this.btnReadAuthors.Size = new System.Drawing.Size(213, 36);
            this.btnReadAuthors.TabIndex = 19;
            this.btnReadAuthors.Text = "View Authors";
            this.btnReadAuthors.UseVisualStyleBackColor = true;
            this.btnReadAuthors.Click += new System.EventHandler(this.btnReadAuthors_Click);
            // 
            // btnUpdateAuthors
            // 
            this.btnUpdateAuthors.Location = new System.Drawing.Point(80, 332);
            this.btnUpdateAuthors.Name = "btnUpdateAuthors";
            this.btnUpdateAuthors.Size = new System.Drawing.Size(69, 36);
            this.btnUpdateAuthors.TabIndex = 18;
            this.btnUpdateAuthors.Text = "Update to List";
            this.btnUpdateAuthors.UseVisualStyleBackColor = true;
            this.btnUpdateAuthors.Click += new System.EventHandler(this.btnUpdateAuthors_Click);
            // 
            // btnSaveAuthors
            // 
            this.btnSaveAuthors.Location = new System.Drawing.Point(155, 333);
            this.btnSaveAuthors.Name = "btnSaveAuthors";
            this.btnSaveAuthors.Size = new System.Drawing.Size(69, 35);
            this.btnSaveAuthors.TabIndex = 17;
            this.btnSaveAuthors.Text = "Save";
            this.btnSaveAuthors.UseVisualStyleBackColor = true;
            this.btnSaveAuthors.Click += new System.EventHandler(this.btnSaveAuthors_Click);
            // 
            // btnAddAU
            // 
            this.btnAddAU.Location = new System.Drawing.Point(11, 332);
            this.btnAddAU.Name = "btnAddAU";
            this.btnAddAU.Size = new System.Drawing.Size(63, 36);
            this.btnAddAU.TabIndex = 16;
            this.btnAddAU.Tag = "";
            this.btnAddAU.Text = "Add to List";
            this.toolTipSaveReminder.SetToolTip(this.btnAddAU, "Don\'t Forget to Save!");
            this.btnAddAU.UseVisualStyleBackColor = true;
            this.btnAddAU.Click += new System.EventHandler(this.btnAddAU_Click);
            // 
            // listViewAuthors
            // 
            this.listViewAuthors.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader18,
            this.columnHeader19,
            this.columnHeader20,
            this.columnHeader21,
            this.columnHeader22});
            this.listViewAuthors.Location = new System.Drawing.Point(6, 125);
            this.listViewAuthors.Name = "listViewAuthors";
            this.listViewAuthors.Size = new System.Drawing.Size(564, 201);
            this.listViewAuthors.TabIndex = 15;
            this.listViewAuthors.UseCompatibleStateImageBehavior = false;
            this.listViewAuthors.SelectedIndexChanged += new System.EventHandler(this.listViewAuthors_SelectedIndexChanged);
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "Author\'s ID";
            this.columnHeader18.Width = 100;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "Author\'s First Name: ";
            this.columnHeader19.Width = 130;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "Author\'s Last Name:";
            this.columnHeader20.Width = 130;
            // 
            // columnHeader21
            // 
            this.columnHeader21.Text = "City:";
            this.columnHeader21.Width = 100;
            // 
            // columnHeader22
            // 
            this.columnHeader22.Text = "PhoneNumber:";
            this.columnHeader22.Width = 100;
            // 
            // txtPhoneA
            // 
            this.txtPhoneA.Location = new System.Drawing.Point(113, 99);
            this.txtPhoneA.Mask = "(999) 000-0000";
            this.txtPhoneA.Name = "txtPhoneA";
            this.txtPhoneA.Size = new System.Drawing.Size(79, 20);
            this.txtPhoneA.TabIndex = 14;
            // 
            // txtCityA
            // 
            this.txtCityA.Location = new System.Drawing.Point(89, 70);
            this.txtCityA.Name = "txtCityA";
            this.txtCityA.Size = new System.Drawing.Size(151, 20);
            this.txtCityA.TabIndex = 13;
            // 
            // txtLNA
            // 
            this.txtLNA.Location = new System.Drawing.Point(89, 42);
            this.txtLNA.Name = "txtLNA";
            this.txtLNA.Size = new System.Drawing.Size(151, 20);
            this.txtLNA.TabIndex = 12;
            this.txtLNA.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtFNA
            // 
            this.txtFNA.Location = new System.Drawing.Point(89, 15);
            this.txtFNA.Name = "txtFNA";
            this.txtFNA.Size = new System.Drawing.Size(151, 20);
            this.txtFNA.TabIndex = 11;
            this.txtFNA.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(6, 99);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(101, 16);
            this.label16.TabIndex = 10;
            this.label16.Text = "Phone Number:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(7, 70);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(33, 16);
            this.label17.TabIndex = 9;
            this.label17.Text = "City:";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(7, 42);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(77, 16);
            this.label18.TabIndex = 8;
            this.label18.Text = "Last-Name:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(6, 16);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(77, 16);
            this.label19.TabIndex = 7;
            this.label19.Text = "First-Name:";
            // 
            // tabPageProduct
            // 
            this.tabPageProduct.BackColor = System.Drawing.SystemColors.Menu;
            this.tabPageProduct.Controls.Add(this.btnSearchProduct);
            this.tabPageProduct.Controls.Add(this.txtKey6);
            this.tabPageProduct.Controls.Add(this.comboBoxSearchProduct);
            this.tabPageProduct.Controls.Add(this.label29);
            this.tabPageProduct.Controls.Add(this.btnRemoveProducts);
            this.tabPageProduct.Controls.Add(this.btnUpdateProduct);
            this.tabPageProduct.Controls.Add(this.btnReadProducts);
            this.tabPageProduct.Controls.Add(this.btnSaveProducts);
            this.tabPageProduct.Controls.Add(this.listBoxAuthors);
            this.tabPageProduct.Controls.Add(this.btnAuthors);
            this.tabPageProduct.Controls.Add(this.comboBoxPublishers);
            this.tabPageProduct.Controls.Add(this.comboBoxAuthors);
            this.tabPageProduct.Controls.Add(this.label28);
            this.tabPageProduct.Controls.Add(this.label27);
            this.tabPageProduct.Controls.Add(this.btnAddProduct);
            this.tabPageProduct.Controls.Add(this.listViewProduct);
            this.tabPageProduct.Controls.Add(this.comboBoxProductType);
            this.tabPageProduct.Controls.Add(this.txtQOH);
            this.tabPageProduct.Controls.Add(this.dateTimePickerProduct);
            this.tabPageProduct.Controls.Add(this.txtUPrice);
            this.tabPageProduct.Controls.Add(this.txtTitle);
            this.tabPageProduct.Controls.Add(this.txtISBN);
            this.tabPageProduct.Controls.Add(this.label26);
            this.tabPageProduct.Controls.Add(this.label25);
            this.tabPageProduct.Controls.Add(this.label21);
            this.tabPageProduct.Controls.Add(this.label22);
            this.tabPageProduct.Controls.Add(this.label23);
            this.tabPageProduct.Controls.Add(this.label24);
            this.tabPageProduct.Location = new System.Drawing.Point(4, 22);
            this.tabPageProduct.Name = "tabPageProduct";
            this.tabPageProduct.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageProduct.Size = new System.Drawing.Size(833, 490);
            this.tabPageProduct.TabIndex = 2;
            this.tabPageProduct.Text = "Product Management";
            // 
            // btnSearchProduct
            // 
            this.btnSearchProduct.Location = new System.Drawing.Point(460, 110);
            this.btnSearchProduct.Name = "btnSearchProduct";
            this.btnSearchProduct.Size = new System.Drawing.Size(89, 25);
            this.btnSearchProduct.TabIndex = 38;
            this.btnSearchProduct.Text = "Search";
            this.btnSearchProduct.UseVisualStyleBackColor = true;
            this.btnSearchProduct.Click += new System.EventHandler(this.btnSearchProduct_Click);
            // 
            // txtKey6
            // 
            this.txtKey6.Location = new System.Drawing.Point(354, 110);
            this.txtKey6.Name = "txtKey6";
            this.txtKey6.Size = new System.Drawing.Size(100, 20);
            this.txtKey6.TabIndex = 37;
            // 
            // comboBoxSearchProduct
            // 
            this.comboBoxSearchProduct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSearchProduct.FormattingEnabled = true;
            this.comboBoxSearchProduct.Location = new System.Drawing.Point(260, 110);
            this.comboBoxSearchProduct.Name = "comboBoxSearchProduct";
            this.comboBoxSearchProduct.Size = new System.Drawing.Size(86, 21);
            this.comboBoxSearchProduct.TabIndex = 36;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(257, 91);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(72, 16);
            this.label29.TabIndex = 35;
            this.label29.Text = "Search by:";
            // 
            // btnRemoveProducts
            // 
            this.btnRemoveProducts.Location = new System.Drawing.Point(745, 3);
            this.btnRemoveProducts.Name = "btnRemoveProducts";
            this.btnRemoveProducts.Size = new System.Drawing.Size(82, 29);
            this.btnRemoveProducts.TabIndex = 34;
            this.btnRemoveProducts.Text = "Remove";
            this.btnRemoveProducts.UseVisualStyleBackColor = true;
            this.btnRemoveProducts.Click += new System.EventHandler(this.btnRemoveProducts_Click);
            // 
            // btnUpdateProduct
            // 
            this.btnUpdateProduct.Location = new System.Drawing.Point(650, 159);
            this.btnUpdateProduct.Name = "btnUpdateProduct";
            this.btnUpdateProduct.Size = new System.Drawing.Size(89, 26);
            this.btnUpdateProduct.TabIndex = 33;
            this.btnUpdateProduct.Text = "Update";
            this.toolTipSaveReminder.SetToolTip(this.btnUpdateProduct, "Don\'t Forget to Save!");
            this.btnUpdateProduct.UseVisualStyleBackColor = true;
            this.btnUpdateProduct.Click += new System.EventHandler(this.btnUpdateProduct_Click);
            // 
            // btnReadProducts
            // 
            this.btnReadProducts.Location = new System.Drawing.Point(555, 159);
            this.btnReadProducts.Name = "btnReadProducts";
            this.btnReadProducts.Size = new System.Drawing.Size(89, 26);
            this.btnReadProducts.TabIndex = 32;
            this.btnReadProducts.Text = "View Products";
            this.toolTipSaveReminder.SetToolTip(this.btnReadProducts, "Don\'t Forget to Save!");
            this.btnReadProducts.UseVisualStyleBackColor = true;
            this.btnReadProducts.Click += new System.EventHandler(this.btnReadProducts_Click);
            // 
            // btnSaveProducts
            // 
            this.btnSaveProducts.Location = new System.Drawing.Point(426, 159);
            this.btnSaveProducts.Name = "btnSaveProducts";
            this.btnSaveProducts.Size = new System.Drawing.Size(89, 26);
            this.btnSaveProducts.TabIndex = 31;
            this.btnSaveProducts.Text = "Save";
            this.toolTipSaveReminder.SetToolTip(this.btnSaveProducts, "Don\'t Forget to Save!");
            this.btnSaveProducts.UseVisualStyleBackColor = true;
            this.btnSaveProducts.Click += new System.EventHandler(this.btnSaveProducts_Click);
            // 
            // listBoxAuthors
            // 
            this.listBoxAuthors.FormattingEnabled = true;
            this.listBoxAuthors.Location = new System.Drawing.Point(536, 3);
            this.listBoxAuthors.Name = "listBoxAuthors";
            this.listBoxAuthors.Size = new System.Drawing.Size(120, 95);
            this.listBoxAuthors.TabIndex = 30;
            // 
            // btnAuthors
            // 
            this.btnAuthors.Location = new System.Drawing.Point(441, 14);
            this.btnAuthors.Name = "btnAuthors";
            this.btnAuthors.Size = new System.Drawing.Size(89, 26);
            this.btnAuthors.TabIndex = 29;
            this.btnAuthors.Text = "Add Authors";
            this.toolTipSaveReminder.SetToolTip(this.btnAuthors, "Don\'t Forget to Save!");
            this.btnAuthors.UseVisualStyleBackColor = true;
            this.btnAuthors.Click += new System.EventHandler(this.btnAuthors_Click);
            // 
            // comboBoxPublishers
            // 
            this.comboBoxPublishers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxPublishers.FormattingEnabled = true;
            this.comboBoxPublishers.Location = new System.Drawing.Point(319, 44);
            this.comboBoxPublishers.Name = "comboBoxPublishers";
            this.comboBoxPublishers.Size = new System.Drawing.Size(116, 21);
            this.comboBoxPublishers.TabIndex = 28;
            // 
            // comboBoxAuthors
            // 
            this.comboBoxAuthors.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxAuthors.FormattingEnabled = true;
            this.comboBoxAuthors.Location = new System.Drawing.Point(319, 16);
            this.comboBoxAuthors.Name = "comboBoxAuthors";
            this.comboBoxAuthors.Size = new System.Drawing.Size(116, 21);
            this.comboBoxAuthors.TabIndex = 27;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(257, 45);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(67, 16);
            this.label28.TabIndex = 26;
            this.label28.Text = "Publisher:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(257, 19);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(56, 16);
            this.label27.TabIndex = 25;
            this.label27.Text = "Authors:";
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.Location = new System.Drawing.Point(319, 159);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(89, 26);
            this.btnAddProduct.TabIndex = 24;
            this.btnAddProduct.Text = "Add to List";
            this.toolTipSaveReminder.SetToolTip(this.btnAddProduct, "Don\'t Forget to Save!");
            this.btnAddProduct.UseVisualStyleBackColor = true;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // listViewProduct
            // 
            this.listViewProduct.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader23,
            this.columnHeader24,
            this.columnHeader25,
            this.columnHeader26,
            this.columnHeader27,
            this.columnHeader28,
            this.columnHeader29});
            this.listViewProduct.Location = new System.Drawing.Point(6, 186);
            this.listViewProduct.Name = "listViewProduct";
            this.listViewProduct.Size = new System.Drawing.Size(821, 296);
            this.listViewProduct.TabIndex = 23;
            this.listViewProduct.UseCompatibleStateImageBehavior = false;
            this.listViewProduct.SelectedIndexChanged += new System.EventHandler(this.listViewProduct_SelectedIndexChanged);
            // 
            // columnHeader23
            // 
            this.columnHeader23.Text = "ISBN";
            this.columnHeader23.Width = 150;
            // 
            // columnHeader24
            // 
            this.columnHeader24.Text = "Title";
            this.columnHeader24.Width = 100;
            // 
            // columnHeader25
            // 
            this.columnHeader25.Text = "Unit Price";
            this.columnHeader25.Width = 150;
            // 
            // columnHeader26
            // 
            this.columnHeader26.Text = "Published Date";
            this.columnHeader26.Width = 150;
            // 
            // columnHeader27
            // 
            this.columnHeader27.Text = "Quantity On Hand";
            this.columnHeader27.Width = 150;
            // 
            // columnHeader28
            // 
            this.columnHeader28.Text = "Product Type";
            this.columnHeader28.Width = 150;
            // 
            // columnHeader29
            // 
            this.columnHeader29.Text = "Publisher:";
            this.columnHeader29.Width = 100;
            // 
            // comboBoxProductType
            // 
            this.comboBoxProductType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxProductType.FormattingEnabled = true;
            this.comboBoxProductType.Location = new System.Drawing.Point(119, 159);
            this.comboBoxProductType.Name = "comboBoxProductType";
            this.comboBoxProductType.Size = new System.Drawing.Size(116, 21);
            this.comboBoxProductType.TabIndex = 22;
            // 
            // txtQOH
            // 
            this.txtQOH.Location = new System.Drawing.Point(119, 128);
            this.txtQOH.Name = "txtQOH";
            this.txtQOH.Size = new System.Drawing.Size(117, 20);
            this.txtQOH.TabIndex = 21;
            // 
            // dateTimePickerProduct
            // 
            this.dateTimePickerProduct.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerProduct.Location = new System.Drawing.Point(119, 101);
            this.dateTimePickerProduct.Name = "dateTimePickerProduct";
            this.dateTimePickerProduct.Size = new System.Drawing.Size(117, 20);
            this.dateTimePickerProduct.TabIndex = 20;
            // 
            // txtUPrice
            // 
            this.txtUPrice.Location = new System.Drawing.Point(119, 72);
            this.txtUPrice.Name = "txtUPrice";
            this.txtUPrice.Size = new System.Drawing.Size(117, 20);
            this.txtUPrice.TabIndex = 19;
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(119, 44);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(117, 20);
            this.txtTitle.TabIndex = 18;
            // 
            // txtISBN
            // 
            this.txtISBN.Location = new System.Drawing.Point(119, 18);
            this.txtISBN.Name = "txtISBN";
            this.txtISBN.Size = new System.Drawing.Size(117, 20);
            this.txtISBN.TabIndex = 17;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(16, 159);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(92, 16);
            this.label26.TabIndex = 16;
            this.label26.Text = "Product Type:";
            this.toolTipSaveReminder.SetToolTip(this.label26, "Quantity On Hand");
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(16, 129);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(41, 16);
            this.label25.TabIndex = 15;
            this.label25.Text = "QOH:";
            this.toolTipSaveReminder.SetToolTip(this.label25, "Quantity On Hand");
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(15, 102);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(103, 16);
            this.label21.TabIndex = 14;
            this.label21.Text = "Published Date:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(16, 73);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(68, 16);
            this.label22.TabIndex = 12;
            this.label22.Text = "Unit Price:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(16, 45);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(37, 16);
            this.label23.TabIndex = 10;
            this.label23.Text = "Title:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(15, 19);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(42, 16);
            this.label24.TabIndex = 8;
            this.label24.Text = "ISBN:";
            // 
            // tabPageClerk
            // 
            this.tabPageClerk.BackColor = System.Drawing.SystemColors.Menu;
            this.tabPageClerk.Controls.Add(this.btnSearchOrders);
            this.tabPageClerk.Controls.Add(this.txtKey7);
            this.tabPageClerk.Controls.Add(this.label37);
            this.tabPageClerk.Controls.Add(this.btnReadOrders);
            this.tabPageClerk.Controls.Add(this.btnSaveOrders);
            this.tabPageClerk.Controls.Add(this.listViewChosenProducts);
            this.tabPageClerk.Controls.Add(this.txtPrice);
            this.tabPageClerk.Controls.Add(this.btnAddOrders);
            this.tabPageClerk.Controls.Add(this.listViewOrders);
            this.tabPageClerk.Controls.Add(this.txtQty);
            this.tabPageClerk.Controls.Add(this.btnBuyProducts);
            this.tabPageClerk.Controls.Add(this.comboBoxOrderBy);
            this.tabPageClerk.Controls.Add(this.comboBoxShipDate);
            this.tabPageClerk.Controls.Add(this.dateTimePickerReqDate);
            this.tabPageClerk.Controls.Add(this.comboBoxProducts);
            this.tabPageClerk.Controls.Add(this.comboBoxClients);
            this.tabPageClerk.Controls.Add(this.txtOID);
            this.tabPageClerk.Controls.Add(this.label38);
            this.tabPageClerk.Controls.Add(this.label31);
            this.tabPageClerk.Controls.Add(this.label32);
            this.tabPageClerk.Controls.Add(this.label33);
            this.tabPageClerk.Controls.Add(this.label34);
            this.tabPageClerk.Controls.Add(this.label35);
            this.tabPageClerk.Controls.Add(this.label36);
            this.tabPageClerk.Location = new System.Drawing.Point(4, 22);
            this.tabPageClerk.Name = "tabPageClerk";
            this.tabPageClerk.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageClerk.Size = new System.Drawing.Size(847, 516);
            this.tabPageClerk.TabIndex = 4;
            this.tabPageClerk.Text = "Order Clerk";
            // 
            // btnSearchOrders
            // 
            this.btnSearchOrders.Location = new System.Drawing.Point(737, 198);
            this.btnSearchOrders.Name = "btnSearchOrders";
            this.btnSearchOrders.Size = new System.Drawing.Size(54, 24);
            this.btnSearchOrders.TabIndex = 46;
            this.btnSearchOrders.Text = "Search";
            this.btnSearchOrders.UseVisualStyleBackColor = true;
            this.btnSearchOrders.Click += new System.EventHandler(this.btnSearchOrders_Click);
            // 
            // txtKey7
            // 
            this.txtKey7.Location = new System.Drawing.Point(631, 201);
            this.txtKey7.Name = "txtKey7";
            this.txtKey7.Size = new System.Drawing.Size(100, 20);
            this.txtKey7.TabIndex = 45;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(537, 202);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(88, 16);
            this.label37.TabIndex = 43;
            this.label37.Text = "Search by ID:";
            // 
            // btnReadOrders
            // 
            this.btnReadOrders.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnReadOrders.Location = new System.Drawing.Point(434, 195);
            this.btnReadOrders.Name = "btnReadOrders";
            this.btnReadOrders.Size = new System.Drawing.Size(82, 29);
            this.btnReadOrders.TabIndex = 42;
            this.btnReadOrders.Text = "View Orders";
            this.toolTipSaveReminder.SetToolTip(this.btnReadOrders, "Don\'t Forget to Save!");
            this.btnReadOrders.UseVisualStyleBackColor = true;
            this.btnReadOrders.Click += new System.EventHandler(this.btnReadOrders_Click);
            // 
            // btnSaveOrders
            // 
            this.btnSaveOrders.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnSaveOrders.Location = new System.Drawing.Point(314, 196);
            this.btnSaveOrders.Name = "btnSaveOrders";
            this.btnSaveOrders.Size = new System.Drawing.Size(82, 29);
            this.btnSaveOrders.TabIndex = 41;
            this.btnSaveOrders.Text = "Save";
            this.toolTipSaveReminder.SetToolTip(this.btnSaveOrders, "Don\'t Forget to Save!");
            this.btnSaveOrders.UseVisualStyleBackColor = true;
            this.btnSaveOrders.Click += new System.EventHandler(this.btnSaveOrders_Click);
            // 
            // listViewChosenProducts
            // 
            this.listViewChosenProducts.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader38,
            this.columnHeader39,
            this.columnHeader40,
            this.columnHeader41});
            this.listViewChosenProducts.Location = new System.Drawing.Point(344, 18);
            this.listViewChosenProducts.Name = "listViewChosenProducts";
            this.listViewChosenProducts.Size = new System.Drawing.Size(418, 151);
            this.listViewChosenProducts.TabIndex = 40;
            this.listViewChosenProducts.UseCompatibleStateImageBehavior = false;
            // 
            // columnHeader38
            // 
            this.columnHeader38.Text = "Product\'s Name:";
            this.columnHeader38.Width = 100;
            // 
            // columnHeader39
            // 
            this.columnHeader39.Text = "Qty:";
            this.columnHeader39.Width = 100;
            // 
            // columnHeader40
            // 
            this.columnHeader40.Text = "UnitPrice:";
            this.columnHeader40.Width = 100;
            // 
            // columnHeader41
            // 
            this.columnHeader41.Text = "SubTotal:";
            this.columnHeader41.Width = 100;
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(203, 67);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.ReadOnly = true;
            this.txtPrice.Size = new System.Drawing.Size(45, 20);
            this.txtPrice.TabIndex = 39;
            // 
            // btnAddOrders
            // 
            this.btnAddOrders.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnAddOrders.Location = new System.Drawing.Point(216, 195);
            this.btnAddOrders.Name = "btnAddOrders";
            this.btnAddOrders.Size = new System.Drawing.Size(82, 29);
            this.btnAddOrders.TabIndex = 37;
            this.btnAddOrders.Text = "Add to List";
            this.toolTipSaveReminder.SetToolTip(this.btnAddOrders, "Don\'t Forget to Save!");
            this.btnAddOrders.UseVisualStyleBackColor = true;
            this.btnAddOrders.Click += new System.EventHandler(this.btnAddOrders_Click);
            // 
            // listViewOrders
            // 
            this.listViewOrders.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader31,
            this.columnHeader32,
            this.columnHeader33,
            this.columnHeader34,
            this.columnHeader35,
            this.columnHeader36,
            this.columnHeader37,
            this.columnHeader42,
            this.columnHeader43,
            this.columnHeader44});
            this.listViewOrders.Location = new System.Drawing.Point(3, 230);
            this.listViewOrders.Name = "listViewOrders";
            this.listViewOrders.Size = new System.Drawing.Size(773, 177);
            this.listViewOrders.TabIndex = 36;
            this.listViewOrders.UseCompatibleStateImageBehavior = false;
            // 
            // columnHeader31
            // 
            this.columnHeader31.Text = "OrderID:";
            this.columnHeader31.Width = 100;
            // 
            // columnHeader32
            // 
            this.columnHeader32.Text = "Client\'s Name:";
            this.columnHeader32.Width = 100;
            // 
            // columnHeader33
            // 
            this.columnHeader33.Text = "Product Qty";
            this.columnHeader33.Width = 100;
            // 
            // columnHeader34
            // 
            this.columnHeader34.Text = "Req. Date:";
            this.columnHeader34.Width = 100;
            // 
            // columnHeader35
            // 
            this.columnHeader35.Text = "Shipping Date:";
            this.columnHeader35.Width = 100;
            // 
            // columnHeader36
            // 
            this.columnHeader36.Text = "OrderType:";
            this.columnHeader36.Width = 100;
            // 
            // columnHeader37
            // 
            this.columnHeader37.Text = "Order\'s SubTotal:";
            this.columnHeader37.Width = 100;
            // 
            // columnHeader42
            // 
            this.columnHeader42.Text = "Total:";
            this.columnHeader42.Width = 100;
            // 
            // columnHeader43
            // 
            this.columnHeader43.Text = "Credit";
            this.columnHeader43.Width = 100;
            // 
            // columnHeader44
            // 
            this.columnHeader44.Text = "Available Credit:";
            this.columnHeader44.Width = 100;
            // 
            // txtQty
            // 
            this.txtQty.Location = new System.Drawing.Point(88, 100);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(28, 20);
            this.txtQty.TabIndex = 35;
            // 
            // btnBuyProducts
            // 
            this.btnBuyProducts.Location = new System.Drawing.Point(132, 96);
            this.btnBuyProducts.Name = "btnBuyProducts";
            this.btnBuyProducts.Size = new System.Drawing.Size(89, 26);
            this.btnBuyProducts.TabIndex = 33;
            this.btnBuyProducts.Text = "Add Products";
            this.toolTipSaveReminder.SetToolTip(this.btnBuyProducts, "Don\'t Forget to Save!");
            this.btnBuyProducts.UseVisualStyleBackColor = true;
            this.btnBuyProducts.Click += new System.EventHandler(this.btnBuyProducts_Click);
            // 
            // comboBoxOrderBy
            // 
            this.comboBoxOrderBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxOrderBy.FormattingEnabled = true;
            this.comboBoxOrderBy.Location = new System.Drawing.Point(114, 185);
            this.comboBoxOrderBy.Name = "comboBoxOrderBy";
            this.comboBoxOrderBy.Size = new System.Drawing.Size(96, 21);
            this.comboBoxOrderBy.TabIndex = 31;
            // 
            // comboBoxShipDate
            // 
            this.comboBoxShipDate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxShipDate.FormattingEnabled = true;
            this.comboBoxShipDate.Location = new System.Drawing.Point(114, 153);
            this.comboBoxShipDate.Name = "comboBoxShipDate";
            this.comboBoxShipDate.Size = new System.Drawing.Size(96, 21);
            this.comboBoxShipDate.TabIndex = 30;
            // 
            // dateTimePickerReqDate
            // 
            this.dateTimePickerReqDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerReqDate.Location = new System.Drawing.Point(114, 126);
            this.dateTimePickerReqDate.Name = "dateTimePickerReqDate";
            this.dateTimePickerReqDate.Size = new System.Drawing.Size(96, 20);
            this.dateTimePickerReqDate.TabIndex = 29;
            // 
            // comboBoxProducts
            // 
            this.comboBoxProducts.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxProducts.FormattingEnabled = true;
            this.comboBoxProducts.Location = new System.Drawing.Point(88, 67);
            this.comboBoxProducts.Name = "comboBoxProducts";
            this.comboBoxProducts.Size = new System.Drawing.Size(99, 21);
            this.comboBoxProducts.TabIndex = 27;
            this.comboBoxProducts.SelectedIndexChanged += new System.EventHandler(this.comboBoxProducts_SelectedIndexChanged);
            // 
            // comboBoxClients
            // 
            this.comboBoxClients.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxClients.FormattingEnabled = true;
            this.comboBoxClients.Location = new System.Drawing.Point(87, 39);
            this.comboBoxClients.Name = "comboBoxClients";
            this.comboBoxClients.Size = new System.Drawing.Size(99, 21);
            this.comboBoxClients.TabIndex = 26;
            this.comboBoxClients.SelectedIndexChanged += new System.EventHandler(this.comboBoxClients_SelectedIndexChanged);
            // 
            // txtOID
            // 
            this.txtOID.Location = new System.Drawing.Point(88, 12);
            this.txtOID.Name = "txtOID";
            this.txtOID.ReadOnly = true;
            this.txtOID.Size = new System.Drawing.Size(98, 20);
            this.txtOID.TabIndex = 25;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(7, 186);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(79, 16);
            this.label38.TabIndex = 24;
            this.label38.Text = "Ordered by:";
            this.toolTipSaveReminder.SetToolTip(this.label38, "Quantity On Hand");
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(8, 154);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(96, 16);
            this.label31.TabIndex = 22;
            this.label31.Text = "Shipping Date:";
            this.toolTipSaveReminder.SetToolTip(this.label31, "Quantity On Hand");
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(8, 124);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(99, 16);
            this.label32.TabIndex = 21;
            this.label32.Text = "Required Date:";
            this.toolTipSaveReminder.SetToolTip(this.label32, "Quantity On Hand");
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(7, 97);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(59, 16);
            this.label33.TabIndex = 20;
            this.label33.Text = "Quantity:";
            this.label33.Click += new System.EventHandler(this.label33_Click);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(8, 68);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(57, 16);
            this.label34.TabIndex = 19;
            this.label34.Text = "Product:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(8, 40);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(44, 16);
            this.label35.TabIndex = 18;
            this.label35.Text = "Client:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(7, 14);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(58, 16);
            this.label36.TabIndex = 17;
            this.label36.Text = "OrderID:";
            // 
            // frmMIS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.GhostWhite;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(846, 536);
            this.Controls.Add(this.tabControlMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMIS";
            this.Text = "Welcome to Hi-Tech Distribution INC";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMIS_FormClosing);
            this.Load += new System.EventHandler(this.frmMIS_Load);
            this.tabControlMenu.ResumeLayout(false);
            this.Employee.ResumeLayout(false);
            this.Employee.PerformLayout();
            this.User.ResumeLayout(false);
            this.User.PerformLayout();
            this.tabControlMain.ResumeLayout(false);
            this.tabPageMIS.ResumeLayout(false);
            this.tabPageSales.ResumeLayout(false);
            this.tabPageSales.PerformLayout();
            this.tabPageInventory.ResumeLayout(false);
            this.tabControlinventory.ResumeLayout(false);
            this.tabPagePublishers.ResumeLayout(false);
            this.tabPagePublishers.PerformLayout();
            this.tabPageAuthor.ResumeLayout(false);
            this.tabPageAuthor.PerformLayout();
            this.tabPageProduct.ResumeLayout(false);
            this.tabPageProduct.PerformLayout();
            this.tabPageClerk.ResumeLayout(false);
            this.tabPageClerk.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlMenu;
        private System.Windows.Forms.TabPage Employee;
        private System.Windows.Forms.TabPage User;
        private System.Windows.Forms.Label lblLN;
        private System.Windows.Forms.TextBox txtFn;
        private System.Windows.Forms.Label lblFirstname;
        private System.Windows.Forms.TextBox txtLn;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.ComboBox comboBoxStatus;
        private System.Windows.Forms.ComboBox comboBoxPosition;
        private System.Windows.Forms.Label lblPos;
        private System.Windows.Forms.ListView listViewEmployees;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnWriteToFile;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnReadFromFile;
        private System.Windows.Forms.TabPage tabPageMIS;
        private System.Windows.Forms.TabPage tabPageSales;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtKey;
        private System.Windows.Forms.TextBox txtPW;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnUserWriteToFile;
        private System.Windows.Forms.Button btnReadUsers;
        private System.Windows.Forms.Button btnUpdateUsers;
        private System.Windows.Forms.Button btnSearchUser;
        private System.Windows.Forms.TextBox txtKey2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnRemove;
        public System.Windows.Forms.TabControl tabControlMain;
        private System.Windows.Forms.ListView listViewUserD;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ListView listViewSchools;
        private System.Windows.Forms.TextBox txtCredit;
        private System.Windows.Forms.MaskedTextBox txtFax;
        private System.Windows.Forms.TextBox txtPostalCode;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtStreet;
        private System.Windows.Forms.TextBox txtInstituteName;
        private System.Windows.Forms.MaskedTextBox txtPhone;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnAddCollege;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.Button btnSaveCol;
        private System.Windows.Forms.Button btnUpdateCollege;
        private System.Windows.Forms.Button btnViewColleges;
        private System.Windows.Forms.Button btnSearchCollege;
        private System.Windows.Forms.TextBox txtKey3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnRemoveClients;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnExit2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tabPageInventory;
        private System.Windows.Forms.TabPage tabPageClerk;
        private System.Windows.Forms.ComboBox comboBoxSearch;
        private System.Windows.Forms.ComboBox comboBoxSearchUser;
        private System.Windows.Forms.ComboBox comboBoxClientSearch;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxSearch;
        private System.Windows.Forms.TabControl tabControlinventory;
        private System.Windows.Forms.TabPage tabPagePublishers;
        private System.Windows.Forms.TabPage tabPageAuthor;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtPPName;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ListView listViewPublishers;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxPhoneNumber;
        private System.Windows.Forms.Button btnViewPublishers;
        private System.Windows.Forms.Button btnUpdatePublishers;
        private System.Windows.Forms.Button btnSavePublisher;
        private System.Windows.Forms.Button btnAddPublisher;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxSearchPublishers;
        private System.Windows.Forms.ComboBox comboBoxSearchPublishers;
        private System.Windows.Forms.TextBox txtKey4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnSearchPublishers;
        private System.Windows.Forms.Button btnRemovePublishers;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtLNA;
        private System.Windows.Forms.TextBox txtFNA;
        private System.Windows.Forms.ListView listViewAuthors;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.ColumnHeader columnHeader21;
        private System.Windows.Forms.ColumnHeader columnHeader22;
        private System.Windows.Forms.MaskedTextBox txtPhoneA;
        private System.Windows.Forms.TextBox txtCityA;
        private System.Windows.Forms.Button btnUpdateAuthors;
        private System.Windows.Forms.Button btnSaveAuthors;
        private System.Windows.Forms.Button btnAddAU;
        private System.Windows.Forms.Button btnReadAuthors;
        private System.Windows.Forms.ComboBox comboBoxSearchAuthors;
        private System.Windows.Forms.Button btnSearchAuthors;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtKey5;
        private System.Windows.Forms.Button btnRemoveAuthors;
        private System.Windows.Forms.Button btnExitP;
        private System.Windows.Forms.Button btnExitA;
        private System.Windows.Forms.TabPage tabPageProduct;
        private System.Windows.Forms.ToolTip toolTipSaveReminder;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtUPrice;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.TextBox txtISBN;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox comboBoxProductType;
        private System.Windows.Forms.TextBox txtQOH;
        private System.Windows.Forms.DateTimePicker dateTimePickerProduct;
        private System.Windows.Forms.ListView listViewProduct;
        private System.Windows.Forms.ColumnHeader columnHeader23;
        private System.Windows.Forms.ColumnHeader columnHeader24;
        private System.Windows.Forms.ColumnHeader columnHeader25;
        private System.Windows.Forms.ColumnHeader columnHeader26;
        private System.Windows.Forms.ColumnHeader columnHeader27;
        private System.Windows.Forms.ColumnHeader columnHeader28;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.ComboBox comboBoxPublishers;
        private System.Windows.Forms.ComboBox comboBoxAuthors;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ColumnHeader columnHeader29;
        private System.Windows.Forms.Button btnAuthors;
        private System.Windows.Forms.ListBox listBoxAuthors;
        private System.Windows.Forms.Button btnSaveProducts;
        private System.Windows.Forms.Button btnReadProducts;
        private System.Windows.Forms.Button btnUpdateProduct;
        private System.Windows.Forms.Button btnRemoveProducts;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnClearSales;
        private System.Windows.Forms.Button btnClearPublisher;
        private System.Windows.Forms.Button btnClearUser;
        private System.Windows.Forms.Button btnClearAuthor;
        private System.Windows.Forms.ComboBox comboBoxSearchProduct;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button btnSearchProduct;
        private System.Windows.Forms.TextBox txtKey6;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ColumnHeader columnHeader30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox comboBoxOrderBy;
        private System.Windows.Forms.ComboBox comboBoxShipDate;
        private System.Windows.Forms.DateTimePicker dateTimePickerReqDate;
        private System.Windows.Forms.ComboBox comboBoxProducts;
        private System.Windows.Forms.ComboBox comboBoxClients;
        private System.Windows.Forms.TextBox txtOID;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Button btnBuyProducts;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.ListView listViewOrders;
        private System.Windows.Forms.Button btnAddOrders;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.ColumnHeader columnHeader31;
        private System.Windows.Forms.ColumnHeader columnHeader32;
        private System.Windows.Forms.ColumnHeader columnHeader33;
        private System.Windows.Forms.ColumnHeader columnHeader34;
        private System.Windows.Forms.ColumnHeader columnHeader35;
        private System.Windows.Forms.ColumnHeader columnHeader36;
        private System.Windows.Forms.ColumnHeader columnHeader37;
        private System.Windows.Forms.ListView listViewChosenProducts;
        private System.Windows.Forms.ColumnHeader columnHeader38;
        private System.Windows.Forms.ColumnHeader columnHeader39;
        private System.Windows.Forms.ColumnHeader columnHeader40;
        private System.Windows.Forms.ColumnHeader columnHeader41;
        private System.Windows.Forms.ColumnHeader columnHeader42;
        private System.Windows.Forms.Button btnSaveOrders;
        private System.Windows.Forms.ColumnHeader columnHeader43;
        private System.Windows.Forms.ColumnHeader columnHeader44;
        private System.Windows.Forms.Button btnReadOrders;
        private System.Windows.Forms.Button btnSearchOrders;
        private System.Windows.Forms.TextBox txtKey7;
        private System.Windows.Forms.Label label37;
    }
}


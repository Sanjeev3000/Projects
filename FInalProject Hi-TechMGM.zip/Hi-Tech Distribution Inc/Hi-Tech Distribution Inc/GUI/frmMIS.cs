﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Hi_TechDistributionIncLibrary.Business;
using Hi_TechDistributionIncLibrary.DataAccess;
using Hi_TechDistributionIncLibrary.Validator;
using System.IO;


namespace Hi_Tech_Distribution_Inc
{
    public partial class frmMIS : Form
    {
       public List<Authors> nlist = new List<Authors>();
        int qty2 = 0;
        float sub2 = 0;
        float taxes = 0.15f;
        int index;
        int indexUsers;
        int indexCollege;
        int indexPublishers;
        int indexAuthors;
        int indexProduct;
        int indexForProduct;
        static int j;
        List<Employee> listOfEmployee = new List<Employee>();
        List<Employee> listforRead = new List<Employee>();
        List<User> listOfUsers = new List<User>();
        List<User> listforReadUsers = new List<User>();
        List<College> listOfColleges = new List<College>();
        List<College> listCollegeTemp = new List<College>();
        List<Publisher> listofPublisher = new List<Publisher>();
        List<Publisher> listPublisherTemp = new List<Publisher>();
        List<Authors> listOfAuthors = new List<Authors>();
        List<Authors> listAuthorsTemp = new List<Authors>();
        List<Product> listOfProduct = new List<Product>();
        List<Product> listProductTemp = new List<Product>();
        List<Product> listOfProductsInOrder = new List<Product>();
        List<Order> listOfOrder = new List<Order>();
        List<Order> listOfTempOD = new List<Order>();
        Employee emp = new Employee();
        User u1 = new User();
        College c1 = new College();
        Publisher pub = new Publisher();
        Authors a3 = new Authors();
        Product p1 = new Product();
        Order ord = new Order();
        GUI.LoginForm log = new GUI.LoginForm();
      
        public frmMIS()
        {
            InitializeComponent();
        }

        private bool IsValidMIS()
        {
            return Validator.IsPresent(txtFn)
                && Validator.IsPresent(txtLn)
                && Validator.IsPresentComboBox(comboBoxStatus)
                && Validator.IsPresentComboBox(comboBoxPosition)
                && Validator.IsLetters(txtFn)
                && Validator.IsLetters(txtLn)
                && Validator.IsSpecialCharacters(txtFn)
                && Validator.IsSpecialCharacters(txtLn);


        }
       

        private void Employee_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
     
        private void frmMIS_Load(object sender, EventArgs e)
        {

         
            this.listOfEmployee = EmployeeDA.ReadFromFile();
            this.listofPublisher = PublisherDA.ReadFromFile();
            this.listOfUsers = UserDA.ReadFromFileUsers();
            this.listOfColleges = CollegeDA.ReadFromFile();
            this.listOfAuthors = AuthorDA.ReadFromFile();
            this.listOfProduct = ProductDA.ReadFromFile();
            listViewEmployees.GridLines = true;
            listViewEmployees.FullRowSelect = true;
            listViewEmployees.View = View.Details;
            listViewUserD.View = View.Details;
            listViewUserD.GridLines = true;
            listViewUserD.FullRowSelect = true;
            listViewSchools.GridLines = true;
            listViewSchools.FullRowSelect = true;
            listViewSchools.View = View.Details;
            listViewPublishers.GridLines = true;
            listViewPublishers.FullRowSelect = true;
            listViewPublishers.View = View.Details;
            listViewAuthors.GridLines = true;
            listViewAuthors.FullRowSelect = true;
            listViewAuthors.View = View.Details;
            listViewProduct.FullRowSelect = true;
            listViewProduct.GridLines = true;
            listViewProduct.View = View.Details;
            listViewOrders.View = View.Details;
            listViewOrders.GridLines = true;
            listViewOrders.FullRowSelect = true;
            listViewChosenProducts.GridLines = true;
            listViewChosenProducts.FullRowSelect = true;
            listViewChosenProducts.View = View.Details;
            maskedTextBoxSearch.Hide();
            maskedTextBoxSearchPublishers.Hide();

            foreach (EnumProduct it in Enum.GetValues(typeof(EnumProduct)))
            {
                comboBoxProductType.Items.Add(it);
            }
            foreach (EnumStatus ele in Enum.GetValues(typeof(EnumStatus)))
            {
                comboBoxStatus.Items.Add(ele);
            }
            foreach (EnumPosition elem in Enum.GetValues(typeof(EnumPosition)))
            {
                comboBoxPosition.Items.Add(elem);
            }

            foreach (EnumSearch eleme in Enum.GetValues(typeof(EnumSearch)))
            {
                comboBoxSearch.Items.Add(eleme);
            }

            foreach (EnumSearchUser element in Enum.GetValues(typeof(EnumSearchUser)))
            {
                comboBoxSearchUser.Items.Add(element);
            }

            foreach (EnumSearchClient elements in Enum.GetValues(typeof(EnumSearchClient)))
            {
                comboBoxClientSearch.Items.Add(elements);
            }
            foreach (EnumPublisherSearch thing in Enum.GetValues(typeof(EnumPublisherSearch)))
            {
                comboBoxSearchPublishers.Items.Add(thing);
            }
            foreach (EnumSearch stuff in Enum.GetValues(typeof(EnumSearch)))
            {
                comboBoxSearchAuthors.Items.Add(stuff);
            }
            foreach (Authors authors in listOfAuthors)
            {
                comboBoxAuthors.Items.Add(authors.Name);
            }
            foreach (Publisher Pu in listofPublisher)
            {
                comboBoxPublishers.Items.Add(Pu.PName);

            }
            foreach (EnumSearchBook product in Enum.GetValues(typeof(EnumSearchBook)))
            {
                comboBoxSearchProduct.Items.Add(product);
            }
            foreach (College colleges in listOfColleges)
            {
                comboBoxClients.Items.Add(colleges.Name);
            }
            foreach (Product products in listOfProduct)
            {
                comboBoxProducts.Items.Add(products.Title);
              
            }
            foreach (EnumShipDate dates in Enum.GetValues(typeof(EnumShipDate)))
            {
                comboBoxShipDate.Items.Add(dates);
            }
            foreach (EnumOrderBy type in Enum.GetValues(typeof(EnumOrderBy)))
            {
                comboBoxOrderBy.Items.Add(type);
            }
            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (IsValidMIS())
            {
                User nw = new Hi_TechDistributionIncLibrary.Business.User(txtUN.Text, txtPW.Text);
                Employee e5 = new Employee((EnumStatus)comboBoxStatus.SelectedIndex, (EnumPosition)comboBoxPosition.SelectedIndex, txtFn.Text, txtLn.Text, Sequence.ReadToCheck(listOfEmployee), nw);
                
                listOfEmployee.Add(e5);
                listOfUsers.Add(nw);

                e5.Display(listOfEmployee, listViewEmployees);
                DialogResult result = MessageBox.Show("Add Complete!", "Add Employee", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }

        private void btnWriteToFile_Click(object sender, EventArgs e)
        {
            Hi_TechDistributionIncLibrary.Business.Employee.SaveToFile(listOfEmployee);

            Hi_TechDistributionIncLibrary.Business.User.SaveToFile(listOfUsers);

            DialogResult result = MessageBox.Show("Save Complete!", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);


        }

        private void listViewEmployees_SelectedIndexChanged(object sender, EventArgs e)
        {
            index = listViewEmployees.FocusedItem.Index;
            txtFn.Text = listOfEmployee[index].Firstname;
            txtLn.Text = listOfEmployee[index].Lastname;
            comboBoxStatus.Text = Convert.ToString(listOfEmployee[index].Status);
            comboBoxPosition.Text = Convert.ToString(listOfEmployee[index].Position);
            txtFn.Focus();
            
           
        }

        private void btnReadFromFile_Click(object sender, EventArgs e)
        {
            this.listOfEmployee = EmployeeDA.ReadFromFile();
            emp.Display(listOfEmployee, listViewEmployees);
            DialogResult result = MessageBox.Show("Read Complete!", "View", MessageBoxButtons.OK, MessageBoxIcon.Information);


        }



        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (IsValidMIS())
            {


                listOfEmployee[index].Firstname = txtFn.Text;
                listOfEmployee[index].Lastname = txtLn.Text;
                listOfEmployee[index].Status = (EnumStatus)Enum.Parse(typeof(EnumStatus), comboBoxStatus.Text);
                listOfEmployee[index].Position = (EnumPosition)Enum.Parse(typeof(EnumPosition), comboBoxPosition.Text);
                emp.Display(listOfEmployee, listViewEmployees);
                DialogResult result = MessageBox.Show("Update Complete!", "Update", MessageBoxButtons.OK,MessageBoxIcon.Information);

            }
        }
        private bool SearchValidName()
        {
            return Validator.IsPresent(txtKey)
                 && Validator.IsLetters(txtKey)
                 && Validator.IsSpecialCharacters(txtKey);
        }
        private bool SearchValidID()
        {
            return Validator.IsInt32(txtKey)
                && Validator.IsRightNumber(txtKey);
                

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            
            if (comboBoxSearch.Text == Convert.ToString(EnumSearch.LastName))
            {
                if (SearchValidName())
                {


                    emp = Hi_TechDistributionIncLibrary.Business.Employee.SearchLN(txtKey);
                    if (emp != null)
                    {
                        MessageBox.Show("[" + emp.EmployeeID + "]," + emp.Firstname + "," + emp.Lastname);
                    }
                    else
                    {
                        MessageBox.Show("Employee not found!");
                    }
                }
            }
            if (comboBoxSearch.Text==Convert.ToString(EnumSearch.FirstName))
            {
                if (SearchValidName())
                {

                    emp = Hi_TechDistributionIncLibrary.Business.Employee.SearchFN(txtKey);
                    if (emp != null)
                    {
                        MessageBox.Show("[" + emp.EmployeeID + "]," + emp.Firstname + "," + emp.Lastname);
                    }
                    else
                    {
                        MessageBox.Show("Employee not found!");
                    }
                }
            }
            if (comboBoxSearch.Text == Convert.ToString(EnumSearch.ID))
            {
                if (SearchValidID())
                {
                    emp = Hi_TechDistributionIncLibrary.Business.Employee.Search(txtKey);
                    if (emp != null)
                    {
                        MessageBox.Show(emp.Firstname + "," + emp.Lastname);
                    }
                    else
                    {
                        MessageBox.Show("Employee not found!");
                    }
                }
            }
            DialogResult result = MessageBox.Show("Search Complete!", "Search", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }





        private void btnUserWriteToFile_Click(object sender, EventArgs e)
        {
            Hi_TechDistributionIncLibrary.Business.Employee.SaveToFile(listOfEmployee);
            //listOfUsers = UserDA.ReadFromFileUsers();
            Hi_TechDistributionIncLibrary.Business.User.SaveToFile(listOfUsers);
            DialogResult result = MessageBox.Show("Save Complete!", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void ListViewUsers(List<Employee> list)
        {
            if (this.listOfEmployee.Capacity != 0)
            {
                listViewUserD.Items.Clear();
                foreach (Employee element in list)
                {
                    ListViewItem item = new ListViewItem(Convert.ToString(element.EmployeeID));

                    item.SubItems.Add(element.Username.Username);
                    item.SubItems.Add(element.Username.Password);
                    

                    listViewUserD.Items.Add(item);
                }


            }
        }
        private void btnReadUsers_Click(object sender, EventArgs e)
        {
            
            List<Employee> list = new List<Employee>();
            list=EmployeeDA.ReadFromFile();
            foreach (Employee item in list)
            {
              
                User u1 = new User();
               u1 = item.Username;
                listOfUsers.Add(u1);
            }
            ListViewUsers(list);
            DialogResult result = MessageBox.Show("Read Complete!", "View", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void btnUpdateUsers_Click(object sender, EventArgs e)
        {
            
            

            
           
            listOfEmployee[indexUsers].Username.Username = txtUN.Text;
            listOfEmployee[indexUsers].Username.Password = txtPW.Text;
            
            ListViewUsers(listOfEmployee);

            DialogResult result = MessageBox.Show("Update Complete!", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }




        private void btnSearchUser_Click(object sender, EventArgs e)
        {
            if (comboBoxSearchUser.Text == Convert.ToString(EnumSearchUser.ID))
            {


               Employee temp = new Employee();
                temp = EmployeeDA.SearchbyID(this.listOfEmployee, Int32.Parse(txtKey2.Text));
                MessageBox.Show(temp.Username.Username);
            }
            if (comboBoxSearchUser.Text == Convert.ToString(EnumSearchUser.Username))
            {
                Employee temp = new Employee();
                temp = EmployeeDA.SearchbyUs(this.listOfEmployee,txtKey2.Text);
                MessageBox.Show("["+temp.EmployeeID.ToString()+"],"+temp.Firstname);
            }
            DialogResult result = MessageBox.Show("Search Complete!", "Search", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure?", "WARNING!", MessageBoxButtons.OKCancel,MessageBoxIcon.Hand);

            if (result == DialogResult.OK)
            {


                int index = -1;

                foreach (Employee item in listOfEmployee)
                {
                    if (item.Firstname == txtFn.Text && item.Lastname == txtLn.Text && item.Status == (EnumStatus)Enum.Parse(typeof(EnumStatus), comboBoxStatus.Text) && item.Position == (EnumPosition)Enum.Parse(typeof(EnumPosition), comboBoxPosition.Text))
                    {
                        index = listOfEmployee.IndexOf(item);


                    }

                }

                if (index != -1)
                {
                    listOfEmployee.RemoveAt(index);
                    Hi_TechDistributionIncLibrary.Business.Employee.SaveToFile(listOfEmployee);

                }

                else
                {
                    MessageBox.Show("The item was not found");
                }

                emp.Display(listOfEmployee, listViewEmployees);
            }
        }
      

        private void listViewUserD_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            
          
        }

        private void listViewUserD_SelectedIndexChanged(object sender, EventArgs e)
        {

            indexUsers = listViewUserD.FocusedItem.Index;
            txtUN.Text = listOfEmployee[indexUsers].Username.Username;
            txtPW.Text = listOfEmployee[indexUsers].Username.Password;
            txtUN.Focus();
        }

        private void frmMIS_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure?", "Exit", MessageBoxButtons.OKCancel);

            if (result == DialogResult.OK)
            {
                this.Dispose();
                log.Show();
            }
        }

        private void tabPageSales_Click(object sender, EventArgs e)
        {

        }
        private bool IsValidSalesManager()
        {
            return Validator.IsPresent(txtInstituteName)
                && Validator.IsPresent(txtStreet)
                && Validator.IsPresent(txtCity)
                && Validator.IsPresent(txtPostalCode)
                && Validator.IsPresentMaskedTextBox(txtPhone)
                && Validator.IsPresentMaskedTextBox(txtFax)
                && Validator.IsPresent(txtCredit)
                && Validator.IsPresent(txtEmail)

                && Validator.IsSpecialCharacters(txtInstituteName)
                && Validator.IsSpecialCharacters(txtStreet)
                && Validator.IsSpecialCharacters(txtCity)
      
                && Validator.IsInt32(txtCredit);





        }
        private void btnAddCollege_Click(object sender, EventArgs e)
        {
            if (IsValidSalesManager())
            {


                College col = new College(txtInstituteName.Text, txtStreet.Text, txtCity.Text, txtPostalCode.Text, txtPhone, txtFax, Int32.Parse(txtCredit.Text), txtEmail.Text);

                listOfColleges.Add(col);
                col.Display(listOfColleges, listViewSchools);

                DialogResult result = MessageBox.Show("Add Complete!", "Add Employee", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void btnSaveCol_Click(object sender, EventArgs e)
        {
            College.SavetoFile(listOfColleges);
            DialogResult result = MessageBox.Show("Save Complete!", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void listViewSchools_SelectedIndexChanged(object sender, EventArgs e)
        {
            indexCollege = listViewSchools.FocusedItem.Index;
            txtInstituteName.Text = listOfColleges[indexCollege].Name;
            txtStreet.Text = listOfColleges[indexCollege].Street;
            txtCity.Text = listOfColleges[indexCollege].City;
            txtPostalCode.Text = listOfColleges[indexCollege].PostCode;
            txtPhone.Text = listOfColleges[indexCollege].PhoneNunber;
            txtFax.Text = listOfColleges[indexCollege].FaxNumber;
            txtCredit.Text = Convert.ToString(listOfColleges[indexCollege].Credit);
            txtEmail.Text = listOfColleges[indexCollege].Email;
        }

        private void btnUpdateCollege_Click(object sender, EventArgs e)
        {
            if (IsValidSalesManager())
            {


                listOfColleges[indexCollege].Name = txtInstituteName.Text;
                listOfColleges[indexCollege].Street = txtStreet.Text;
                listOfColleges[indexCollege].City = txtCity.Text;
                listOfColleges[indexCollege].PostCode = txtPostalCode.Text;
                listOfColleges[indexCollege].PhoneNunber = txtPhone.Text;
                listOfColleges[indexCollege].FaxNumber = txtFax.Text;
                listOfColleges[indexCollege].Credit = Int32.Parse(txtCredit.Text);
                listOfColleges[indexCollege].Email = txtEmail.Text;
                c1.Display(listOfColleges, listViewSchools);
                DialogResult result = MessageBox.Show("Update Complete!", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnViewColleges_Click(object sender, EventArgs e)
        {
            College.ReadFromFile(listCollegeTemp, listOfColleges, c1, listViewSchools);
            DialogResult result = MessageBox.Show("Read Complete!", "View", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }
        private bool SearchValidPhone()
        {
            return Validator.IsPresentMaskedTextBox(maskedTextBoxSearch);
                
              

        }
        private bool SearchValidNameSales()
        {
            return Validator.IsPresent(txtKey2)
                 && Validator.IsLetters(txtKey2)
                 && Validator.IsSpecialCharacters(txtKey2);
        }
        private void btnSearchCollege_Click(object sender, EventArgs e)
        {
            if (comboBoxClientSearch.Text == Convert.ToString(EnumSearchClient.InstituteName))
            {
                if (SearchValidNameSales())
                {


                    College ctemp = new College();
                    ctemp = College.Search(txtKey3);
                    MessageBox.Show(ctemp.Name + "," + ctemp.PhoneNunber + "," + ctemp.Email);
                }
            }
            if (comboBoxClientSearch.Text==Convert.ToString(EnumSearchClient.PhoneNumber))
            {
                if (SearchValidPhone())
                {


                    College ctemp2 = new College();
                    ctemp2 = College.SearchNumber(maskedTextBoxSearch);
                    MessageBox.Show(ctemp2.Name + "," + ctemp2.PhoneNunber);
                }
            }
            DialogResult result = MessageBox.Show("Search Complete!", "Search", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void btnRemoveClients_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure?", "WARNING!", MessageBoxButtons.OKCancel, MessageBoxIcon.Hand);

            if (result == DialogResult.OK)
            {
                int index = -1;

                foreach (College item in listOfColleges)
                {
                    if (item.Name == txtInstituteName.Text && item.Street == txtStreet.Text && item.City == txtCity.Text && item.PostCode == txtPostalCode.Text && item.PhoneNunber == txtPhone.Text && item.FaxNumber == txtFax.Text && item.Credit == Int32.Parse(txtCredit.Text))
                    {
                        index = listOfColleges.IndexOf(item);


                    }

                }

                if (index != -1)
                {
                    listOfColleges.RemoveAt(index);
                    College.SavetoFile(listOfColleges);

                }

                else
                {
                    MessageBox.Show("The item was not found");
                }

                c1.Display(listOfColleges, listViewSchools);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure?", "Exit", MessageBoxButtons.OKCancel);

            if (result == DialogResult.OK)
            {
                this.Dispose();
                log.Show();
            }
        }

        private void btnExit2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure?", "Exit", MessageBoxButtons.OKCancel);

            if (result == DialogResult.OK)
            {
                this.Dispose();
                log.Show();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure?", "Exit", MessageBoxButtons.OKCancel);

            if (result == DialogResult.OK)
            {
                this.Dispose();
                log.Show();
            }
        }

        private void txtKey_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void comboBoxSearch_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxClientSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxClientSearch.Text==Convert.ToString(EnumSearchClient.PhoneNumber))
            {
                txtKey3.Hide();
                maskedTextBoxSearch.Show();
            }
        }

        private void tabPagePublishers_Click(object sender, EventArgs e)
        {

        }
        private bool IsValidInventory()
        {

            return Validator.IsPresent(txtPPName)
                && Validator.IsPresentMaskedTextBox(maskedTextBoxPhoneNumber)

                && Validator.IsSpecialCharacters(txtPPName);

        }

        private void btnAddPublisher_Click(object sender, EventArgs e)
        {
            if (IsValidInventory())
            {


                Publisher p1 = new Publisher(txtPPName.Text, maskedTextBoxPhoneNumber);
                listofPublisher.Add(p1);
                p1.Display(listofPublisher, listViewPublishers);
                DialogResult result = MessageBox.Show("Add Complete!", "Add Employee", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnSavePublisher_Click(object sender, EventArgs e)
        {
            Publisher.SavetoFile(listofPublisher);
            DialogResult result = MessageBox.Show("Save Complete!", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void btnViewPublishers_Click(object sender, EventArgs e)
        {
            Publisher.ReadFromFile(listPublisherTemp, listofPublisher, pub, listViewPublishers);
            DialogResult result = MessageBox.Show("Read Complete!", "View", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void btnUpdatePublishers_Click(object sender, EventArgs e)
        {
            if (IsValidInventory())
            {


                listofPublisher[indexPublishers].PName = txtPPName.Text;
                listofPublisher[indexPublishers].Pphonenumber = maskedTextBoxPhoneNumber.Text;
                pub.Display(listofPublisher, listViewPublishers);
                DialogResult result = MessageBox.Show("Update Complete!", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void listViewPublishers_SelectedIndexChanged(object sender, EventArgs e)
        {
            indexPublishers = listViewPublishers.FocusedItem.Index;
            txtPPName.Text = listofPublisher[indexPublishers].PName;
            maskedTextBoxPhoneNumber.Text = listofPublisher[indexPublishers].Pphonenumber;
        }

        private void comboBoxSearchPublishers_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxSearchPublishers.Text == Convert.ToString(EnumPublisherSearch.Phone_Number))
            {
                txtKey4.Hide();
                maskedTextBoxSearchPublishers.Show();
            }
        }
        private bool SearchValidNameInv()
        {
            return Validator.IsPresent(txtKey4)
                     && Validator.IsLetters(txtKey4)
                     && Validator.IsSpecialCharacters(txtKey4);
        }
        private bool SearchValidPhoneInv()
        {
       
            return Validator.IsPresentMaskedTextBox(maskedTextBoxSearchPublishers);



        
         }
        private void btnSearchPublishers_Click(object sender, EventArgs e)
        {
            if (comboBoxSearchPublishers.Text == Convert.ToString(EnumPublisherSearch.Publisher_Name))
            {
                if (SearchValidNameInv())
                {


                    Publisher ptemp = new Publisher();
                    ptemp = Publisher.Search(txtKey4);
                    MessageBox.Show(ptemp.PName + ":" + ptemp.Pphonenumber);
                }

               

            }
            if (comboBoxSearchPublishers.Text == Convert.ToString(EnumPublisherSearch.Phone_Number))
            {
                if (SearchValidPhoneInv())
                {


                    Publisher ptemp = new Publisher();
                    ptemp = Publisher.SearchNumber(maskedTextBoxSearchPublishers);
                    MessageBox.Show(ptemp.PName + ":" + ptemp.Pphonenumber);
                }
            }
            DialogResult result = MessageBox.Show("Search Complete!", "Search", MessageBoxButtons.OK, MessageBoxIcon.Information);


        }

        private void btnRemovePublishers_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure?", "WARNING!", MessageBoxButtons.OKCancel, MessageBoxIcon.Hand);

            if (result == DialogResult.OK)
            {

                int index = -1;

                foreach (Publisher item in listofPublisher)
                {
                    if (item.PName == txtPPName.Text && item.Pphonenumber == maskedTextBoxPhoneNumber.Text)
                    {
                        index = listofPublisher.IndexOf(item);


                    }


                }
                if (index != -1)
                {
                    listofPublisher.RemoveAt(index);
                    Publisher.SavetoFile(listofPublisher);

                }

                else
                {
                    MessageBox.Show("The Publisher was not found");
                }

                pub.Display(listofPublisher, listViewPublishers);

            }
        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private bool IsValidInv()
        {
            return Validator.IsPresent(txtFNA)
                && Validator.IsPresent(txtLNA)
                && Validator.IsPresent(txtCityA)
                && Validator.IsPresentMaskedTextBox(txtPhoneA)

                && Validator.IsSpecialCharacters(txtFNA)
                && Validator.IsSpecialCharacters(txtLNA)
                && Validator.IsSpecialCharacters(txtCityA);
        }
        private void btnAddAU_Click(object sender, EventArgs e)
        {
            if (IsValidInv())
            {


                Authors author = new Authors(SequenceAuthor.ReadToCheck(listOfAuthors), txtCityA.Text, txtPhoneA.Text, txtFNA.Text, txtLNA.Text);
                listOfAuthors.Add(author);
                author.Display(listOfAuthors, listViewAuthors);

                DialogResult result = MessageBox.Show("Add Complete!", "Add Employee", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnSaveAuthors_Click(object sender, EventArgs e)
        {
            Authors.SaveToFile(listOfAuthors);
            DialogResult result = MessageBox.Show("Save Complete!", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void btnReadAuthors_Click(object sender, EventArgs e)
        {
            Authors.ReadFromFile(listAuthorsTemp, listOfAuthors, a3, listViewAuthors);
            DialogResult result = MessageBox.Show("Read Complete!", "View", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void btnUpdateAuthors_Click(object sender, EventArgs e)
        {
            if (IsValidInv())
            {


                listOfAuthors[indexAuthors].Firstname = txtFNA.Text;
                listOfAuthors[indexAuthors].Lastname = txtLNA.Text;
                listOfAuthors[indexAuthors].City = txtCityA.Text;
                listOfAuthors[indexAuthors].Phone = txtPhoneA.Text;
                a3.Display(listOfAuthors, listViewAuthors);
                DialogResult result = MessageBox.Show("Update Complete!", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void listViewAuthors_SelectedIndexChanged(object sender, EventArgs e)
        {
            indexAuthors = listViewAuthors.FocusedItem.Index;
            txtFNA.Text = listOfAuthors[indexAuthors].Firstname;
            txtLNA.Text = listOfAuthors[indexAuthors].Lastname;
            txtCityA.Text = listOfAuthors[indexAuthors].City;
            txtPhoneA.Text = listOfAuthors[indexAuthors].Phone;
        }
        private bool SearchValidNameInvAuthor()
        {
            return Validator.IsPresent(txtKey5)
                 && Validator.IsLetters(txtKey5)
                 && Validator.IsSpecialCharacters(txtKey5);
        }
        private bool SearchValidIDAuthor()
        {
            return Validator.IsInt32(txtKey5)
                && Validator.IsRightNumberAuthor(txtKey5);


        }
        private void btnSearchAuthors_Click(object sender, EventArgs e)
        {
            if (comboBoxSearchAuthors.Text == Convert.ToString(EnumSearch.LastName))
            {
                if (SearchValidNameInvAuthor())
                {


                    a3 = Authors.SearchLN(txtKey5);
                    if (a3 != null)
                    {
                        MessageBox.Show("[" + a3.AuthorID + "]," + a3.Firstname + "," + a3.Lastname + "," + a3.Phone);
                    }
                    else
                    {
                        MessageBox.Show("Author not found!");
                    }
                }
            }
            if (comboBoxSearchAuthors.Text == Convert.ToString(EnumSearch.FirstName))
            {
                if (SearchValidNameInvAuthor())
                {
                    a3 = Authors.SearchFN(txtKey5);
                    if (a3 != null)
                    {
                        MessageBox.Show("[" + a3.AuthorID + "]," + a3.Firstname + "," + a3.Lastname + "," + a3.Phone);
                    }
                    else
                    {
                        MessageBox.Show("Author not found!");
                    }
                }
            }
            if (comboBoxSearchAuthors.Text == Convert.ToString(EnumSearch.ID))
            {
                if (SearchValidIDAuthor())
                {


                    a3 = Authors.Search(txtKey5);
                    if (a3 != null)
                    {
                        MessageBox.Show("[" + a3.AuthorID + "]," + a3.Firstname + "," + a3.Lastname + "," + a3.Phone);
                    }
                    else
                    {
                        MessageBox.Show("Author not found!");
                    }
                }
            }
            DialogResult result = MessageBox.Show("Search Complete!", "Search", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void btnRemoveAuthors_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure?", "WARNING!", MessageBoxButtons.OKCancel, MessageBoxIcon.Hand);

            if (result == DialogResult.OK)
            {

                int index = -1;

                foreach (Authors item in listOfAuthors)
                {
                    if (item.Firstname == txtFNA.Text && item.Lastname == txtLNA.Text&&item.City==txtCityA.Text&&item.Phone==txtPhoneA.Text)
                    {
                        index = listOfAuthors.IndexOf(item);


                    }


                }
                if (index != -1)
                {
                    listOfAuthors.RemoveAt(index);
                    Authors.SaveToFile(listOfAuthors);

                }

                else
                {
                    MessageBox.Show("The Author was not found");
                }

                a3.Display(listOfAuthors, listViewAuthors);

            }
        }

        private void btnExitP_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure?", "Exit", MessageBoxButtons.OKCancel);

            if (result == DialogResult.OK)
            {
                this.Dispose();
                log.Show();
            }

        }

        private void btnExitA_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure?", "Exit", MessageBoxButtons.OKCancel);

            if (result == DialogResult.OK)
            {
                this.Dispose();
                log.Show();
            }
        }
        private bool IsValidInvProduct()
        {
            return Validator.IsPresent(txtISBN)
                && Validator.IsPresent(txtTitle)
                && Validator.IsPresent(txtUPrice)
                && Validator.IsPresentDate(dateTimePickerProduct)
                && Validator.IsPresent(txtQOH)
                && Validator.IsPresentComboBox(comboBoxProductType)
                && Validator.IsPresentComboBox(comboBoxAuthors)
                && Validator.IsPresentComboBox(comboBoxPublishers)

                && Validator.IsLong(txtISBN)
                && Validator.IsDecimal(txtUPrice)
                && Validator.IsInt32(txtQOH)

                && Validator.IsRightNumberISBN(txtISBN);

              
                




        }
        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            if (IsValidInvProduct())
            {


                string au = "";
                if (listBoxAuthors.Items.Count == 3)
                {


                    string au1 = listBoxAuthors.Items[0].ToString();
                    string au2 = listBoxAuthors.Items[1].ToString();
                    string au3 = listBoxAuthors.Items[2].ToString();
                    au = au1 + "|" + au2 + "|" + au3;
                }
                if (listBoxAuthors.Items.Count == 2)
                {


                    string au1 = listBoxAuthors.Items[0].ToString();
                    string au2 = listBoxAuthors.Items[1].ToString();

                    au = au1 + "|" + au2;
                }
                if (listBoxAuthors.Items.Count == 1)
                {


                    string au1 = listBoxAuthors.Items[0].ToString();


                    au = au1;
                }


                Product prod = new Product(long.Parse(txtISBN.Text), txtTitle.Text, float.Parse(txtUPrice.Text), Int32.Parse(txtQOH.Text), (EnumProduct)comboBoxProductType.SelectedIndex);
                prod.Names1 = au;
                prod.Publisher = comboBoxPublishers.Text;
                prod.YearPublished = dateTimePickerProduct.Value;
                listOfProduct.Add(prod);
                prod.Display(listOfProduct, listViewProduct);

                DialogResult result = MessageBox.Show("Add Complete!", "Add Employee", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnAuthors_Click(object sender, EventArgs e)
        {
            if (listBoxAuthors.Items.Count == 3)
            {
                MessageBox.Show("Maximum amount of authors is 3");
            }
            else
            {
                listBoxAuthors.Items.Clear();
                nlist.Add(new Authors(comboBoxAuthors));
                foreach (var item in nlist)
                {
                    listBoxAuthors.Items.Add(item.Nametemp);
                }

            }
         
        }

        private void btnSaveProducts_Click(object sender, EventArgs e)
        {
            Product.SaveToFile(listOfProduct);
            DialogResult result = MessageBox.Show("Save Complete!", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void listViewProduct_SelectedIndexChanged(object sender, EventArgs e)
        {

            indexProduct = listViewProduct.FocusedItem.Index;
            txtISBN.Text = Convert.ToString(listOfProduct[indexProduct].ISBN);
            txtTitle.Text = listOfProduct[indexProduct].Title;
            txtUPrice.Text = Convert.ToString(listOfProduct[indexProduct].UPrice);
            dateTimePickerProduct.Text = Convert.ToString(listOfProduct[indexProduct].YearPublished);
            txtQOH.Text = Convert.ToString(listOfProduct[indexProduct].QOH);
            comboBoxProductType.Text = Convert.ToString(listOfProduct[indexProduct].ProductType);
            comboBoxAuthors.Text = "";
            //string[] line = listOfProduct[indexProduct].Names1.Split('|');
            
            
            //string a1 = line[0];
            //string a2 = line[1];
            //string a3 = line[2];


            //listBoxAuthors.Items.Add(a1);
            
            
            comboBoxPublishers.Text = Convert.ToString(listOfProduct[indexProduct].Publisher);

        }

        private void btnReadProducts_Click(object sender, EventArgs e)
        {
            Product.ReadFromFile(listProductTemp, listOfProduct, p1, listViewProduct);
            DialogResult result = MessageBox.Show("Read Complete!", "View", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void btnUpdateProduct_Click(object sender, EventArgs e)
        {
            if (IsValidInvProduct())
            {


                string au = "";
                if (listBoxAuthors.Items.Count == 3)
                {


                    string au1 = listBoxAuthors.Items[0].ToString();
                    string au2 = listBoxAuthors.Items[1].ToString();
                    string au3 = listBoxAuthors.Items[2].ToString();
                    au = au1 + "|" + au2 + "|" + au3;
                }
                if (listBoxAuthors.Items.Count == 2)
                {


                    string au1 = listBoxAuthors.Items[0].ToString();
                    string au2 = listBoxAuthors.Items[1].ToString();

                    au = au1 + "|" + au2;
                }
                if (listBoxAuthors.Items.Count == 1)
                {


                    string au1 = listBoxAuthors.Items[0].ToString();


                    au = au1;
                }

                listOfProduct[indexProduct].ISBN = long.Parse(txtISBN.Text);
                listOfProduct[indexProduct].Title = txtTitle.Text;
                listOfProduct[indexProduct].UPrice = float.Parse(txtUPrice.Text);
                listOfProduct[indexProduct].YearPublished = System.DateTime.Parse(dateTimePickerProduct.Text);
                listOfProduct[indexProduct].QOH = Int32.Parse(txtQOH.Text);
                listOfProduct[indexProduct].ProductType = (EnumProduct)comboBoxProductType.SelectedIndex;
                listOfProduct[indexProduct].Names1 = au;
                listOfProduct[indexProduct].Publisher = comboBoxPublishers.Text;
                p1.Display(listOfProduct, listViewProduct);
                DialogResult result = MessageBox.Show("Update Complete!", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnRemoveProducts_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure?", "WARNING!", MessageBoxButtons.OKCancel, MessageBoxIcon.Hand);

            if (result == DialogResult.OK)
            {

                int index = -1;

                foreach (Product item in listOfProduct)
                {
                    if (item.ISBN==long.Parse(txtISBN.Text)&&item.Title==txtTitle.Text&&item.UPrice==float.Parse(txtUPrice.Text)&&item.YearPublished==System.DateTime.Parse(dateTimePickerProduct.Text)&&item.QOH==Int32.Parse(txtQOH.Text)&&item.ProductType==(EnumProduct)comboBoxProductType.SelectedIndex&&item.Publisher==comboBoxPublishers.Text)
                    {
                        index = listOfProduct.IndexOf(item);


                    }


                }
                if (index != -1)
                {
                    listOfProduct.RemoveAt(index);
                    Product.SaveToFile(listOfProduct);

                }

                else
                {
                    MessageBox.Show("The Author was not found");
                }

                p1.Display(listOfProduct, listViewProduct);

            }
        }

        
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtFn.Clear();
            txtLn.Clear();
            comboBoxPosition.Text = Convert.ToString(EnumPosition.unknown);
            comboBoxStatus.Text = Convert.ToString(EnumStatus.Unknown);
            txtKey.Clear();
            DialogResult result = MessageBox.Show("Clear Complete!", "Reset", MessageBoxButtons.OK, MessageBoxIcon.Information);


        }

        private void btnClearSales_Click(object sender, EventArgs e)
        {
            txtInstituteName.Clear();
            txtStreet.Clear();
            txtCity.Clear();
            txtPostalCode.Clear();
            txtPhone.Clear();
            txtFax.Clear();
            txtCredit.Clear();
            txtKey3.Clear();
            DialogResult result = MessageBox.Show("Clear Complete!", "Reset", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void btnClearPublisher_Click(object sender, EventArgs e)
        {

            txtPPName.Clear();
            maskedTextBoxPhoneNumber.Clear();
            maskedTextBoxSearchPublishers.Clear();
            txtKey4.Clear();
            DialogResult result = MessageBox.Show("Clear Complete!", "Reset", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void btnClearUser_Click(object sender, EventArgs e)
        {
            txtUN.Clear();
            txtPW.Clear();
            txtKey2.Clear();

            DialogResult result = MessageBox.Show("Clear Complete!", "Reset", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void btnClearAuthor_Click(object sender, EventArgs e)
        {
            txtFNA.Clear();
            txtLNA.Clear();
            txtCityA.Clear();
            txtPhoneA.Clear();
            txtKey5.Clear();
            DialogResult result = MessageBox.Show("Clear Complete!", "Reset", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }
        private bool SearchValidNameInvProduct()
        {
            return Validator.IsPresent(txtKey6)
                 && Validator.IsLetters(txtKey6)
                 && Validator.IsSpecialCharacters(txtKey6);
        }
        private bool SearchValidISBN()
        {
            return Validator.IsLong(txtKey6)
                && Validator.IsRightNumberISBN(txtKey6);


        }

        private void btnSearchProduct_Click(object sender, EventArgs e)
        {
            
            if (comboBoxSearchProduct.Text==Convert.ToString(EnumSearchBook.ISBN))
            {
                if (SearchValidISBN())
                {


                    p1 = Product.Search(txtKey6);
                    if (p1 != null)
                    {
                        MessageBox.Show("[" + p1.ISBN + "]" + p1.Title + "," + p1.ProductType + "\tby:" + "\t" + p1.Names1 + "\n" + p1.UPrice + "$");

                    }
                    else
                    {
                        MessageBox.Show("Product Not found!");
                    }
                }
            }
            if (comboBoxSearchProduct.Text == Convert.ToString(EnumSearchBook.Title))
            {
                if (SearchValidNameInvProduct())
                {


                    p1 = Product.SearchByTitle(txtKey6);
                    if (p1 != null)
                    {
                        MessageBox.Show("[" + p1.ISBN + "]" + p1.Title + "," + p1.ProductType + ":" + p1.UPrice);

                    }
                    else
                    {
                        MessageBox.Show("Product Not found!");
                    }
                }
                    DialogResult result = MessageBox.Show("Search Complete!", "Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
            }
        }

        private void label33_Click(object sender, EventArgs e)
        {

        }

        private void comboBoxProducts_SelectedIndexChanged(object sender, EventArgs e)
        {

            indexForProduct = comboBoxProducts.SelectedIndex;
            txtPrice.Text = Convert.ToString(listOfProduct[indexForProduct].UPrice);
            

        }

        private void btnBuyProducts_Click(object sender, EventArgs e)
        {
            
            if (listOfProductsInOrder.Count == 5)
            {
                MessageBox.Show("Too many Products");
            }
            else
            {
               
                listOfProductsInOrder.Add(new Product(comboBoxProducts));

                j = comboBoxProducts.SelectedIndex;
                    listOfProductsInOrder[j].Qty = Int32.Parse(txtQty.Text);
                    int qty = listOfProductsInOrder[j].Qty;
                    listOfProductsInOrder[j].UPrice = float.Parse(txtPrice.Text);
                    float price = listOfProductsInOrder[j].UPrice;
                    float sub = qty * price;
                    listOfProductsInOrder[j].Subtotal = sub;
                
                p1.Display2(listOfProductsInOrder, listViewChosenProducts);
             


            }
        }
        private bool IsValidOrders()
        {
            return Validator.IsPresentComboBox(comboBoxClients)
                && Validator.IsPresentComboBox(comboBoxProducts)
                && Validator.IsPresentComboBox(comboBoxShipDate)
                && Validator.IsPresentComboBox(comboBoxOrderBy)

                && Validator.IsPresent(txtQty)

                && Validator.IsPresentDate(dateTimePickerReqDate)

                && Validator.IsInt32(txtQty);
                
        }
        private void btnAddOrders_Click(object sender, EventArgs e)
        {
            if (IsValidOrders())
            {


                int indexcomboClients = comboBoxClients.SelectedIndex;
                Order od = new Order(SequenceOrder.ReadToCheck(listOfOrder), comboBoxClients.Text, dateTimePickerReqDate.Value, (EnumShipDate)comboBoxShipDate.SelectedIndex);

                od.ChosenProd1 = listOfProductsInOrder;
                string names = "";
                od.Email = listOfColleges[indexcomboClients].Email;
                od.Fax = listOfColleges[indexcomboClients].FaxNumber;
                od.Phonenumber = listOfColleges[indexcomboClients].PhoneNunber;

                if (comboBoxOrderBy.Text == Convert.ToString(EnumOrderBy.Email))
                {


                    od.OrderType = od.Email;
                }
                if (comboBoxOrderBy.Text == Convert.ToString(EnumOrderBy.Fax))
                {
                    od.OrderType = od.Fax;
                }
                if (comboBoxOrderBy.Text == Convert.ToString(EnumOrderBy.Phone))
                {
                    od.OrderType = od.Phonenumber;
                }

                if (od.ChosenProd1.Count == 5)
                {


                    qty2 = od.ChosenProd1[0].Qty + od.ChosenProd1[1].Qty + od.ChosenProd1[2].Qty + od.ChosenProd1[3].Qty + od.ChosenProd1[4].Qty;
                    sub2 = od.ChosenProd1[0].Subtotal + od.ChosenProd1[1].Subtotal + od.ChosenProd1[2].Subtotal + od.ChosenProd1[3].Subtotal + od.ChosenProd1[4].Subtotal;
                    names = od.ChosenProd1[0].Title + "|" + od.ChosenProd1[1].Title + "|" + od.ChosenProd1[2].Title + "|" + od.ChosenProd1[3].Title + "|" + od.ChosenProd1[4].Title;
                }

                if (od.ChosenProd1.Count == 4)
                {


                    qty2 = od.ChosenProd1[0].Qty + od.ChosenProd1[1].Qty + od.ChosenProd1[2].Qty + od.ChosenProd1[3].Qty;
                    sub2 = od.ChosenProd1[0].Subtotal + od.ChosenProd1[1].Subtotal + od.ChosenProd1[2].Subtotal + od.ChosenProd1[3].Subtotal;
                    names = od.ChosenProd1[0].Title + "|" + od.ChosenProd1[1].Title + "|" + od.ChosenProd1[2].Title + "|" + od.ChosenProd1[3].Title;
                }
                if (od.ChosenProd1.Count == 3)
                {


                    qty2 = od.ChosenProd1[0].Qty + od.ChosenProd1[1].Qty + od.ChosenProd1[2].Qty;
                    sub2 = od.ChosenProd1[0].Subtotal + od.ChosenProd1[1].Subtotal + od.ChosenProd1[2].Subtotal;
                    names = od.ChosenProd1[0].Title + "|" + od.ChosenProd1[1].Title + "|" + od.ChosenProd1[2].Title;
                }
                if (od.ChosenProd1.Count == 2)
                {


                    qty2 = od.ChosenProd1[0].Qty + od.ChosenProd1[1].Qty;
                    sub2 = od.ChosenProd1[0].Subtotal + od.ChosenProd1[1].Subtotal;
                    names = od.ChosenProd1[0].Title + "|" + od.ChosenProd1[1].Title;

                }
                if (od.ChosenProd1.Count == 1)
                {


                    qty2 = od.ChosenProd1[0].Qty;
                    sub2 = od.ChosenProd1[0].Subtotal;
                    names = od.ChosenProd1[0].Title;
                }
                od.ProductName = names;
                od.Qty = qty2;
                od.Subtotal = sub2;
                float subtaxe = 0.00f;
                subtaxe = sub2 * taxes;
                float total = 0.00f;
                total = subtaxe + sub2;
                od.Total = total;
                int credit = listOfColleges[comboBoxClients.SelectedIndex].Credit;
                od.Credit = credit;
                float acredit = credit - total;
                if (acredit < 0)
                {
                    MessageBox.Show("Limited Credit");
                }
                else
                {


                    od.AvailableCredit = acredit;
                    listOfOrder.Add(od);
                    od.Display(listOfOrder, listViewOrders);
                    listViewChosenProducts.Items.Clear();
                }


                DialogResult result = MessageBox.Show("Add Complete!", "Add Employee", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void comboBoxClients_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxQty_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSaveOrders_Click(object sender, EventArgs e)
        {
            Order.SaveToFile(listOfOrder);
            DialogResult result = MessageBox.Show("Save Complete!", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void btnReadOrders_Click(object sender, EventArgs e)
        {
            Order.ReadFromFile(listOfTempOD, listOfOrder, ord, listViewOrders);
            DialogResult result = MessageBox.Show("Read Complete!", "View", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }
        private bool SearchValidOrderID()
        {
            return Validator.IsInt32(txtKey7)
                && Validator.IsRightNumberOrderID(txtKey7);


        }
        private void btnSearchOrders_Click(object sender, EventArgs e)
        {
            if (SearchValidOrderID())
            {


                ord = Order.Search(txtKey7);
                if (ord != null)
                {
                    MessageBox.Show("[" + ord.OrderID + "]" + ord.ClientName + ",Total:" + ord.Total + "$,AvailableCredit:" + ord.AvailableCredit + "$");

                }
                else
                {
                    MessageBox.Show("Order Not found!");
                }
                DialogResult result = MessageBox.Show("Search Complete!", "Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void maskedTextBoxSearch_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnAbout_Click(object sender, EventArgs e)
        {
            
        }
    }
    }

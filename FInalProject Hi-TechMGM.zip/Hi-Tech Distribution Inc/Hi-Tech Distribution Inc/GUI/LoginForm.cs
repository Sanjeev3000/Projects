﻿using Hi_TechDistributionIncLibrary.Business;
using Hi_TechDistributionIncLibrary.DataAccess;
using Hi_TechDistributionIncLibrary.Validator;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.TabControl;

namespace Hi_Tech_Distribution_Inc.GUI
{
    public partial class LoginForm : Form
    {
        List<Employee> list = new List<Employee>();
        List<User> listUsers = new List<User>();
        
        private void ListAllUsers() {
            foreach (Employee item in this.list)
            {
                User u1 = new User();
                u1 = item.Username;
                this.listUsers.Add(u1);
            }
        }

        public LoginForm()
        {
            InitializeComponent();


        }
    
        private void comboBoxPosition_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private bool Valid()
        {
            return Validator.IsPresent(txtID)
                && Validator.IsPresent(txtPassword);



        }
        private void LoginForm_Load(object sender, EventArgs e)
        {
            this.list = EmployeeDA.ReadFromFile();
            
           
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (Valid())
            {


                //Employee temp = new Employee();
                //temp = EmployeeDA.SearchInfo(this.list, txtID.Text);
                //LoginForm log = new LoginForm();
                //UserDA.Login(log, txtID, txtPassword,Convert.ToString(temp.Position));
                //this.Hide();
                Employee temp = new Employee();
                temp = EmployeeDA.SearchInfo(this.list, txtID.Text);
                LoginForm log = new LoginForm();
                UserDA.Login(log, txtID, txtPassword, Convert.ToString(temp.Position));
                this.Hide();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure?", "Exit", MessageBoxButtons.OKCancel);

            if (result == DialogResult.OK)
            {
                this.Close();
            }
        }

        private void txtID_MouseClick(object sender, MouseEventArgs e)
        {
            txtID.Text= "";
        }

        private void LoginForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            AboutBoxHiTechDistribution form = new AboutBoxHiTechDistribution();
            this.Hide();
            form.Show();
        }
    }
}
